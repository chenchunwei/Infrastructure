Imports System
Imports System.Collections
Imports System.IO
Imports Microsoft.VisualBasic
Imports Dimac.JMail
Imports Dimac.JMail.MailMerge

Module MainModule

    Sub Main()
        ' set up fake data
        Dim mailingList As New ArrayList
        For i As Int32 = 1 To 100
            Dim entry As New SubscriptionEntry("Support Dude #" & i, "support" & i & "@dimac.net", "Helsingborg")
            mailingList.Add(entry)
        Next

        ' set up mailmerge object
        Dim mm As New Dimac.JMail.MailMerge.MailMerge

        ' create template
        mm.Template.From.Email = "test@dimac.net"
        mm.Template.Subject = "Hello, brave new world!"
        mm.Template.BodyText = "Hello <%# Name %>" & vbCrLf & "Since you live in <%# City %> you are welcome to visit us."
        mm.Template.To.Add("<%# EmailAddress %>", "<%# Name %>")

        ' set output directory
        mm.OutputDirectory = Directory.GetCurrentDirectory()


        ' create messages
        mm.DataSource = mailingList
        Dim count = mm.DataBind()

        Console.WriteLine("{0} messages created.", count)
    End Sub

End Module
