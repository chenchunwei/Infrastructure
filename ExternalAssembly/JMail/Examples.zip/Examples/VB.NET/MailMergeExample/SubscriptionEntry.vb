Public Class SubscriptionEntry
    Private m_name As String
    Private m_emailAddress As String
    Private m_city As String

    Public Sub New(ByVal name As String, ByVal emailAddress As String, ByVal city As String)
        m_name = name
        m_emailAddress = emailAddress
        m_city = city
    End Sub

    Public ReadOnly Property Name()
        Get
            Return m_name
        End Get
    End Property

    Public ReadOnly Property EmailAddress()
        Get
            Return m_emailAddress
        End Get
    End Property

    Public ReadOnly Property City()
        Get
            Return m_city
        End Get
    End Property
End Class
