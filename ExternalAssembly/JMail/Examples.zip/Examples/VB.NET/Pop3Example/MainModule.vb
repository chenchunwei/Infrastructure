Imports System 
Imports Dimac.JMail
Imports Dimac.JMail.Pop3

Module MainModule

    Sub Main()

        Console.WriteLine(New String("=", 79))
        Console.Write("Server: ")
        Dim hostName = Console.ReadLine()
        Console.Write("User Name: ")
        Dim userName = Console.ReadLine()
        Console.Write("Password: ")
        Dim password = Console.ReadLine()
        Console.WriteLine(New String("=", 79))
        Console.WriteLine()

        Dim pop3 As New Dimac.JMail.Pop3.Pop3(hostName, userName, password)
        Dim messages = pop3.Inbox
        Console.Write(FixedWidth("Date", 17))
        Console.Write(FixedWidth("Subject", 31))
        Console.WriteLine(FixedWidth("From", 31))
        Console.WriteLine(New String("=", 79))
        Dim msg As Message
        For Each msg In messages
            Console.WriteLine("{0} {1} {2}", msg.Date.ToString("yyyy-MM-dd HH:mm"), FixedWidth(msg.Subject, 30), FixedWidth(msg.From.FullName, 30))
        Next
    End Sub

    Private Function FixedWidth(ByVal s As String, ByVal length As Int32)
        If s Is Nothing Then
            Return New String(" ", length)
        ElseIf s.Length < length Then
            Return s.PadRight(length, " ")
        Else
            Return s.Substring(0, length - 2) & ".."
        End If
    End Function
End Module
