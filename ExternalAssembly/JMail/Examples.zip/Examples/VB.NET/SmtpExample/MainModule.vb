Imports System
Imports System.Text
Imports Dimac.JMail
Imports Dimac.JMail.Smtp
Imports Dimac.JMail.Mime

' A consol application that sends an email by SMTP.
' Lets the user to set the fields and then write the body part. 
' The body part is ended by entering an empty line,
' which will also send the email.
Module MainModule

	Sub Main()
		Console.WriteLine( New String( "=", 79 ) )
		Console.Write( "Server: " )
		Dim hostName = Console.ReadLine()
		Console.Write( "From: " )
		Dim from = Console.ReadLine()
		Console.Write( "To: " )
		Dim toAddress = Console.ReadLine()
		Console.Write( "Subject: " )
		Dim subject = Console.ReadLine()
		Dim bodyPart = Body()
		Console.WriteLine( New String( "=", 79 ) )
		
		Console.WriteLine( "Sending message..." )
		Dim message As New Message( Address.Parse( from ), Address.Parse( toAddress ), subject, bodyPart )
		Dimac.JMail.Smtp.Smtp.Send( message, hostName )
		Console.WriteLine( "Message sent." )
	End Sub

	' Get the body part from user input.
	' It is ended with an empty line.
	Private Function Body() As String
		Console.WriteLine( "Body(end with an emtpy line): " )
		
		Dim bodyPart As New StringBuilder()
		Dim line = Console.ReadLine()
		While line.Length > 0
			If line.Length > 0 and bodyPart.Length > 0 Then
				bodyPart.Append( Environment.NewLine )
			End If
			bodyPart.Append( line )
			line = Console.ReadLine()
		End While
		Return bodyPart.ToString()
	End Function
	
End Module
