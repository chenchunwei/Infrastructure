Option Explicit

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Windows.Forms
Imports Dimac.JMail.Mime

Module MainModule

    Sub Main()
        Application.Run(New MainForm())
    End Sub

End Module

Public Class MainForm
    Inherits System.Windows.Forms.Form    

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents StatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents StatusBarPanel As System.Windows.Forms.StatusBarPanel
    Friend WithEvents lvHeaders As System.Windows.Forms.ListView
    Friend WithEvents tvBodyParts As System.Windows.Forms.TreeView
    Friend WithEvents chHeaderName As System.Windows.Forms.ColumnHeader
    Friend WithEvents chHeaderValue As System.Windows.Forms.ColumnHeader
    Friend WithEvents Splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents mainMenu As System.Windows.Forms.MainMenu
    Friend WithEvents mFile As System.Windows.Forms.MenuItem
    Friend WithEvents mFileOpen As System.Windows.Forms.MenuItem
    Friend WithEvents mFileExit As System.Windows.Forms.MenuItem
    Friend WithEvents openFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents MenuSaveAs As System.Windows.Forms.MenuItem
    Friend WithEvents Shadows contextMenu As System.Windows.Forms.ContextMenu
    Friend WithEvents saveFileDialog As System.Windows.Forms.SaveFileDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu = New System.Windows.Forms.MainMenu
        Me.mFile = New System.Windows.Forms.MenuItem
        Me.mFileOpen = New System.Windows.Forms.MenuItem
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.mFileExit = New System.Windows.Forms.MenuItem
        Me.StatusBar = New System.Windows.Forms.StatusBar
        Me.StatusBarPanel = New System.Windows.Forms.StatusBarPanel
        Me.lvHeaders = New System.Windows.Forms.ListView
        Me.chHeaderName = New System.Windows.Forms.ColumnHeader
        Me.chHeaderValue = New System.Windows.Forms.ColumnHeader
        Me.tvBodyParts = New System.Windows.Forms.TreeView
        Me.Splitter1 = New System.Windows.Forms.Splitter
        Me.openFileDialog = New System.Windows.Forms.OpenFileDialog
        Me.contextMenu = New System.Windows.Forms.ContextMenu
        Me.MenuSaveAs = New System.Windows.Forms.MenuItem
        Me.saveFileDialog = New System.Windows.Forms.SaveFileDialog
        CType(Me.StatusBarPanel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mainMenu
        '
        Me.mainMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mFile})
        '
        'mFile
        '
        Me.mFile.Index = 0
        Me.mFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mFileOpen, Me.MenuItem1, Me.mFileExit})
        Me.mFile.Text = "&File"
        '
        'mFileOpen
        '
        Me.mFileOpen.Index = 0
        Me.mFileOpen.Shortcut = System.Windows.Forms.Shortcut.CtrlO
        Me.mFileOpen.Text = "&Open.."
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 1
        Me.MenuItem1.Text = "-"
        '
        'mFileExit
        '
        Me.mFileExit.Index = 2
        Me.mFileExit.Text = "E&xit"
        '
        'StatusBar
        '
        Me.StatusBar.Location = New System.Drawing.Point(0, 333)
        Me.StatusBar.Name = "StatusBar"
        Me.StatusBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.StatusBarPanel})
        Me.StatusBar.ShowPanels = True
        Me.StatusBar.Size = New System.Drawing.Size(368, 22)
        Me.StatusBar.TabIndex = 0
        '
        'StatusBarPanel
        '
        Me.StatusBarPanel.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.StatusBarPanel.Text = "Ready"
        Me.StatusBarPanel.Width = 352
        '
        'lvHeaders
        '
        Me.lvHeaders.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chHeaderName, Me.chHeaderValue})
        Me.lvHeaders.Dock = System.Windows.Forms.DockStyle.Top
        Me.lvHeaders.FullRowSelect = True
        Me.lvHeaders.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvHeaders.Location = New System.Drawing.Point(0, 0)
        Me.lvHeaders.Name = "lvHeaders"
        Me.lvHeaders.Size = New System.Drawing.Size(368, 152)
        Me.lvHeaders.TabIndex = 1
        Me.lvHeaders.View = System.Windows.Forms.View.Details
        '
        'chHeaderName
        '
        Me.chHeaderName.Text = "Name"
        Me.chHeaderName.Width = 160
        '
        'chHeaderValue
        '
        Me.chHeaderValue.Text = "Value"
        Me.chHeaderValue.Width = 160
        '
        'tvBodyParts
        '
        Me.tvBodyParts.ContextMenu = Me.contextMenu
        Me.tvBodyParts.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tvBodyParts.ImageIndex = -1
        Me.tvBodyParts.Location = New System.Drawing.Point(0, 152)
        Me.tvBodyParts.Name = "tvBodyParts"
        Me.tvBodyParts.SelectedImageIndex = -1
        Me.tvBodyParts.Size = New System.Drawing.Size(368, 181)
        Me.tvBodyParts.TabIndex = 2
        '
        'Splitter1
        '
        Me.Splitter1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Splitter1.Location = New System.Drawing.Point(0, 152)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(368, 3)
        Me.Splitter1.TabIndex = 3
        Me.Splitter1.TabStop = False
        '
        'openFileDialog
        '
        Me.openFileDialog.Filter = "E-mail Files (*.eml)|*.eml|All Files (*.*)|*.*"
        '
        'contextMenu
        '
        Me.contextMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuSaveAs})
        '
        'MenuSaveAs
        '
        Me.MenuSaveAs.Index = 0
        Me.MenuSaveAs.Text = "&Save As.."
        '
        'saveFileDialog
        '
        Me.saveFileDialog.Filter = "All Files (*.*)|*.*"
        '
        'MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(368, 355)
        Me.Controls.Add(Me.Splitter1)
        Me.Controls.Add(Me.tvBodyParts)
        Me.Controls.Add(Me.lvHeaders)
        Me.Controls.Add(Me.StatusBar)
        Me.Menu = Me.mainMenu
        Me.Name = "MainForm"
        Me.Text = "MIME Document Viewer"
        CType(Me.StatusBarPanel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub mFileOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mFileOpen.Click
        If openFileDialog.ShowDialog(Me) Then
            OpenFile(openFileDialog.FileName)
        End If
    End Sub

    Private Sub mFileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mFileExit.Click
        Application.Exit()
    End Sub

    Private Sub OpenFile(ByVal Path As String)
        If File.Exists(Path) Then            
            ' setup filestream for reading file
            Dim fs As New FileStream(Path, FileMode.Open, FileAccess.Read, FileShare.Read)
            ' setup mimereader for parsing the mime objects in the file stream
            Dim reader As New MimeReader(fs)
            Try
                Dim root As Entity
                root = reader.Read
                If Not root Is Nothing Then
                    BindEntity(root)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.OKOnly, "MIME Error")
            Finally
                fs.Close()
                reader.Dispose()
            End Try
        End If
    End Sub

    Private Sub BindEntity(ByRef entity As Entity)
        StatusBarPanel.Text = "Loading MIME document.."
        tvBodyParts.BeginUpdate()
        AddBodyPart(Nothing, entity)
        tvBodyParts.EndUpdate()
        BindHeaders(entity)
        StatusBarPanel.Text = "Ready"
    End Sub

    Private Sub AddBodyPart(ByRef parent As TreeNode, ByRef entity As Entity)
        Dim text As String
        text = entity.Headers.ContentType.Type & "/" & entity.Headers.ContentType.SubType & " (" & FormatSize(entity.Body.Length) & ")"

        Dim node As New TreeNode(text)
        node.Tag = entity

        If parent Is Nothing Then
            tvBodyParts.Nodes.Add(node)
        Else
            parent.Nodes.Add(node)
        End If

        ' iterate child enities ("body parts")
        Dim child As Entity
        For Each child In entity.BodyParts
            AddBodyPart(node, child)
        Next        
    End Sub

    Private Sub BindHeaders(ByRef entity As Entity)
        Dim Name As String
        lvHeaders.BeginUpdate()
        lvHeaders.Items.Clear()
        ' iterate entity headers and add to list
        For Each Name In entity.Headers.Names
            Dim item As New ListViewItem(Name)
            item.SubItems.Add(entity.Headers(Name).ToString())
            lvHeaders.Items.Add(item)
        Next
        lvHeaders.EndUpdate()
    End Sub

    Private Sub tvBodyParts_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvBodyParts.AfterSelect        
        BindHeaders(e.Node.Tag)
    End Sub

    Const GB = 1024 * 1024 * 1024
    Const MB = 1024 * 1024
    Const KB = 1024

    Private Function FormatSize(ByVal size As Decimal)
        If size > GB Then
            FormatSize = Math.Round(size / GB, 2).ToString() & " GB"
        ElseIf size > MB Then
            FormatSize = Math.Round(size / MB, 2).ToString() & " MB"
        ElseIf size > KB Then
            FormatSize = Math.Round(size / KB, 2).ToString() & " KB"
        Else
            FormatSize = size & " B"
        End If
    End Function

    Private Sub MenuSaveAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuSaveAs.Click
        If Not tvBodyParts.SelectedNode Is Nothing Then
            Dim entity As Entity = tvBodyParts.SelectedNode.Tag
            If Not entity Is Nothing Then
                If entity.Body.Length > 0 And entity.Headers.ContentType.Type <> "multipart" Then
                    If Not entity.Headers.ContentDisposition.FileName Is Nothing Then
                        saveFileDialog.FileName = entity.Headers.ContentDisposition.FileName
                    End If
                    If saveFileDialog.ShowDialog(Me) = DialogResult.OK Then
                        Dim fs As New FileStream(saveFileDialog.FileName, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.None)
                        Try
                            fs.Write(entity.Body, 0, entity.Body.Length)
                        Finally
                            fs.Close()
                        End Try
                    End If
                End If
            End If
        End If
    End Sub
End Class
