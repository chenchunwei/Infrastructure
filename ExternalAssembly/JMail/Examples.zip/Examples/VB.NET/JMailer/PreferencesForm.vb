Public Class PreferencesForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Databind the SmtpAuthentication methods to a combo box.
        cbAuthentication.DataSource = [Enum].GetValues(GetType(SmtpAuthentication))

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents bCancel As System.Windows.Forms.Button
    Friend WithEvents bOK As System.Windows.Forms.Button
    Friend WithEvents tabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents tPop3Password As System.Windows.Forms.TextBox
    Friend WithEvents tPop3UserName As System.Windows.Forms.TextBox
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents tPop3Port As System.Windows.Forms.TextBox
    Friend WithEvents tPop3HostName As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents tabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents tSmtpFullName As System.Windows.Forms.TextBox
    Friend WithEvents tSmtpEmail As System.Windows.Forms.TextBox
    Friend WithEvents label10 As System.Windows.Forms.Label
    Friend WithEvents label11 As System.Windows.Forms.Label
    Friend WithEvents cbAuthentication As System.Windows.Forms.ComboBox
    Friend WithEvents label9 As System.Windows.Forms.Label
    Friend WithEvents tSmtpPassword As System.Windows.Forms.TextBox
    Friend WithEvents tSmtpUserName As System.Windows.Forms.TextBox
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents label6 As System.Windows.Forms.Label
    Friend WithEvents label7 As System.Windows.Forms.Label
    Friend WithEvents tSmtpPort As System.Windows.Forms.TextBox
    Friend WithEvents tSmtpHostName As System.Windows.Forms.TextBox
    Friend WithEvents label8 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.bCancel = New System.Windows.Forms.Button
        Me.bOK = New System.Windows.Forms.Button
        Me.tabControl1 = New System.Windows.Forms.TabControl
        Me.tabPage1 = New System.Windows.Forms.TabPage
        Me.tPop3Password = New System.Windows.Forms.TextBox
        Me.tPop3UserName = New System.Windows.Forms.TextBox
        Me.label4 = New System.Windows.Forms.Label
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.tPop3Port = New System.Windows.Forms.TextBox
        Me.tPop3HostName = New System.Windows.Forms.TextBox
        Me.label1 = New System.Windows.Forms.Label
        Me.tabPage2 = New System.Windows.Forms.TabPage
        Me.tSmtpFullName = New System.Windows.Forms.TextBox
        Me.tSmtpEmail = New System.Windows.Forms.TextBox
        Me.label10 = New System.Windows.Forms.Label
        Me.label11 = New System.Windows.Forms.Label
        Me.cbAuthentication = New System.Windows.Forms.ComboBox
        Me.label9 = New System.Windows.Forms.Label
        Me.tSmtpPassword = New System.Windows.Forms.TextBox
        Me.tSmtpUserName = New System.Windows.Forms.TextBox
        Me.label5 = New System.Windows.Forms.Label
        Me.label6 = New System.Windows.Forms.Label
        Me.label7 = New System.Windows.Forms.Label
        Me.tSmtpPort = New System.Windows.Forms.TextBox
        Me.tSmtpHostName = New System.Windows.Forms.TextBox
        Me.label8 = New System.Windows.Forms.Label
        Me.tabControl1.SuspendLayout()
        Me.tabPage1.SuspendLayout()
        Me.tabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'bCancel
        '
        Me.bCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.bCancel.Location = New System.Drawing.Point(169, 321)
        Me.bCancel.Name = "bCancel"
        Me.bCancel.TabIndex = 5
        Me.bCancel.Text = "&Cancel"
        '
        'bOK
        '
        Me.bOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.bOK.Location = New System.Drawing.Point(249, 321)
        Me.bOK.Name = "bOK"
        Me.bOK.TabIndex = 4
        Me.bOK.Text = "&OK"
        '
        'tabControl1
        '
        Me.tabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tabControl1.Controls.Add(Me.tabPage1)
        Me.tabControl1.Controls.Add(Me.tabPage2)
        Me.tabControl1.Location = New System.Drawing.Point(9, 9)
        Me.tabControl1.Name = "tabControl1"
        Me.tabControl1.SelectedIndex = 0
        Me.tabControl1.Size = New System.Drawing.Size(320, 304)
        Me.tabControl1.TabIndex = 3
        '
        'tabPage1
        '
        Me.tabPage1.Controls.Add(Me.tPop3Password)
        Me.tabPage1.Controls.Add(Me.tPop3UserName)
        Me.tabPage1.Controls.Add(Me.label4)
        Me.tabPage1.Controls.Add(Me.label3)
        Me.tabPage1.Controls.Add(Me.label2)
        Me.tabPage1.Controls.Add(Me.tPop3Port)
        Me.tabPage1.Controls.Add(Me.tPop3HostName)
        Me.tabPage1.Controls.Add(Me.label1)
        Me.tabPage1.Location = New System.Drawing.Point(4, 22)
        Me.tabPage1.Name = "tabPage1"
        Me.tabPage1.Size = New System.Drawing.Size(312, 278)
        Me.tabPage1.TabIndex = 0
        Me.tabPage1.Text = "POP3"
        '
        'tPop3Password
        '
        Me.tPop3Password.Location = New System.Drawing.Point(160, 88)
        Me.tPop3Password.Name = "tPop3Password"
        Me.tPop3Password.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.tPop3Password.Size = New System.Drawing.Size(144, 20)
        Me.tPop3Password.TabIndex = 7
        Me.tPop3Password.Text = ""
        '
        'tPop3UserName
        '
        Me.tPop3UserName.Location = New System.Drawing.Point(8, 88)
        Me.tPop3UserName.Name = "tPop3UserName"
        Me.tPop3UserName.Size = New System.Drawing.Size(144, 20)
        Me.tPop3UserName.TabIndex = 6
        Me.tPop3UserName.Text = ""
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(160, 72)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(64, 16)
        Me.label4.TabIndex = 5
        Me.label4.Text = "Password:"
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(8, 72)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(72, 16)
        Me.label3.TabIndex = 4
        Me.label3.Text = "User Name:"
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(232, 16)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(48, 16)
        Me.label2.TabIndex = 3
        Me.label2.Text = "Port:"
        '
        'tPop3Port
        '
        Me.tPop3Port.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tPop3Port.Location = New System.Drawing.Point(232, 32)
        Me.tPop3Port.Name = "tPop3Port"
        Me.tPop3Port.Size = New System.Drawing.Size(72, 20)
        Me.tPop3Port.TabIndex = 2
        Me.tPop3Port.Text = ""
        '
        'tPop3HostName
        '
        Me.tPop3HostName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tPop3HostName.Location = New System.Drawing.Point(8, 32)
        Me.tPop3HostName.Name = "tPop3HostName"
        Me.tPop3HostName.Size = New System.Drawing.Size(216, 20)
        Me.tPop3HostName.TabIndex = 1
        Me.tPop3HostName.Text = ""
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 16)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(100, 16)
        Me.label1.TabIndex = 0
        Me.label1.Text = "Host Name:"
        '
        'tabPage2
        '
        Me.tabPage2.Controls.Add(Me.tSmtpFullName)
        Me.tabPage2.Controls.Add(Me.tSmtpEmail)
        Me.tabPage2.Controls.Add(Me.label10)
        Me.tabPage2.Controls.Add(Me.label11)
        Me.tabPage2.Controls.Add(Me.cbAuthentication)
        Me.tabPage2.Controls.Add(Me.label9)
        Me.tabPage2.Controls.Add(Me.tSmtpPassword)
        Me.tabPage2.Controls.Add(Me.tSmtpUserName)
        Me.tabPage2.Controls.Add(Me.label5)
        Me.tabPage2.Controls.Add(Me.label6)
        Me.tabPage2.Controls.Add(Me.label7)
        Me.tabPage2.Controls.Add(Me.tSmtpPort)
        Me.tabPage2.Controls.Add(Me.tSmtpHostName)
        Me.tabPage2.Controls.Add(Me.label8)
        Me.tabPage2.Location = New System.Drawing.Point(4, 22)
        Me.tabPage2.Name = "tabPage2"
        Me.tabPage2.Size = New System.Drawing.Size(312, 278)
        Me.tabPage2.TabIndex = 1
        Me.tabPage2.Text = "SMTP"
        Me.tabPage2.Visible = False
        '
        'tSmtpFullName
        '
        Me.tSmtpFullName.Location = New System.Drawing.Point(160, 200)
        Me.tSmtpFullName.Name = "tSmtpFullName"
        Me.tSmtpFullName.Size = New System.Drawing.Size(144, 20)
        Me.tSmtpFullName.TabIndex = 21
        Me.tSmtpFullName.Text = ""
        '
        'tSmtpEmail
        '
        Me.tSmtpEmail.Location = New System.Drawing.Point(8, 200)
        Me.tSmtpEmail.Name = "tSmtpEmail"
        Me.tSmtpEmail.Size = New System.Drawing.Size(144, 20)
        Me.tSmtpEmail.TabIndex = 20
        Me.tSmtpEmail.Text = ""
        '
        'label10
        '
        Me.label10.Location = New System.Drawing.Point(160, 184)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(64, 16)
        Me.label10.TabIndex = 19
        Me.label10.Text = "Full Name:"
        '
        'label11
        '
        Me.label11.Location = New System.Drawing.Point(8, 184)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(96, 16)
        Me.label11.TabIndex = 18
        Me.label11.Text = "E-mail Address:"
        '
        'cbAuthentication
        '
        Me.cbAuthentication.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbAuthentication.Location = New System.Drawing.Point(8, 88)
        Me.cbAuthentication.Name = "cbAuthentication"
        Me.cbAuthentication.Size = New System.Drawing.Size(296, 21)
        Me.cbAuthentication.TabIndex = 17
        '
        'label9
        '
        Me.label9.Location = New System.Drawing.Point(8, 72)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(80, 16)
        Me.label9.TabIndex = 16
        Me.label9.Text = "Authentication:"
        '
        'tSmtpPassword
        '
        Me.tSmtpPassword.Location = New System.Drawing.Point(160, 144)
        Me.tSmtpPassword.Name = "tSmtpPassword"
        Me.tSmtpPassword.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.tSmtpPassword.Size = New System.Drawing.Size(144, 20)
        Me.tSmtpPassword.TabIndex = 15
        Me.tSmtpPassword.Text = ""
        '
        'tSmtpUserName
        '
        Me.tSmtpUserName.Location = New System.Drawing.Point(8, 144)
        Me.tSmtpUserName.Name = "tSmtpUserName"
        Me.tSmtpUserName.Size = New System.Drawing.Size(144, 20)
        Me.tSmtpUserName.TabIndex = 14
        Me.tSmtpUserName.Text = ""
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(160, 128)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(64, 16)
        Me.label5.TabIndex = 13
        Me.label5.Text = "Password:"
        '
        'label6
        '
        Me.label6.Location = New System.Drawing.Point(8, 128)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(72, 16)
        Me.label6.TabIndex = 12
        Me.label6.Text = "User Name:"
        '
        'label7
        '
        Me.label7.Location = New System.Drawing.Point(232, 16)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(48, 16)
        Me.label7.TabIndex = 11
        Me.label7.Text = "Port:"
        '
        'tSmtpPort
        '
        Me.tSmtpPort.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tSmtpPort.Location = New System.Drawing.Point(232, 32)
        Me.tSmtpPort.Name = "tSmtpPort"
        Me.tSmtpPort.Size = New System.Drawing.Size(72, 20)
        Me.tSmtpPort.TabIndex = 10
        Me.tSmtpPort.Text = ""
        '
        'tSmtpHostName
        '
        Me.tSmtpHostName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tSmtpHostName.Location = New System.Drawing.Point(8, 32)
        Me.tSmtpHostName.Name = "tSmtpHostName"
        Me.tSmtpHostName.Size = New System.Drawing.Size(216, 20)
        Me.tSmtpHostName.TabIndex = 9
        Me.tSmtpHostName.Text = ""
        '
        'label8
        '
        Me.label8.Location = New System.Drawing.Point(8, 16)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(100, 16)
        Me.label8.TabIndex = 8
        Me.label8.Text = "Host Name:"
        '
        'PreferencesForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(338, 352)
        Me.Controls.Add(Me.bCancel)
        Me.Controls.Add(Me.bOK)
        Me.Controls.Add(Me.tabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "PreferencesForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Preferences"
        Me.tabControl1.ResumeLayout(False)
        Me.tabPage1.ResumeLayout(False)
        Me.tabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' Loads the application settings to the form.
    Private Sub PreferencesForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        tPop3HostName.Text = Config.Singleton.GetValue("pop3.hostname", "localhost")
        tPop3Port.Text = Config.Singleton.GetValue("pop3.port", "110")
        tPop3UserName.Text = Config.Singleton.GetValue("pop3.username", "")
        tPop3Password.Text = Config.Singleton.GetValue("pop3.password", "")

        tSmtpHostName.Text = Config.Singleton.GetValue("smtp.hostname", "localhost")
        tSmtpPort.Text = Config.Singleton.GetValue("smtp.port", "25")
        tSmtpUserName.Text = Config.Singleton.GetValue("smtp.username", "")
        tSmtpPassword.Text = Config.Singleton.GetValue("smtp.password", "")

        tSmtpEmail.Text = Config.Singleton.GetValue("smtp.email", "")
        tSmtpFullName.Text = Config.Singleton.GetValue("smtp.fullname", "")

        Dim auth As SmtpAuthentication = [Enum].Parse(GetType(SmtpAuthentication), Config.Singleton.GetValue("smtp.authentication", "None"))
        cbAuthentication.SelectedIndex = cbAuthentication.Items.IndexOf(auth)        

        cbAuthentication_SelectedIndexChanged(sender, e)
    End Sub

    ' Handles authentication.
    Private Sub cbAuthentication_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbAuthentication.SelectedIndexChanged
        If cbAuthentication.SelectedIndex > 0 Then
            tSmtpUserName.Enabled = True
            tSmtpPassword.Enabled = True
        Else
            tSmtpUserName.Enabled = False
            tSmtpPassword.Enabled = False
            tSmtpPassword.Text = ""
            tSmtpUserName.Text = ""
        End If
    End Sub

    ' Closes the form without saving changes.
    Private Sub bCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bCancel.Click
        DialogResult = DialogResult.Cancel
        Close()
    End Sub

    ' Closes the form and saves changes.
    Private Sub bOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bOK.Click
        Config.Singleton.SetValue("pop3.hostname", tPop3HostName.Text.Trim())
        Config.Singleton.SetValue("pop3.port", tPop3Port.Text.Trim())
        Config.Singleton.SetValue("pop3.username", tPop3UserName.Text.Trim())
        Config.Singleton.SetValue("pop3.password", tPop3Password.Text.Trim())

        Config.Singleton.SetValue("smtp.hostname", tSmtpHostName.Text.Trim())
        Config.Singleton.SetValue("smtp.port", tSmtpPort.Text.Trim())
        Config.Singleton.SetValue("smtp.username", tSmtpUserName.Text.Trim())
        Config.Singleton.SetValue("smtp.password", tSmtpPassword.Text.Trim())
        Config.Singleton.SetValue("smtp.authentication", cbAuthentication.SelectedValue.ToString())
        Config.Singleton.SetValue("smtp.email", tSmtpEmail.Text.Trim())
        Config.Singleton.SetValue("smtp.fullname", tSmtpFullName.Text.Trim())

        Config.Singleton.Save()

        DialogResult = DialogResult.OK
        Close()
    End Sub
End Class
