Public Class MainForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        ' dispose JMail POP3 client if it's not already null.
        If Not m_pop3 Is Nothing Then
            m_pop3.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu As System.Windows.Forms.MainMenu
    Friend WithEvents MenuFile As System.Windows.Forms.MenuItem
    Friend WithEvents MenuFilePreferences As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuFileExit As System.Windows.Forms.MenuItem
    Friend WithEvents MenuMail As System.Windows.Forms.MenuItem
    Friend WithEvents MenuMailNewMessage As System.Windows.Forms.MenuItem
    Friend WithEvents MenuMailDelete As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuMailRefresh As System.Windows.Forms.MenuItem
    Friend WithEvents lvMail As System.Windows.Forms.ListView
    Friend WithEvents chFrom As System.Windows.Forms.ColumnHeader
    Friend WithEvents chSubject As System.Windows.Forms.ColumnHeader
    Friend WithEvents chDateReceived As System.Windows.Forms.ColumnHeader
    Friend WithEvents SplitterHorizontal As System.Windows.Forms.Splitter
    Friend WithEvents pAttachments As System.Windows.Forms.Panel
    Friend WithEvents axwbMailBody As AxSHDocVw.AxWebBrowser
    Friend WithEvents SaveFileDialog As System.Windows.Forms.SaveFileDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MainForm))
        Me.MainMenu = New System.Windows.Forms.MainMenu
        Me.MenuFile = New System.Windows.Forms.MenuItem
        Me.MenuFilePreferences = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuFileExit = New System.Windows.Forms.MenuItem
        Me.MenuMail = New System.Windows.Forms.MenuItem
        Me.MenuMailNewMessage = New System.Windows.Forms.MenuItem
        Me.MenuMailDelete = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MenuMailRefresh = New System.Windows.Forms.MenuItem
        Me.lvMail = New System.Windows.Forms.ListView
        Me.chFrom = New System.Windows.Forms.ColumnHeader
        Me.chSubject = New System.Windows.Forms.ColumnHeader
        Me.chDateReceived = New System.Windows.Forms.ColumnHeader
        Me.SplitterHorizontal = New System.Windows.Forms.Splitter
        Me.pAttachments = New System.Windows.Forms.Panel
        Me.axwbMailBody = New AxSHDocVw.AxWebBrowser
        Me.SaveFileDialog = New System.Windows.Forms.SaveFileDialog
        CType(Me.axwbMailBody, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MainMenu
        '
        Me.MainMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuFile, Me.MenuMail})
        '
        'MenuFile
        '
        Me.MenuFile.Index = 0
        Me.MenuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuFilePreferences, Me.MenuItem3, Me.MenuFileExit})
        Me.MenuFile.Text = "&File"
        '
        'MenuFilePreferences
        '
        Me.MenuFilePreferences.Index = 0
        Me.MenuFilePreferences.Text = "&Preferences.."
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 1
        Me.MenuItem3.Text = "-"
        '
        'MenuFileExit
        '
        Me.MenuFileExit.Index = 2
        Me.MenuFileExit.Text = "E&xit"
        '
        'MenuMail
        '
        Me.MenuMail.Index = 1
        Me.MenuMail.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuMailNewMessage, Me.MenuMailDelete, Me.MenuItem5, Me.MenuMailRefresh})
        Me.MenuMail.Text = "&Mail"
        '
        'MenuMailNewMessage
        '
        Me.MenuMailNewMessage.Index = 0
        Me.MenuMailNewMessage.Text = "&New Message.."
        '
        'MenuMailDelete
        '
        Me.MenuMailDelete.Index = 1
        Me.MenuMailDelete.Text = "&Delete"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 2
        Me.MenuItem5.Text = "-"
        '
        'MenuMailRefresh
        '
        Me.MenuMailRefresh.Index = 3
        Me.MenuMailRefresh.Text = "&Refresh"
        '
        'lvMail
        '
        Me.lvMail.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chFrom, Me.chSubject, Me.chDateReceived})
        Me.lvMail.Dock = System.Windows.Forms.DockStyle.Top
        Me.lvMail.FullRowSelect = True
        Me.lvMail.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvMail.Location = New System.Drawing.Point(0, 0)
        Me.lvMail.Name = "lvMail"
        Me.lvMail.Size = New System.Drawing.Size(488, 152)
        Me.lvMail.TabIndex = 1
        Me.lvMail.View = System.Windows.Forms.View.Details
        '
        'chFrom
        '
        Me.chFrom.Text = "From"
        Me.chFrom.Width = 140
        '
        'chSubject
        '
        Me.chSubject.Text = "Subject"
        Me.chSubject.Width = 180
        '
        'chDateReceived
        '
        Me.chDateReceived.Text = "Date Received"
        Me.chDateReceived.Width = 120
        '
        'SplitterHorizontal
        '
        Me.SplitterHorizontal.Dock = System.Windows.Forms.DockStyle.Top
        Me.SplitterHorizontal.Location = New System.Drawing.Point(0, 152)
        Me.SplitterHorizontal.Name = "SplitterHorizontal"
        Me.SplitterHorizontal.Size = New System.Drawing.Size(488, 3)
        Me.SplitterHorizontal.TabIndex = 2
        Me.SplitterHorizontal.TabStop = False
        '
        'pAttachments
        '
        Me.pAttachments.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pAttachments.Location = New System.Drawing.Point(0, 414)
        Me.pAttachments.Name = "pAttachments"
        Me.pAttachments.Size = New System.Drawing.Size(488, 24)
        Me.pAttachments.TabIndex = 4
        '
        'axwbMailBody
        '
        Me.axwbMailBody.Dock = System.Windows.Forms.DockStyle.Fill
        Me.axwbMailBody.Enabled = True
        Me.axwbMailBody.Location = New System.Drawing.Point(0, 155)
        Me.axwbMailBody.OcxState = CType(resources.GetObject("axwbMailBody.OcxState"), System.Windows.Forms.AxHost.State)
        Me.axwbMailBody.Size = New System.Drawing.Size(488, 259)
        Me.axwbMailBody.TabIndex = 5
        '
        'MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(488, 438)
        Me.Controls.Add(Me.axwbMailBody)
        Me.Controls.Add(Me.pAttachments)
        Me.Controls.Add(Me.SplitterHorizontal)
        Me.Controls.Add(Me.lvMail)
        Me.Menu = Me.MainMenu
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "JMailer"
        CType(Me.axwbMailBody, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' The JMail POP3 client class.
    Private m_pop3 As Pop3
    ' Regex for resolving content-id's in HTML e-mails.
    Private Shared m_regexInlineAttachments As New Regex("cid\:(?<cid>.+)", RegexOptions.Multiline Or RegexOptions.Compiled)

    ' This method binds the List View with Messages.
	Private Sub BindMessages()
        lvMail.BeginUpdate()
        lvMail.Items.Clear()

        Dim message As Dimac.JMail.Message

        ' loop all messages in POP3 Inbox
        For Each message In m_pop3.Inbox
            ' tidy from address / name
            Dim from As String
            If message.From.FullName Is Nothing Or message.From.FullName.Length = 0 Then
                from = message.From.Email
            Else
                from = message.From.FullName
            End If

            ' create list item
            Dim item As New ListViewItem(from)
            ' add values
            item.SubItems.Add(message.Subject)
            item.SubItems.Add(message.Date.ToString())

            ' add list item to list view control
            lvMail.Items.Add(item)
        Next

        lvMail.EndUpdate()
    End Sub

    ' Private helper method who cleans up file names.
    Private Shared Function FixPath(ByVal path As String) As String
        Return path.Replace("/", "_").Replace("\", "_").Replace(":", "_").Replace("*", "_").Replace("?", "_").Replace("""", "_").Replace("<", "_").Replace(">", "_").Replace("|", "_")
    End Function

    ' Clears the message view (the body and the attachment panel).
    Private Sub ClearMessage()
        axwbMailBody.Navigate("about:blank")
        pAttachments.Controls.Clear()
        pAttachments.Visible = False
    End Sub

   ' This method saves all inline attachments in the supplied message to a temporary directory and returns a hashtable with all the Content-ID's as keys and the temporary file path's as values.
    Private Function CreateTempInlineAttachments(ByVal msg As Dimac.JMail.Message, ByVal uidl As String) As Hashtable
        If msg.Attachments.Count > 0 Then
            Dim hasInline As Boolean = False
            Dim att As Attachment
            For Each att In msg.Attachments

                If Not att.ContentID Is Nothing AndAlso att.ContentID.Length > 0 AndAlso att.ContentDisposition.DispositionType = DispositionType.Inline Then
                    hasInline = True
                    'BREAK()
                End If
            Next


            If hasInline Then
                Dim attPath As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "temp\\" & FixPath(uidl))

                Dim exists As Boolean = Directory.Exists(attPath)

                If Not exists Then
                    Directory.CreateDirectory(attPath)
                End If

                Dim result As New Hashtable
                For Each att In msg.Attachments
                    If att.ContentDisposition.DispositionType = DispositionType.Inline Then
                        Dim cid As String = att.ContentID
                        If Not cid Is Nothing AndAlso cid.Length > 0 Then
                            Dim fileName As String = Path.Combine(attPath, FixPath(cid))
                            result.Add(cid, fileName)
                            If Not exists Then
                                att.Save(fileName)
                            End If
                        End If
                    End If
                Next
                Return result
            End If
        End If
        Return Nothing
    End Function

    ' File->Preferences menu
    Private Sub MenuFilePreferences_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuFilePreferences.Click
        Dim form As New PreferencesForm
        form.ShowDialog(Me)
    End Sub

    ' File->Exit menu
    Private Sub MenuFileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuFileExit.Click
        Application.Exit()
    End Sub

    ' Mail->New Message menu
    Private Sub MenuMailNewMessage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuMailNewMessage.Click
        Dim form As New NewMessageForm
        form.ShowDialog(Me)
    End Sub

    ' Mail->Delete menu. Deletes the selected message from the server.
	' Please note that you have to Close the current POP3 connection to commit the delete (use the Mail->Refresh menu).
	Private Sub MenuMailDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuMailDelete.Click
        If lvMail.SelectedIndices.Count > 0 AndAlso MessageBox.Show(Me, "Are you sure you want to delete the selected messages?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then
            Cursor = Cursors.WaitCursor
            Dim i As Integer
            For i = 0 To lvMail.SelectedIndices.Count - 1
                m_pop3.Inbox.DeleteMessageFromServer(lvMail.SelectedIndices(i))
            Next i
            Cursor = Cursors.Default
            ClearMessage()
            MessageBox.Show(Me, "Selected messages has been deleted, please refresh your inbox to see the changes.")
        End If
    End Sub

    ' Mail->Refresh menu
    Private Sub MenuMailRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuMailRefresh.Click
        Cursor = Cursors.WaitCursor

        ClearMessage()

        ' if we already got a pop3 connection - kill it.
        If Not m_pop3 Is Nothing Then
            m_pop3.Close()
        End If

        ' connect to the pop3 server as described in the config settings.
        m_pop3 = New Pop3(Config.Singleton.GetValue("pop3.hostname", "localhost"), Short.Parse(Config.Singleton.GetValue("pop3.port", "110")), Config.Singleton.GetValue("pop3.username", ""), Config.Singleton.GetValue("pop3.password", ""))

        ' display the messages in our list view.
        BindMessages()

        Cursor = Cursors.Default
    End Sub

    ' initializes the form
    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim tempPath As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "temp")

        If Not Directory.Exists(tempPath) Then
            Directory.CreateDirectory(tempPath)
        End If

        ClearMessage()
    End Sub

    ' This method is called when a message is selected in the list view.
    Private Sub lvMail_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvMail.SelectedIndexChanged
        ' if we for some odd reason hasn't got any seleted message - return back.
        If lvMail.SelectedIndices.Count = 0 Then
            Return
        End If

        Cursor = Cursors.WaitCursor

        Dim index As Integer = lvMail.SelectedIndices(0)

        If index >= 0 AndAlso index < m_pop3.Inbox.Count Then
            ' download the FULL message (headers AND body AND attachments) from the server.
            ' this might take a WHILE..
            Dim msg As Dimac.JMail.Message = m_pop3.Inbox.DownloadFullMessage(index)

            ' if the message is null for some reason,
            ' clear the form and return.
            If msg Is Nothing Then
                ClearMessage()
                Cursor = Cursors.Default
                Return
            End If

            ' get the uidl for this message from the POP3 server.
            Dim uidl As String = m_pop3.Inbox.Uidl(index)

            ' temporarily save inline attachments (if there are any).
            Dim inline As Hashtable = CreateTempInlineAttachments(msg, uidl)

            ' clear body
            axwbMailBody.Navigate("about:blank")
            ' get document object to write to body
            Dim doc As IHTMLDocument2 = axwbMailBody.Document

            ' write standard headers,
            ' such as From, Subject, Date and so on.
            doc.write("<html><body>")
            doc.write("<strong>From:</strong> " & HttpUtility.HtmlEncode(msg.From.ToString()) & "<br>")
            doc.write("<strong>Subject:</strong> " & HttpUtility.HtmlEncode(msg.Subject) & "<br>")
            doc.write("<strong>Date:</strong> " & msg.Date.ToString() & "<br>")
            doc.write("<strong>To:</strong> " & HttpUtility.HtmlEncode(msg.To.ToString()) & "<br>")
            If msg.Cc.Count > 0 Then
                doc.write("<strong>CC:</strong> " & HttpUtility.HtmlEncode(msg.Cc.ToString()) & "<br>")
            End If
            If msg.Bcc.Count > 0 Then
                doc.write("<strong>BCC:</strong> " & HttpUtility.HtmlEncode(msg.Bcc.ToString()) & "<br>")
            End If

            Dim p As Priority = msg.Priority
            If p <> Priority.None Then
                doc.write("<strong>Priority:</strong> " & p.ToString() & "<br>")
            End If
            doc.write("<hr></body></html>")

            ' handle html body
            Dim hasHtml As Boolean = False
            If msg.BodyHtml.Length > 0 Then
                Dim html As String = msg.BodyHtml
                ' if we have any inline messages, we have to look for them in the HTML body and replace them with a real url.
                If Not inline Is Nothing Then
                    ' foreach content-id in inline attachments
                    Dim cid As String
                    For Each cid In inline.Keys
                        ' use regex to replace it with a real url.
                        html = html.Replace("cid:" & cid, CStr(inline(cid)))
                    Next
                End If

                ' write html to document
                doc.write(html)
                hasHtml = True
            Else
                doc.write("<html><body></body></html>")
            End If

            ' handle text body if there is any
            If msg.BodyText.Length > 0 Then
                doc.write("<html><body>")
                If hasHtml Then
                    doc.write("<hr>")
                    doc.write("<pre>" & HttpUtility.HtmlEncode(msg.BodyText) & "</pre></body></html>")
                End If
            End If

            ' print attachments for saving to disk
            pAttachments.Visible = msg.Attachments.Count > 0
            If pAttachments.Visible Then
                pAttachments.Controls.Clear()
                Dim left As Integer = 4
                Dim att As Attachment
                For Each att In msg.Attachments

                    Dim lbl As LinkLabel = New LinkLabel
                    lbl.Name = "lAtt" & Guid.NewGuid().ToString("n")
                    pAttachments.Controls.Add(lbl)
                    lbl.Text = att.FileName
                    lbl.AutoSize = True
                    lbl.Tag = att
                    lbl.Top = 4
                    lbl.Left = left
                    AddHandler lbl.Click, AddressOf lbl_Click
                    left += lbl.Width
                Next
            Else

                pAttachments.Controls.Clear()
                pAttachments.Visible = False
            End If

            axwbMailBody.Invalidate()
            axwbMailBody.CtlRefresh()

            lvMail.Focus()
        End If

        Cursor = Cursors.Default
    End Sub

    ' Handles the event that's fired when an attachment is clicked. Displays the save file dialog.
    Private Sub lbl_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim lbl As LinkLabel = sender
        Dim att As Attachment = lbl.Tag

        SaveFileDialog.FileName = att.FileName
        If SaveFileDialog.ShowDialog(Me) = DialogResult.OK Then
            att.Save(SaveFileDialog.FileName)
        End If
    End Sub
End Class
