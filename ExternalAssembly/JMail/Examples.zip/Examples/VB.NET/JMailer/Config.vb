' Simple utility class for handling application configuration.
' Please not that this class has nothing to do with jmail - It's just for this example.
Public Class Config
	' We only want one instance of this class.
    Public Shared Singleton As New Config

		' Contains the application settings.
    Private m_settings As NameValueCollection

    ' Private constructor since we only want one instance.
    ' The Config class automatically loads settings directly when initialized.
    ' Be ware of that this constructor might throw an exception if the data in the config file is invalid.
    Private Sub New()
        m_settings = New NameValueCollection

        If File.Exists(FileName) Then
            Dim Xml As New XmlDocument
            Xml.Load(FileName)
            Dim node As XmlNode
            For Each node In Xml.DocumentElement.ChildNodes
                m_settings.Add(node.Name, node.InnerText)
            Next
        End If
    End Sub

    ' Saves the settings to an xml-file.
    Public Sub Save()
        Dim writer As New StreamWriter(FileName, False, Encoding.UTF8)
        Dim xml As New XmlTextWriter(writer)

        xml.WriteStartDocument()
        xml.WriteStartElement("configuration")

        Dim name As String
        For Each name In m_settings.AllKeys
            xml.WriteStartElement(name)
            xml.WriteString(m_settings(name))
            xml.WriteEndElement()
        Next

        xml.WriteEndElement()
        xml.WriteEndDocument()
        xml.Close()
        writer.Close()
    End Sub

    ' Gets a value from the settings.
    Public Function GetValue(ByVal name As String, ByVal defaultValue As String) As String
        Dim s As String = m_settings(name)
        If s Is Nothing Then
            Return defaultValue
        End If
        Return s
    End Function

    'Sets the value in the settings.
    Public Sub SetValue(ByVal name As String, ByVal value As String)
        m_settings(name) = value
    End Sub

    ' Config file name.		
    Public ReadOnly Property FileName()
        Get
            Return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "jmailer.config")
        End Get
    End Property
End Class
