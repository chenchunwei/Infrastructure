Public Class NewMessageForm
    Inherits System.Windows.Forms.Form

   ' Contains common charsets (for use in this form).    
    Private Shared charsets As Hashtable

    ' Static constructor makes sure that we only load available charsets once per application.
    Shared Sub New()
        charsets = New Hashtable
        Dim ciList As CultureInfo() = CultureInfo.GetCultures(CultureTypes.InstalledWin32Cultures)
        For Each ci As CultureInfo In ciList
            Try
                Dim enc As Encoding = Encoding.GetEncoding(ci.TextInfo.ANSICodePage)
                If Not charsets.ContainsKey(enc.CodePage) Then
                    charsets.Add(enc.CodePage, enc.BodyName)
                End If
            Catch
            End Try
        Next

        If Not charsets.ContainsKey(Encoding.UTF8.CodePage) Then
            charsets.Add(Encoding.UTF8.CodePage, Encoding.UTF8.BodyName)
        End If

        If Not charsets.ContainsKey(Encoding.ASCII.CodePage) Then
            charsets.Add(Encoding.ASCII.CodePage, Encoding.ASCII.BodyName)
        End If

        If Not charsets.ContainsKey(Encoding.Default.CodePage) Then
            charsets.Add(Encoding.Default.CodePage, Encoding.Default.BodyName)
        End If
    End Sub

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents tabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents tbBodyText As System.Windows.Forms.TextBox
    Friend WithEvents tabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents tbBodyHtml As System.Windows.Forms.TextBox
    Friend WithEvents tabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents bRemoveAttachment As System.Windows.Forms.Button
    Friend WithEvents bAddAttachment As System.Windows.Forms.Button
    Friend WithEvents tbAttPath As System.Windows.Forms.TextBox
    Friend WithEvents tbAttCID As System.Windows.Forms.TextBox
    Friend WithEvents cbAttInline As System.Windows.Forms.CheckBox
    Friend WithEvents label8 As System.Windows.Forms.Label
    Friend WithEvents label7 As System.Windows.Forms.Label
    Friend WithEvents lbAttachments As System.Windows.Forms.ListBox
    Friend WithEvents cbCharset As System.Windows.Forms.ComboBox
    Friend WithEvents label6 As System.Windows.Forms.Label
    Friend WithEvents bCancel As System.Windows.Forms.Button
    Friend WithEvents bSend As System.Windows.Forms.Button
    Friend WithEvents tbSubject As System.Windows.Forms.TextBox
    Friend WithEvents tbBcc As System.Windows.Forms.TextBox
    Friend WithEvents tbCc As System.Windows.Forms.TextBox
    Friend WithEvents tbTo As System.Windows.Forms.TextBox
    Friend WithEvents cbPriority As System.Windows.Forms.ComboBox
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents openFileDialog As System.Windows.Forms.OpenFileDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.tabControl1 = New System.Windows.Forms.TabControl
        Me.tabPage1 = New System.Windows.Forms.TabPage
        Me.tbBodyText = New System.Windows.Forms.TextBox
        Me.tabPage2 = New System.Windows.Forms.TabPage
        Me.tbBodyHtml = New System.Windows.Forms.TextBox
        Me.tabPage3 = New System.Windows.Forms.TabPage
        Me.bRemoveAttachment = New System.Windows.Forms.Button
        Me.bAddAttachment = New System.Windows.Forms.Button
        Me.tbAttPath = New System.Windows.Forms.TextBox
        Me.tbAttCID = New System.Windows.Forms.TextBox
        Me.cbAttInline = New System.Windows.Forms.CheckBox
        Me.label8 = New System.Windows.Forms.Label
        Me.label7 = New System.Windows.Forms.Label
        Me.lbAttachments = New System.Windows.Forms.ListBox
        Me.cbCharset = New System.Windows.Forms.ComboBox
        Me.label6 = New System.Windows.Forms.Label
        Me.bCancel = New System.Windows.Forms.Button
        Me.bSend = New System.Windows.Forms.Button
        Me.tbSubject = New System.Windows.Forms.TextBox
        Me.tbBcc = New System.Windows.Forms.TextBox
        Me.tbCc = New System.Windows.Forms.TextBox
        Me.tbTo = New System.Windows.Forms.TextBox
        Me.cbPriority = New System.Windows.Forms.ComboBox
        Me.label5 = New System.Windows.Forms.Label
        Me.label4 = New System.Windows.Forms.Label
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.openFileDialog = New System.Windows.Forms.OpenFileDialog
        Me.tabControl1.SuspendLayout()
        Me.tabPage1.SuspendLayout()
        Me.tabPage2.SuspendLayout()
        Me.tabPage3.SuspendLayout()
        Me.SuspendLayout()
        '
        'tabControl1
        '
        Me.tabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tabControl1.Controls.Add(Me.tabPage1)
        Me.tabControl1.Controls.Add(Me.tabPage2)
        Me.tabControl1.Controls.Add(Me.tabPage3)
        Me.tabControl1.Location = New System.Drawing.Point(8, 152)
        Me.tabControl1.Name = "tabControl1"
        Me.tabControl1.SelectedIndex = 0
        Me.tabControl1.Size = New System.Drawing.Size(400, 200)
        Me.tabControl1.TabIndex = 30
        '
        'tabPage1
        '
        Me.tabPage1.Controls.Add(Me.tbBodyText)
        Me.tabPage1.Location = New System.Drawing.Point(4, 22)
        Me.tabPage1.Name = "tabPage1"
        Me.tabPage1.Size = New System.Drawing.Size(392, 174)
        Me.tabPage1.TabIndex = 0
        Me.tabPage1.Text = "Text Body"
        '
        'tbBodyText
        '
        Me.tbBodyText.AcceptsReturn = True
        Me.tbBodyText.AcceptsTab = True
        Me.tbBodyText.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tbBodyText.Location = New System.Drawing.Point(0, 0)
        Me.tbBodyText.Multiline = True
        Me.tbBodyText.Name = "tbBodyText"
        Me.tbBodyText.Size = New System.Drawing.Size(392, 174)
        Me.tbBodyText.TabIndex = 0
        Me.tbBodyText.Text = ""
        '
        'tabPage2
        '
        Me.tabPage2.Controls.Add(Me.tbBodyHtml)
        Me.tabPage2.Location = New System.Drawing.Point(4, 22)
        Me.tabPage2.Name = "tabPage2"
        Me.tabPage2.Size = New System.Drawing.Size(392, 174)
        Me.tabPage2.TabIndex = 1
        Me.tabPage2.Text = "HTML Body"
        Me.tabPage2.Visible = False
        '
        'tbBodyHtml
        '
        Me.tbBodyHtml.AcceptsReturn = True
        Me.tbBodyHtml.AcceptsTab = True
        Me.tbBodyHtml.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tbBodyHtml.Location = New System.Drawing.Point(0, 0)
        Me.tbBodyHtml.Multiline = True
        Me.tbBodyHtml.Name = "tbBodyHtml"
        Me.tbBodyHtml.Size = New System.Drawing.Size(392, 174)
        Me.tbBodyHtml.TabIndex = 1
        Me.tbBodyHtml.Text = ""
        '
        'tabPage3
        '
        Me.tabPage3.Controls.Add(Me.bRemoveAttachment)
        Me.tabPage3.Controls.Add(Me.bAddAttachment)
        Me.tabPage3.Controls.Add(Me.tbAttPath)
        Me.tabPage3.Controls.Add(Me.tbAttCID)
        Me.tabPage3.Controls.Add(Me.cbAttInline)
        Me.tabPage3.Controls.Add(Me.label8)
        Me.tabPage3.Controls.Add(Me.label7)
        Me.tabPage3.Controls.Add(Me.lbAttachments)
        Me.tabPage3.Location = New System.Drawing.Point(4, 22)
        Me.tabPage3.Name = "tabPage3"
        Me.tabPage3.Size = New System.Drawing.Size(392, 174)
        Me.tabPage3.TabIndex = 2
        Me.tabPage3.Text = "Attachments"
        Me.tabPage3.Visible = False
        '
        'bRemoveAttachment
        '
        Me.bRemoveAttachment.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.bRemoveAttachment.Location = New System.Drawing.Point(80, 144)
        Me.bRemoveAttachment.Name = "bRemoveAttachment"
        Me.bRemoveAttachment.Size = New System.Drawing.Size(64, 23)
        Me.bRemoveAttachment.TabIndex = 7
        Me.bRemoveAttachment.Text = "Remove"
        '
        'bAddAttachment
        '
        Me.bAddAttachment.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.bAddAttachment.Location = New System.Drawing.Point(8, 144)
        Me.bAddAttachment.Name = "bAddAttachment"
        Me.bAddAttachment.Size = New System.Drawing.Size(64, 23)
        Me.bAddAttachment.TabIndex = 6
        Me.bAddAttachment.Text = "Add"
        '
        'tbAttPath
        '
        Me.tbAttPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbAttPath.Enabled = False
        Me.tbAttPath.Location = New System.Drawing.Point(216, 16)
        Me.tbAttPath.Name = "tbAttPath"
        Me.tbAttPath.Size = New System.Drawing.Size(160, 20)
        Me.tbAttPath.TabIndex = 5
        Me.tbAttPath.Text = ""
        '
        'tbAttCID
        '
        Me.tbAttCID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbAttCID.Location = New System.Drawing.Point(216, 56)
        Me.tbAttCID.Name = "tbAttCID"
        Me.tbAttCID.Size = New System.Drawing.Size(160, 20)
        Me.tbAttCID.TabIndex = 4
        Me.tbAttCID.Text = ""
        '
        'cbAttInline
        '
        Me.cbAttInline.Location = New System.Drawing.Point(152, 32)
        Me.cbAttInline.Name = "cbAttInline"
        Me.cbAttInline.Size = New System.Drawing.Size(56, 24)
        Me.cbAttInline.TabIndex = 3
        Me.cbAttInline.Text = "Inline"
        '
        'label8
        '
        Me.label8.Location = New System.Drawing.Point(152, 56)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(64, 16)
        Me.label8.TabIndex = 2
        Me.label8.Text = "Content-ID:"
        '
        'label7
        '
        Me.label7.Location = New System.Drawing.Point(152, 16)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(48, 16)
        Me.label7.TabIndex = 1
        Me.label7.Text = "Path:"
        '
        'lbAttachments
        '
        Me.lbAttachments.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lbAttachments.Location = New System.Drawing.Point(8, 8)
        Me.lbAttachments.Name = "lbAttachments"
        Me.lbAttachments.Size = New System.Drawing.Size(136, 134)
        Me.lbAttachments.TabIndex = 0
        '
        'cbCharset
        '
        Me.cbCharset.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cbCharset.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCharset.Location = New System.Drawing.Point(56, 128)
        Me.cbCharset.Name = "cbCharset"
        Me.cbCharset.Size = New System.Drawing.Size(352, 21)
        Me.cbCharset.TabIndex = 26
        '
        'label6
        '
        Me.label6.Location = New System.Drawing.Point(8, 128)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(48, 16)
        Me.label6.TabIndex = 29
        Me.label6.Text = "Charset:"
        '
        'bCancel
        '
        Me.bCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.bCancel.Location = New System.Drawing.Point(248, 360)
        Me.bCancel.Name = "bCancel"
        Me.bCancel.TabIndex = 28
        Me.bCancel.Text = "Cancel"
        '
        'bSend
        '
        Me.bSend.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.bSend.Location = New System.Drawing.Point(328, 360)
        Me.bSend.Name = "bSend"
        Me.bSend.TabIndex = 27
        Me.bSend.Text = "Send"
        '
        'tbSubject
        '
        Me.tbSubject.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbSubject.Location = New System.Drawing.Point(56, 80)
        Me.tbSubject.Name = "tbSubject"
        Me.tbSubject.Size = New System.Drawing.Size(352, 20)
        Me.tbSubject.TabIndex = 23
        Me.tbSubject.Text = ""
        '
        'tbBcc
        '
        Me.tbBcc.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbBcc.Location = New System.Drawing.Point(56, 56)
        Me.tbBcc.Name = "tbBcc"
        Me.tbBcc.Size = New System.Drawing.Size(352, 20)
        Me.tbBcc.TabIndex = 21
        Me.tbBcc.Text = ""
        '
        'tbCc
        '
        Me.tbCc.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbCc.Location = New System.Drawing.Point(56, 32)
        Me.tbCc.Name = "tbCc"
        Me.tbCc.Size = New System.Drawing.Size(352, 20)
        Me.tbCc.TabIndex = 19
        Me.tbCc.Text = ""
        '
        'tbTo
        '
        Me.tbTo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbTo.Location = New System.Drawing.Point(56, 8)
        Me.tbTo.Name = "tbTo"
        Me.tbTo.Size = New System.Drawing.Size(352, 20)
        Me.tbTo.TabIndex = 17
        Me.tbTo.Text = ""
        '
        'cbPriority
        '
        Me.cbPriority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbPriority.Location = New System.Drawing.Point(56, 104)
        Me.cbPriority.Name = "cbPriority"
        Me.cbPriority.Size = New System.Drawing.Size(128, 21)
        Me.cbPriority.TabIndex = 25
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(8, 56)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(40, 16)
        Me.label5.TabIndex = 24
        Me.label5.Text = "Bcc:"
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(8, 32)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(32, 16)
        Me.label4.TabIndex = 22
        Me.label4.Text = "Cc:"
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(8, 104)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(48, 16)
        Me.label3.TabIndex = 20
        Me.label3.Text = "Priority:"
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(8, 80)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(48, 16)
        Me.label2.TabIndex = 18
        Me.label2.Text = "Subject:"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 8)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(48, 16)
        Me.label1.TabIndex = 16
        Me.label1.Text = "To:"
        '
        'openFileDialog
        '
        Me.openFileDialog.Filter = "All Files (*.*)|*.*"
        '
        'NewMessageForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(416, 390)
        Me.Controls.Add(Me.tabControl1)
        Me.Controls.Add(Me.cbCharset)
        Me.Controls.Add(Me.label6)
        Me.Controls.Add(Me.bCancel)
        Me.Controls.Add(Me.bSend)
        Me.Controls.Add(Me.tbSubject)
        Me.Controls.Add(Me.tbBcc)
        Me.Controls.Add(Me.tbCc)
        Me.Controls.Add(Me.tbTo)
        Me.Controls.Add(Me.cbPriority)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.MinimumSize = New System.Drawing.Size(424, 424)
        Me.Name = "NewMessageForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Compose Mail.."
        Me.tabControl1.ResumeLayout(False)
        Me.tabPage1.ResumeLayout(False)
        Me.tabPage2.ResumeLayout(False)
        Me.tabPage3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' Initializes the form, loads Priorities and charsets.
    Private Sub NewMessageForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cbPriority.DataSource = [Enum].GetValues(GetType(Priority))

        For Each codePage As Integer In charsets.Keys
            cbCharset.Items.Add(charsets(codePage))
        Next

        cbCharset.SelectedIndex = cbCharset.Items.IndexOf(Encoding.Default.BodyName)

        tbAttCID.Enabled = False
    End Sub

    ' Closes the form without sending the e-mail message.
    Private Sub bCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bCancel.Click
        Close()
    End Sub

    ' Sends an e-mail message and closes the form.
    Private Sub bSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bSend.Click
        Try

            ' create a JMail Message
            Dim message As New Dimac.JMail.Message

            ' set the From: adress (get it from the configuration file)
            message.From.FullName = Config.Singleton.GetValue("smtp.fullname", "")
            message.From.Email = Config.Singleton.GetValue("smtp.email", "")

            ' set the To: recipients, get value from the textbox in the form
            Dim temp As String() = tbTo.Text.Split(";,".ToCharArray())
            For Each s As String In temp
                If s.Trim().Length > 0 Then
                    message.To.Add(Address.Parse(s.Trim()))
                End If
            Next

            ' set the Cc: recipients, get value from the textbox in the form
            temp = tbTo.Text.Split(";,".ToCharArray())
            For Each s As String In temp
                If s.Trim().Length > 0 Then
                    message.Cc.Add(Address.Parse(s.Trim()))
                End If
            Next

            ' set the Bcc: recipients, get value from the textbox in the form
            temp = tbTo.Text.Split(";,".ToCharArray())
            For Each s As String In temp
                If s.Trim().Length > 0 Then
                    message.Bcc.Add(Address.Parse(s.Trim()))
                End If
            Next

            ' set the Subject, get value from the textbox in the form
            message.Subject = tbSubject.Text

            ' set the message Priority, get value from the form
            If cbPriority.SelectedIndex > 0 Then
                message.Priority = cbPriority.SelectedValue
            End If

            ' set message charset, get value from he form
            message.Charset = Encoding.GetEncoding(cbCharset.SelectedItem.ToString())

            ' set HTML and TEXT body's from form
            message.BodyText = tbBodyText.Text
            message.BodyHtml = tbBodyHtml.Text

            ' add attachments
            For Each file As LocalAttachedFile In lbAttachments.Items				
                If file.Inline Then
                    message.Attachments.AddInlineAttachment(file.Path, file.ContentId)
                Else
                    message.Attachments.Add(file.Path)
                End If
            Next


            ' make sure that we have at least one recipient
            If message.To.Count < 0 AndAlso message.Cc.Count < 0 AndAlso message.Bcc.Count < 0 Then
                Throw New Exception("No recipients was supplied.")
            End If

            ' get HELO domain from senders e-mail address
            ' WARNING: this might not work for all mail servers, but the odds are good that it will.
            Dim heloDomain As String = Nothing
            If Not message.From.Email Is Nothing AndAlso message.From.Email.Length > 0 Then
                Dim idx As Integer = message.From.Email.IndexOf("@")
                If idx <> -1 Then
                    heloDomain = message.From.Email.Substring(idx + 1)
                End If
            End If

            ' send the message using configuration settings
            Smtp.Send(message, Config.Singleton.GetValue("smtp.hostname", "localhost"), Short.Parse(Config.Singleton.GetValue("smtp.port", "25")), heloDomain, [Enum].Parse(GetType(SmtpAuthentication), Config.Singleton.GetValue("smtp.authentication", "None")), Config.Singleton.GetValue("smtp.username", ""), Config.Singleton.GetValue("smtp.password", ""))

            Close()
        Catch ex As Exception			
            ' on exceptions - popup a messagebox displaying error message
            MessageBox.Show(Me, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Adds an attachment
    Private Sub bAddAttachment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bAddAttachment.Click
        If openFileDialog.ShowDialog(Me) = DialogResult.OK Then
            Try
                Dim file As LocalAttachedFile = New LocalAttachedFile(openFileDialog.FileName)
                lbAttachments.BeginUpdate()
                lbAttachments.Items.Add(file)
                lbAttachments.EndUpdate()
            Catch ex As Exception
                MessageBox.Show(Me, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    ' Removes an attachment
    Private Sub bRemoveAttachment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bRemoveAttachment.Click
        If lbAttachments.SelectedIndex >= 0 AndAlso lbAttachments.SelectedIndex < lbAttachments.Items.Count Then
            lbAttachments.BeginUpdate()
            lbAttachments.Items.RemoveAt(lbAttachments.SelectedIndex)
            lbAttachments.EndUpdate()
        End If
    End Sub

    ' Set up attachment form for editing selected attachment
    Private Sub lbAttachments_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbAttachments.SelectedIndexChanged
        If lbAttachments.SelectedIndex >= 0 AndAlso lbAttachments.SelectedIndex < lbAttachments.Items.Count Then
            Dim file As LocalAttachedFile = lbAttachments.SelectedItem
            If Not file Is Nothing Then
                tbAttPath.Text = file.Path
                tbAttCID.Enabled = file.Inline
                cbAttInline.Checked = file.Inline
                tbAttCID.Text = file.ContentId
            End If
        End If
    End Sub

    ' On inline checked-changed
    Private Sub cbAttInline_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbAttInline.CheckedChanged
        tbAttCID.Enabled = cbAttInline.Checked
        If lbAttachments.SelectedIndex >= 0 AndAlso lbAttachments.SelectedIndex < lbAttachments.Items.Count Then
            Dim file As LocalAttachedFile = lbAttachments.SelectedItem
            If Not file Is Nothing Then
                file.Inline = cbAttInline.Checked
            End If
        End If
    End Sub

    ' On content-id-changed
    Private Sub tbAttCID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbAttCID.TextChanged
        If lbAttachments.SelectedIndex >= 0 AndAlso lbAttachments.SelectedIndex < lbAttachments.Items.Count Then
            Dim file As LocalAttachedFile = lbAttachments.SelectedItem
            If Not file Is Nothing Then
                file.ContentId = tbAttCID.Text
            End If
        End If
    End Sub
End Class
