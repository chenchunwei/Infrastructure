' Private class representing an attached file to send in a message.	
' Please not that this class has nothing to do with jmail - It's just for this example.	
Public Class LocalAttachedFile
    ' Path of the file to attach.
    Private m_path As String
    ' Boolean telling us if this is an inline attachment or not.
    Private m_inline As Boolean
    ' If this is an inline file, we want a content-id, this is it.	
    Private m_contentId As String

    ' Constructor. Creates a new attachment.
    Public Sub New(ByVal path As String)
        If Not File.Exists(path) Then
            Throw New FileNotFoundException
        End If

        m_path = path
        m_inline = False
        m_contentId = Nothing
    End Sub

    ' Constructor. Creates a new attachment.
    Public Sub New(ByVal path As String, ByVal inline As Boolean, ByVal contentId As String)
        m_path = path
        m_inline = inline
        If m_inline Then
            m_contentId = contentId
        Else
            m_contentId = Nothing
        End If
    End Sub

    'Gets and sets the path of the file to add.
    Public Property Path() As String
        Get
            Return m_path
        End Get
        Set(ByVal Value As String)
            If Not File.Exists(Value) Then
                Throw New FileNotFoundException
            End If
            m_path = Value
        End Set
    End Property

    ' Gets and sets the inline value.
    Public Property Inline() As Boolean
        Get
            Return m_inline
        End Get
        Set(ByVal Value As Boolean)
            m_inline = Value
            If Not Value Then
                m_contentId = Nothing
            End If
        End Set
    End Property

    ' Gets and sets the content-id.
    Public Property ContentId() As String
        Get
            Return m_contentId
        End Get
        Set(ByVal Value As String)
            If m_inline Then
                m_contentId = Value
            End If
        End Set
    End Property

    Public Overrides Function ToString() As String
        Return m_path
    End Function
End Class