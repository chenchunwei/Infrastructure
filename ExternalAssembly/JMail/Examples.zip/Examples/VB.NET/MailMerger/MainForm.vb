Public Class MainForm
    Inherits System.Windows.Forms.Form

    Private m_file As New MailMergeFile

   ' Contains common charsets (for use in this form).
    Shared charsets As Hashtable

    ' Static constructor makes sure that we only load available charsets once per application.
    Shared Sub New()
        charsets = New Hashtable
        Dim ciList As CultureInfo() = CultureInfo.GetCultures(CultureTypes.InstalledWin32Cultures)
        For Each ci As CultureInfo In ciList
            Try
                Dim enc As Encoding = Encoding.GetEncoding(ci.TextInfo.ANSICodePage)
                If Not charsets.ContainsKey(enc.CodePage) Then
                    charsets.Add(enc.CodePage, enc.BodyName)
                End If
				catch
            End Try
        Next

        If Not charsets.ContainsKey(Encoding.UTF8.CodePage) Then
            charsets.Add(Encoding.UTF8.CodePage, Encoding.UTF8.BodyName)
        End If

        If Not charsets.ContainsKey(Encoding.ASCII.CodePage) Then
            charsets.Add(Encoding.ASCII.CodePage, Encoding.ASCII.BodyName)
        End If

        If Not charsets.ContainsKey(Encoding.Default.CodePage) Then
            charsets.Add(Encoding.Default.CodePage, Encoding.Default.BodyName)
        End If
    End Sub

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        ' fill combobox with valid priorities
        cbPriority.DataSource = [Enum].GetValues(GetType(Priority))

        ' fill combobox with valid authentications
        cbAuthentication.DataSource = [Enum].GetValues(GetType(SmtpAuthentication))

        rbOutputDirectory.Checked = True

        ' add valid charsets to combobox
        For Each codePage As Integer In charsets.Keys
            cbCharset.Items.Add(charsets(codePage))
        Next
        cbCharset.SelectedIndex = cbCharset.Items.IndexOf(Encoding.Default.BodyName)
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents saveFileDialog As System.Windows.Forms.SaveFileDialog
    Friend WithEvents attFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents openFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents mainMenu As System.Windows.Forms.MainMenu
    Friend WithEvents menuFile As System.Windows.Forms.MenuItem
    Friend WithEvents menuFileNew As System.Windows.Forms.MenuItem
    Friend WithEvents menuFileOpen As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents menuFileSave As System.Windows.Forms.MenuItem
    Friend WithEvents menuFileSaveAs As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents menuFileExit As System.Windows.Forms.MenuItem
    Friend WithEvents tabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents tbFromName As System.Windows.Forms.TextBox
    Friend WithEvents tbFromAddress As System.Windows.Forms.TextBox
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents tbToName As System.Windows.Forms.TextBox
    Friend WithEvents tabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents tabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents tbBodyText As System.Windows.Forms.TextBox
    Friend WithEvents tabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents tbBodyHtml As System.Windows.Forms.TextBox
    Friend WithEvents tabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents bRemoveAttachment As System.Windows.Forms.Button
    Friend WithEvents bAddAttachment As System.Windows.Forms.Button
    Friend WithEvents tbAttPath As System.Windows.Forms.TextBox
    Friend WithEvents tbAttCID As System.Windows.Forms.TextBox
    Friend WithEvents cbAttInline As System.Windows.Forms.CheckBox
    Friend WithEvents label8 As System.Windows.Forms.Label
    Friend WithEvents label7 As System.Windows.Forms.Label
    Friend WithEvents lbAttachments As System.Windows.Forms.ListBox
    Friend WithEvents cbCharset As System.Windows.Forms.ComboBox
    Friend WithEvents label6 As System.Windows.Forms.Label
    Friend WithEvents tbSubject As System.Windows.Forms.TextBox
    Friend WithEvents tbToAdress As System.Windows.Forms.TextBox
    Friend WithEvents cbPriority As System.Windows.Forms.ComboBox
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents tabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents bTestSQL As System.Windows.Forms.Button
    Friend WithEvents tbSql As System.Windows.Forms.TextBox
    Friend WithEvents label9 As System.Windows.Forms.Label
    Friend WithEvents bTestConnection As System.Windows.Forms.Button
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents tbConnectionString As System.Windows.Forms.TextBox
    Friend WithEvents tabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents tbSmtpHelo As System.Windows.Forms.TextBox
    Friend WithEvents label15 As System.Windows.Forms.Label
    Friend WithEvents cbAuthentication As System.Windows.Forms.ComboBox
    Friend WithEvents label10 As System.Windows.Forms.Label
    Friend WithEvents tbSmtpPassword As System.Windows.Forms.TextBox
    Friend WithEvents tbSmtpUserName As System.Windows.Forms.TextBox
    Friend WithEvents label11 As System.Windows.Forms.Label
    Friend WithEvents label12 As System.Windows.Forms.Label
    Friend WithEvents label13 As System.Windows.Forms.Label
    Friend WithEvents tbSmtpPort As System.Windows.Forms.TextBox
    Friend WithEvents tbSmtpHostName As System.Windows.Forms.TextBox
    Friend WithEvents label14 As System.Windows.Forms.Label
    Friend WithEvents rbSmtp As System.Windows.Forms.RadioButton
    Friend WithEvents rbOutputDirectory As System.Windows.Forms.RadioButton
    Friend WithEvents tbOutputDirectory As System.Windows.Forms.TextBox
    Friend WithEvents tabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents bGenerate As System.Windows.Forms.Button
    Friend WithEvents cbIsTest As System.Windows.Forms.CheckBox
    Friend WithEvents progressBar As System.Windows.Forms.ProgressBar
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.saveFileDialog = New System.Windows.Forms.SaveFileDialog
        Me.attFileDialog = New System.Windows.Forms.OpenFileDialog
        Me.openFileDialog = New System.Windows.Forms.OpenFileDialog
        Me.mainMenu = New System.Windows.Forms.MainMenu
        Me.menuFile = New System.Windows.Forms.MenuItem
        Me.menuFileNew = New System.Windows.Forms.MenuItem
        Me.menuFileOpen = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.menuFileSave = New System.Windows.Forms.MenuItem
        Me.menuFileSaveAs = New System.Windows.Forms.MenuItem
        Me.menuItem4 = New System.Windows.Forms.MenuItem
        Me.menuFileExit = New System.Windows.Forms.MenuItem
        Me.tabControl1 = New System.Windows.Forms.TabControl
        Me.tabPage1 = New System.Windows.Forms.TabPage
        Me.tbFromName = New System.Windows.Forms.TextBox
        Me.tbFromAddress = New System.Windows.Forms.TextBox
        Me.label4 = New System.Windows.Forms.Label
        Me.tbToName = New System.Windows.Forms.TextBox
        Me.tabControl2 = New System.Windows.Forms.TabControl
        Me.tabPage2 = New System.Windows.Forms.TabPage
        Me.tbBodyText = New System.Windows.Forms.TextBox
        Me.tabPage3 = New System.Windows.Forms.TabPage
        Me.tbBodyHtml = New System.Windows.Forms.TextBox
        Me.tabPage4 = New System.Windows.Forms.TabPage
        Me.bRemoveAttachment = New System.Windows.Forms.Button
        Me.bAddAttachment = New System.Windows.Forms.Button
        Me.tbAttPath = New System.Windows.Forms.TextBox
        Me.tbAttCID = New System.Windows.Forms.TextBox
        Me.cbAttInline = New System.Windows.Forms.CheckBox
        Me.label8 = New System.Windows.Forms.Label
        Me.label7 = New System.Windows.Forms.Label
        Me.lbAttachments = New System.Windows.Forms.ListBox
        Me.cbCharset = New System.Windows.Forms.ComboBox
        Me.label6 = New System.Windows.Forms.Label
        Me.tbSubject = New System.Windows.Forms.TextBox
        Me.tbToAdress = New System.Windows.Forms.TextBox
        Me.cbPriority = New System.Windows.Forms.ComboBox
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.tabPage5 = New System.Windows.Forms.TabPage
        Me.bTestSQL = New System.Windows.Forms.Button
        Me.tbSql = New System.Windows.Forms.TextBox
        Me.label9 = New System.Windows.Forms.Label
        Me.bTestConnection = New System.Windows.Forms.Button
        Me.label5 = New System.Windows.Forms.Label
        Me.tbConnectionString = New System.Windows.Forms.TextBox
        Me.tabPage6 = New System.Windows.Forms.TabPage
        Me.tbSmtpHelo = New System.Windows.Forms.TextBox
        Me.label15 = New System.Windows.Forms.Label
        Me.cbAuthentication = New System.Windows.Forms.ComboBox
        Me.label10 = New System.Windows.Forms.Label
        Me.tbSmtpPassword = New System.Windows.Forms.TextBox
        Me.tbSmtpUserName = New System.Windows.Forms.TextBox
        Me.label11 = New System.Windows.Forms.Label
        Me.label12 = New System.Windows.Forms.Label
        Me.label13 = New System.Windows.Forms.Label
        Me.tbSmtpPort = New System.Windows.Forms.TextBox
        Me.tbSmtpHostName = New System.Windows.Forms.TextBox
        Me.label14 = New System.Windows.Forms.Label
        Me.rbSmtp = New System.Windows.Forms.RadioButton
        Me.rbOutputDirectory = New System.Windows.Forms.RadioButton
        Me.tbOutputDirectory = New System.Windows.Forms.TextBox
        Me.tabPage7 = New System.Windows.Forms.TabPage
        Me.bGenerate = New System.Windows.Forms.Button
        Me.cbIsTest = New System.Windows.Forms.CheckBox
        Me.progressBar = New System.Windows.Forms.ProgressBar
        Me.tabControl1.SuspendLayout()
        Me.tabPage1.SuspendLayout()
        Me.tabControl2.SuspendLayout()
        Me.tabPage2.SuspendLayout()
        Me.tabPage3.SuspendLayout()
        Me.tabPage4.SuspendLayout()
        Me.tabPage5.SuspendLayout()
        Me.tabPage6.SuspendLayout()
        Me.tabPage7.SuspendLayout()
        Me.SuspendLayout()
        '
        'saveFileDialog
        '
        Me.saveFileDialog.DefaultExt = "mm"
        Me.saveFileDialog.Filter = "MailMerge Files (*.mm)|*.mm"
        '
        'openFileDialog
        '
        Me.openFileDialog.DefaultExt = "mm"
        Me.openFileDialog.Filter = "MailMerge Files (*.mm)|*.mm"
        '
        'mainMenu
        '
        Me.mainMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuFile})
        '
        'menuFile
        '
        Me.menuFile.Index = 0
        Me.menuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuFileNew, Me.menuFileOpen, Me.menuItem2, Me.menuFileSave, Me.menuFileSaveAs, Me.menuItem4, Me.menuFileExit})
        Me.menuFile.Text = "&File"
        '
        'menuFileNew
        '
        Me.menuFileNew.Index = 0
        Me.menuFileNew.Shortcut = System.Windows.Forms.Shortcut.CtrlN
        Me.menuFileNew.Text = "&New"
        '
        'menuFileOpen
        '
        Me.menuFileOpen.Index = 1
        Me.menuFileOpen.Shortcut = System.Windows.Forms.Shortcut.CtrlO
        Me.menuFileOpen.Text = "&Open.."
        '
        'menuItem2
        '
        Me.menuItem2.Index = 2
        Me.menuItem2.Text = "-"
        '
        'menuFileSave
        '
        Me.menuFileSave.Index = 3
        Me.menuFileSave.Shortcut = System.Windows.Forms.Shortcut.CtrlS
        Me.menuFileSave.Text = "&Save"
        '
        'menuFileSaveAs
        '
        Me.menuFileSaveAs.Index = 4
        Me.menuFileSaveAs.Text = "Save &As.."
        '
        'menuItem4
        '
        Me.menuItem4.Index = 5
        Me.menuItem4.Text = "-"
        '
        'menuFileExit
        '
        Me.menuFileExit.Index = 6
        Me.menuFileExit.Text = "E&xit"
        '
        'tabControl1
        '
        Me.tabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tabControl1.Controls.Add(Me.tabPage1)
        Me.tabControl1.Controls.Add(Me.tabPage5)
        Me.tabControl1.Controls.Add(Me.tabPage6)
        Me.tabControl1.Controls.Add(Me.tabPage7)
        Me.tabControl1.Location = New System.Drawing.Point(8, 8)
        Me.tabControl1.Name = "tabControl1"
        Me.tabControl1.SelectedIndex = 0
        Me.tabControl1.Size = New System.Drawing.Size(440, 392)
        Me.tabControl1.TabIndex = 1
        '
        'tabPage1
        '
        Me.tabPage1.Controls.Add(Me.tbFromName)
        Me.tabPage1.Controls.Add(Me.tbFromAddress)
        Me.tabPage1.Controls.Add(Me.label4)
        Me.tabPage1.Controls.Add(Me.tbToName)
        Me.tabPage1.Controls.Add(Me.tabControl2)
        Me.tabPage1.Controls.Add(Me.cbCharset)
        Me.tabPage1.Controls.Add(Me.label6)
        Me.tabPage1.Controls.Add(Me.tbSubject)
        Me.tabPage1.Controls.Add(Me.tbToAdress)
        Me.tabPage1.Controls.Add(Me.cbPriority)
        Me.tabPage1.Controls.Add(Me.label3)
        Me.tabPage1.Controls.Add(Me.label2)
        Me.tabPage1.Controls.Add(Me.label1)
        Me.tabPage1.Location = New System.Drawing.Point(4, 22)
        Me.tabPage1.Name = "tabPage1"
        Me.tabPage1.Size = New System.Drawing.Size(432, 366)
        Me.tabPage1.TabIndex = 0
        Me.tabPage1.Text = "1. Template"
        '
        'tbFromName
        '
        Me.tbFromName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbFromName.Location = New System.Drawing.Point(272, 8)
        Me.tbFromName.Name = "tbFromName"
        Me.tbFromName.Size = New System.Drawing.Size(144, 20)
        Me.tbFromName.TabIndex = 42
        Me.tbFromName.Text = ""
        '
        'tbFromAddress
        '
        Me.tbFromAddress.Location = New System.Drawing.Point(112, 8)
        Me.tbFromAddress.Name = "tbFromAddress"
        Me.tbFromAddress.Size = New System.Drawing.Size(152, 20)
        Me.tbFromAddress.TabIndex = 41
        Me.tbFromAddress.Text = ""
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(8, 16)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(112, 16)
        Me.label4.TabIndex = 43
        Me.label4.Text = "From E-mail / Name:"
        '
        'tbToName
        '
        Me.tbToName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbToName.Location = New System.Drawing.Point(272, 32)
        Me.tbToName.Name = "tbToName"
        Me.tbToName.Size = New System.Drawing.Size(144, 20)
        Me.tbToName.TabIndex = 2
        Me.tbToName.Text = ""
        '
        'tabControl2
        '
        Me.tabControl2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tabControl2.Controls.Add(Me.tabPage2)
        Me.tabControl2.Controls.Add(Me.tabPage3)
        Me.tabControl2.Controls.Add(Me.tabPage4)
        Me.tabControl2.Location = New System.Drawing.Point(12, 136)
        Me.tabControl2.Name = "tabControl2"
        Me.tabControl2.SelectedIndex = 0
        Me.tabControl2.Size = New System.Drawing.Size(408, 216)
        Me.tabControl2.TabIndex = 6
        '
        'tabPage2
        '
        Me.tabPage2.Controls.Add(Me.tbBodyText)
        Me.tabPage2.Location = New System.Drawing.Point(4, 22)
        Me.tabPage2.Name = "tabPage2"
        Me.tabPage2.Size = New System.Drawing.Size(400, 190)
        Me.tabPage2.TabIndex = 0
        Me.tabPage2.Text = "Text Body"
        '
        'tbBodyText
        '
        Me.tbBodyText.AcceptsReturn = True
        Me.tbBodyText.AcceptsTab = True
        Me.tbBodyText.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tbBodyText.Location = New System.Drawing.Point(0, 0)
        Me.tbBodyText.Multiline = True
        Me.tbBodyText.Name = "tbBodyText"
        Me.tbBodyText.Size = New System.Drawing.Size(400, 190)
        Me.tbBodyText.TabIndex = 7
        Me.tbBodyText.Text = ""
        '
        'tabPage3
        '
        Me.tabPage3.Controls.Add(Me.tbBodyHtml)
        Me.tabPage3.Location = New System.Drawing.Point(4, 22)
        Me.tabPage3.Name = "tabPage3"
        Me.tabPage3.Size = New System.Drawing.Size(400, 190)
        Me.tabPage3.TabIndex = 1
        Me.tabPage3.Text = "HTML Body"
        Me.tabPage3.Visible = False
        '
        'tbBodyHtml
        '
        Me.tbBodyHtml.AcceptsReturn = True
        Me.tbBodyHtml.AcceptsTab = True
        Me.tbBodyHtml.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tbBodyHtml.Location = New System.Drawing.Point(0, 0)
        Me.tbBodyHtml.Multiline = True
        Me.tbBodyHtml.Name = "tbBodyHtml"
        Me.tbBodyHtml.Size = New System.Drawing.Size(400, 190)
        Me.tbBodyHtml.TabIndex = 8
        Me.tbBodyHtml.Text = ""
        '
        'tabPage4
        '
        Me.tabPage4.Controls.Add(Me.bRemoveAttachment)
        Me.tabPage4.Controls.Add(Me.bAddAttachment)
        Me.tabPage4.Controls.Add(Me.tbAttPath)
        Me.tabPage4.Controls.Add(Me.tbAttCID)
        Me.tabPage4.Controls.Add(Me.cbAttInline)
        Me.tabPage4.Controls.Add(Me.label8)
        Me.tabPage4.Controls.Add(Me.label7)
        Me.tabPage4.Controls.Add(Me.lbAttachments)
        Me.tabPage4.Location = New System.Drawing.Point(4, 22)
        Me.tabPage4.Name = "tabPage4"
        Me.tabPage4.Size = New System.Drawing.Size(400, 190)
        Me.tabPage4.TabIndex = 2
        Me.tabPage4.Text = "Attachments"
        Me.tabPage4.Visible = False
        '
        'bRemoveAttachment
        '
        Me.bRemoveAttachment.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.bRemoveAttachment.Location = New System.Drawing.Point(80, 160)
        Me.bRemoveAttachment.Name = "bRemoveAttachment"
        Me.bRemoveAttachment.Size = New System.Drawing.Size(64, 23)
        Me.bRemoveAttachment.TabIndex = 11
        Me.bRemoveAttachment.Text = "Remove"
        '
        'bAddAttachment
        '
        Me.bAddAttachment.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.bAddAttachment.Location = New System.Drawing.Point(8, 160)
        Me.bAddAttachment.Name = "bAddAttachment"
        Me.bAddAttachment.Size = New System.Drawing.Size(64, 23)
        Me.bAddAttachment.TabIndex = 10
        Me.bAddAttachment.Text = "Add"
        '
        'tbAttPath
        '
        Me.tbAttPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbAttPath.Enabled = False
        Me.tbAttPath.Location = New System.Drawing.Point(216, 16)
        Me.tbAttPath.Name = "tbAttPath"
        Me.tbAttPath.Size = New System.Drawing.Size(168, 20)
        Me.tbAttPath.TabIndex = 12
        Me.tbAttPath.Text = ""
        '
        'tbAttCID
        '
        Me.tbAttCID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbAttCID.Enabled = False
        Me.tbAttCID.Location = New System.Drawing.Point(216, 56)
        Me.tbAttCID.Name = "tbAttCID"
        Me.tbAttCID.Size = New System.Drawing.Size(168, 20)
        Me.tbAttCID.TabIndex = 14
        Me.tbAttCID.Text = ""
        '
        'cbAttInline
        '
        Me.cbAttInline.Enabled = False
        Me.cbAttInline.Location = New System.Drawing.Point(152, 32)
        Me.cbAttInline.Name = "cbAttInline"
        Me.cbAttInline.Size = New System.Drawing.Size(56, 24)
        Me.cbAttInline.TabIndex = 13
        Me.cbAttInline.Text = "Inline"
        '
        'label8
        '
        Me.label8.Location = New System.Drawing.Point(152, 56)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(64, 16)
        Me.label8.TabIndex = 2
        Me.label8.Text = "Content-ID:"
        '
        'label7
        '
        Me.label7.Location = New System.Drawing.Point(152, 16)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(48, 16)
        Me.label7.TabIndex = 1
        Me.label7.Text = "Path:"
        '
        'lbAttachments
        '
        Me.lbAttachments.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lbAttachments.Location = New System.Drawing.Point(8, 8)
        Me.lbAttachments.Name = "lbAttachments"
        Me.lbAttachments.Size = New System.Drawing.Size(136, 134)
        Me.lbAttachments.TabIndex = 9
        '
        'cbCharset
        '
        Me.cbCharset.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cbCharset.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCharset.Location = New System.Drawing.Point(112, 104)
        Me.cbCharset.Name = "cbCharset"
        Me.cbCharset.Size = New System.Drawing.Size(304, 21)
        Me.cbCharset.TabIndex = 5
        '
        'label6
        '
        Me.label6.Location = New System.Drawing.Point(8, 112)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(48, 16)
        Me.label6.TabIndex = 40
        Me.label6.Text = "Charset:"
        '
        'tbSubject
        '
        Me.tbSubject.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbSubject.Location = New System.Drawing.Point(112, 56)
        Me.tbSubject.Name = "tbSubject"
        Me.tbSubject.Size = New System.Drawing.Size(304, 20)
        Me.tbSubject.TabIndex = 3
        Me.tbSubject.Text = ""
        '
        'tbToAdress
        '
        Me.tbToAdress.Location = New System.Drawing.Point(112, 32)
        Me.tbToAdress.Name = "tbToAdress"
        Me.tbToAdress.Size = New System.Drawing.Size(152, 20)
        Me.tbToAdress.TabIndex = 1
        Me.tbToAdress.Text = ""
        '
        'cbPriority
        '
        Me.cbPriority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbPriority.Location = New System.Drawing.Point(112, 80)
        Me.cbPriority.Name = "cbPriority"
        Me.cbPriority.Size = New System.Drawing.Size(128, 21)
        Me.cbPriority.TabIndex = 4
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(8, 88)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(48, 16)
        Me.label3.TabIndex = 33
        Me.label3.Text = "Priority:"
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(8, 64)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(48, 16)
        Me.label2.TabIndex = 31
        Me.label2.Text = "Subject:"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 40)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(96, 16)
        Me.label1.TabIndex = 29
        Me.label1.Text = "To E-mail / Name:"
        '
        'tabPage5
        '
        Me.tabPage5.Controls.Add(Me.bTestSQL)
        Me.tabPage5.Controls.Add(Me.tbSql)
        Me.tabPage5.Controls.Add(Me.label9)
        Me.tabPage5.Controls.Add(Me.bTestConnection)
        Me.tabPage5.Controls.Add(Me.label5)
        Me.tabPage5.Controls.Add(Me.tbConnectionString)
        Me.tabPage5.Location = New System.Drawing.Point(4, 22)
        Me.tabPage5.Name = "tabPage5"
        Me.tabPage5.Size = New System.Drawing.Size(432, 366)
        Me.tabPage5.TabIndex = 1
        Me.tabPage5.Text = "2. Data Source"
        Me.tabPage5.Visible = False
        '
        'bTestSQL
        '
        Me.bTestSQL.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.bTestSQL.Location = New System.Drawing.Point(352, 328)
        Me.bTestSQL.Name = "bTestSQL"
        Me.bTestSQL.TabIndex = 5
        Me.bTestSQL.Text = "Test"
        '
        'tbSql
        '
        Me.tbSql.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbSql.Location = New System.Drawing.Point(8, 56)
        Me.tbSql.Multiline = True
        Me.tbSql.Name = "tbSql"
        Me.tbSql.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.tbSql.Size = New System.Drawing.Size(416, 264)
        Me.tbSql.TabIndex = 4
        Me.tbSql.Text = ""
        '
        'label9
        '
        Me.label9.Location = New System.Drawing.Point(8, 40)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(88, 16)
        Me.label9.TabIndex = 3
        Me.label9.Text = "SQL Code:"
        '
        'bTestConnection
        '
        Me.bTestConnection.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.bTestConnection.Location = New System.Drawing.Point(344, 8)
        Me.bTestConnection.Name = "bTestConnection"
        Me.bTestConnection.TabIndex = 2
        Me.bTestConnection.Text = "Test"
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(8, 8)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(104, 16)
        Me.label5.TabIndex = 1
        Me.label5.Text = "Connection String:"
        '
        'tbConnectionString
        '
        Me.tbConnectionString.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbConnectionString.Location = New System.Drawing.Point(120, 8)
        Me.tbConnectionString.Name = "tbConnectionString"
        Me.tbConnectionString.Size = New System.Drawing.Size(216, 20)
        Me.tbConnectionString.TabIndex = 0
        Me.tbConnectionString.Text = ""
        '
        'tabPage6
        '
        Me.tabPage6.Controls.Add(Me.tbSmtpHelo)
        Me.tabPage6.Controls.Add(Me.label15)
        Me.tabPage6.Controls.Add(Me.cbAuthentication)
        Me.tabPage6.Controls.Add(Me.label10)
        Me.tabPage6.Controls.Add(Me.tbSmtpPassword)
        Me.tabPage6.Controls.Add(Me.tbSmtpUserName)
        Me.tabPage6.Controls.Add(Me.label11)
        Me.tabPage6.Controls.Add(Me.label12)
        Me.tabPage6.Controls.Add(Me.label13)
        Me.tabPage6.Controls.Add(Me.tbSmtpPort)
        Me.tabPage6.Controls.Add(Me.tbSmtpHostName)
        Me.tabPage6.Controls.Add(Me.label14)
        Me.tabPage6.Controls.Add(Me.rbSmtp)
        Me.tabPage6.Controls.Add(Me.rbOutputDirectory)
        Me.tabPage6.Controls.Add(Me.tbOutputDirectory)
        Me.tabPage6.Location = New System.Drawing.Point(4, 22)
        Me.tabPage6.Name = "tabPage6"
        Me.tabPage6.Size = New System.Drawing.Size(432, 366)
        Me.tabPage6.TabIndex = 2
        Me.tabPage6.Text = "3. Output"
        Me.tabPage6.Visible = False
        '
        'tbSmtpHelo
        '
        Me.tbSmtpHelo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbSmtpHelo.Location = New System.Drawing.Point(32, 136)
        Me.tbSmtpHelo.Name = "tbSmtpHelo"
        Me.tbSmtpHelo.Size = New System.Drawing.Size(360, 20)
        Me.tbSmtpHelo.TabIndex = 29
        Me.tbSmtpHelo.Text = ""
        '
        'label15
        '
        Me.label15.Location = New System.Drawing.Point(32, 120)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(80, 16)
        Me.label15.TabIndex = 28
        Me.label15.Text = "HELO Domain:"
        '
        'cbAuthentication
        '
        Me.cbAuthentication.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cbAuthentication.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbAuthentication.Location = New System.Drawing.Point(32, 200)
        Me.cbAuthentication.Name = "cbAuthentication"
        Me.cbAuthentication.Size = New System.Drawing.Size(368, 21)
        Me.cbAuthentication.TabIndex = 27
        '
        'label10
        '
        Me.label10.Location = New System.Drawing.Point(32, 184)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(80, 16)
        Me.label10.TabIndex = 26
        Me.label10.Text = "Authentication:"
        '
        'tbSmtpPassword
        '
        Me.tbSmtpPassword.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbSmtpPassword.Location = New System.Drawing.Point(32, 296)
        Me.tbSmtpPassword.Name = "tbSmtpPassword"
        Me.tbSmtpPassword.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.tbSmtpPassword.Size = New System.Drawing.Size(360, 20)
        Me.tbSmtpPassword.TabIndex = 25
        Me.tbSmtpPassword.Text = ""
        '
        'tbSmtpUserName
        '
        Me.tbSmtpUserName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbSmtpUserName.Location = New System.Drawing.Point(32, 248)
        Me.tbSmtpUserName.Name = "tbSmtpUserName"
        Me.tbSmtpUserName.Size = New System.Drawing.Size(360, 20)
        Me.tbSmtpUserName.TabIndex = 24
        Me.tbSmtpUserName.Text = ""
        '
        'label11
        '
        Me.label11.Location = New System.Drawing.Point(32, 280)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(64, 16)
        Me.label11.TabIndex = 23
        Me.label11.Text = "Password:"
        '
        'label12
        '
        Me.label12.Location = New System.Drawing.Point(32, 232)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(72, 16)
        Me.label12.TabIndex = 22
        Me.label12.Text = "User Name:"
        '
        'label13
        '
        Me.label13.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label13.Location = New System.Drawing.Point(328, 72)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(48, 16)
        Me.label13.TabIndex = 21
        Me.label13.Text = "Port:"
        '
        'tbSmtpPort
        '
        Me.tbSmtpPort.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbSmtpPort.Location = New System.Drawing.Point(328, 88)
        Me.tbSmtpPort.Name = "tbSmtpPort"
        Me.tbSmtpPort.Size = New System.Drawing.Size(72, 20)
        Me.tbSmtpPort.TabIndex = 20
        Me.tbSmtpPort.Text = ""
        '
        'tbSmtpHostName
        '
        Me.tbSmtpHostName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbSmtpHostName.Location = New System.Drawing.Point(32, 88)
        Me.tbSmtpHostName.Name = "tbSmtpHostName"
        Me.tbSmtpHostName.Size = New System.Drawing.Size(288, 20)
        Me.tbSmtpHostName.TabIndex = 19
        Me.tbSmtpHostName.Text = ""
        '
        'label14
        '
        Me.label14.Location = New System.Drawing.Point(32, 72)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(100, 16)
        Me.label14.TabIndex = 18
        Me.label14.Text = "Host Name:"
        '
        'rbSmtp
        '
        Me.rbSmtp.Location = New System.Drawing.Point(16, 40)
        Me.rbSmtp.Name = "rbSmtp"
        Me.rbSmtp.TabIndex = 4
        Me.rbSmtp.Text = "Output SMTP:"
        '
        'rbOutputDirectory
        '
        Me.rbOutputDirectory.Location = New System.Drawing.Point(16, 8)
        Me.rbOutputDirectory.Name = "rbOutputDirectory"
        Me.rbOutputDirectory.Size = New System.Drawing.Size(112, 24)
        Me.rbOutputDirectory.TabIndex = 3
        Me.rbOutputDirectory.Text = "Output Directory:"
        '
        'tbOutputDirectory
        '
        Me.tbOutputDirectory.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbOutputDirectory.Location = New System.Drawing.Point(128, 8)
        Me.tbOutputDirectory.Name = "tbOutputDirectory"
        Me.tbOutputDirectory.Size = New System.Drawing.Size(272, 20)
        Me.tbOutputDirectory.TabIndex = 2
        Me.tbOutputDirectory.Text = ""
        '
        'tabPage7
        '
        Me.tabPage7.Controls.Add(Me.bGenerate)
        Me.tabPage7.Controls.Add(Me.cbIsTest)
        Me.tabPage7.Controls.Add(Me.progressBar)
        Me.tabPage7.Location = New System.Drawing.Point(4, 22)
        Me.tabPage7.Name = "tabPage7"
        Me.tabPage7.Size = New System.Drawing.Size(432, 366)
        Me.tabPage7.TabIndex = 3
        Me.tabPage7.Text = "4. MailMerge"
        Me.tabPage7.Visible = False
        '
        'bGenerate
        '
        Me.bGenerate.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.bGenerate.Location = New System.Drawing.Point(16, 56)
        Me.bGenerate.Name = "bGenerate"
        Me.bGenerate.Size = New System.Drawing.Size(400, 23)
        Me.bGenerate.TabIndex = 2
        Me.bGenerate.Text = "Start"
        '
        'cbIsTest
        '
        Me.cbIsTest.Location = New System.Drawing.Point(16, 24)
        Me.cbIsTest.Name = "cbIsTest"
        Me.cbIsTest.Size = New System.Drawing.Size(224, 24)
        Me.cbIsTest.TabIndex = 1
        Me.cbIsTest.Text = "Run in test-mode only."
        '
        'progressBar
        '
        Me.progressBar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.progressBar.Location = New System.Drawing.Point(16, 88)
        Me.progressBar.Name = "progressBar"
        Me.progressBar.Size = New System.Drawing.Size(400, 24)
        Me.progressBar.TabIndex = 0
        '
        'MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(456, 409)
        Me.Controls.Add(Me.tabControl1)
        Me.Menu = Me.mainMenu
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MailMerger"
        Me.tabControl1.ResumeLayout(False)
        Me.tabPage1.ResumeLayout(False)
        Me.tabControl2.ResumeLayout(False)
        Me.tabPage2.ResumeLayout(False)
        Me.tabPage3.ResumeLayout(False)
        Me.tabPage4.ResumeLayout(False)
        Me.tabPage5.ResumeLayout(False)
        Me.tabPage6.ResumeLayout(False)
        Me.tabPage7.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' Helper function - displays an error message.
    Private Sub ShowErrorMessage(ByVal e As Exception)
        ShowErrorMessage(e.Message)
    End Sub

    ' Helper function - displays an error message.
    Private Sub ShowErrorMessage(ByVal msg As String)
        MessageBox.Show(Me, msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    ' Helper member - keeps track of wether we are updating the form or the user is.
    Private m_isBinding As Boolean = False

		' Fills the form with data.
    Private Sub BindFormData()

        m_isBinding = True

        ' template form data
        ' message headers
        tbFromAddress.Text = m_file.FromEmail
        tbFromName.Text = m_file.FromFullName
        tbToAdress.Text = m_file.ToEmail
        tbToName.Text = m_file.ToFullName
        tbSubject.Text = m_file.Subject
        cbPriority.SelectedItem = m_file.Priority
        cbCharset.SelectedIndex = cbCharset.Items.IndexOf(m_file.Charset.BodyName)

        ' bodies
        tbBodyText.Text = m_file.BodyText
        tbBodyHtml.Text = m_file.BodyHtml

        ' attachments			
        BindAttachments()

        ' data sources
        ' connection string
        tbConnectionString.Text = m_file.ConnectionString
        tbSql.Text = m_file.Sql

        ' output
        ' output directory
        If m_file.OutputMethod = 0 Then
            rbOutputDirectory.Checked = True
        Else
            rbOutputDirectory.Checked = False
        End If
        tbOutputDirectory.Text = m_file.OutputDirectory
        ' output smtp
        If m_file.OutputMethod = 1 Then
            rbSmtp.Checked = True
        Else
            rbSmtp.Checked = False
        End If

        tbSmtpHostName.Text = m_file.OutputSmtpHostName
        tbSmtpHelo.Text = m_file.OutputSmtpHelo
        tbSmtpPort.Text = m_file.OutputSmtpPort.ToString()
        cbAuthentication.SelectedItem = m_file.OutputSmtpAuth
        tbSmtpUserName.Text = m_file.OutputSmtpUserName
        tbSmtpPassword.Text = m_file.OutputSmtpPassword

        ChangeOutput()

        m_isBinding = False
    End Sub

    ' Changes the output method.
    Private Sub ChangeOutput()
        If m_file.OutputMethod = 0 Then

            tbOutputDirectory.Enabled = True

            tbSmtpHostName.Enabled = False
            tbSmtpPort.Enabled = False
            cbAuthentication.Enabled = False
            tbSmtpUserName.Enabled = False
            tbSmtpPassword.Enabled = False

            cbAuthentication.SelectedIndex = 0

            tbSmtpHostName.Text = ""
            tbSmtpPort.Text = ""
            tbSmtpUserName.Text = ""
            tbSmtpPassword.Text = ""
        End If
        If m_file.OutputMethod = 1 Then
            tbOutputDirectory.Enabled = False
            tbOutputDirectory.Text = ""

            tbSmtpHostName.Enabled = True
            tbSmtpPort.Enabled = True
            cbAuthentication.Enabled = True

            If cbAuthentication.SelectedIndex > 0 Then
                tbSmtpUserName.Enabled = True
                tbSmtpPassword.Enabled = True
            Else
                tbSmtpUserName.Enabled = False
                tbSmtpPassword.Enabled = False
            End If
        End If
    End Sub

    ' Fills the attachment list.
    Private Sub BindAttachments()
        lbAttachments.BeginUpdate()
        lbAttachments.Items.Clear()
        For Each att As LocalAttachedFile In m_file.Attachments
            lbAttachments.Items.Add(att)
        Next
        lbAttachments.EndUpdate()
    End Sub

    ' File -> New
    Private Sub menuFileNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFileNew.Click
        m_file = New MailMergeFile
        BindFormData()
    End Sub

    ' File -> Open
    Private Sub menuFileOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFileOpen.Click
        If openFileDialog.ShowDialog(Me) = DialogResult.OK Then
            Try
                m_file.Load(openFileDialog.FileName)
                BindFormData()
            Catch ex As Exception
                ShowErrorMessage(ex)
            End Try
        End If
    End Sub

    ' File -> Save
    Private Sub menuFileSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFileSave.Click
        If m_file.FileName = Nothing Then
            menuFileSaveAs_Click(sender, e)
        Else
			Try
                m_file.Save(m_file.FileName)
            Catch ex As Exception
                ShowErrorMessage(ex)
            End Try
        End If
    End Sub

    ' File -> Save As
    Private Sub menuFileSaveAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFileSaveAs.Click
        If saveFileDialog.ShowDialog(Me) = DialogResult.OK Then
			Try
                m_file.Save(saveFileDialog.FileName)
            Catch ex As Exception
                ShowErrorMessage(ex)
            End Try
        End If
    End Sub

    ' File -> Exit
    Private Sub menuFileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuFileExit.Click
        Application.Exit()
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbFromAddress_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbFromAddress.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.FromEmail = tbFromAddress.Text
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbFromName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbFromName.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.FromFullName = tbFromName.Text()
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbToAdress_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbToAdress.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.ToEmail = tbToAdress.Text
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbToName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbToName.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.ToFullName = tbToName.Text
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbSubject_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbSubject.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.Subject = tbSubject.Text
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub cbPriority_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbPriority.SelectedIndexChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.Priority = cbPriority.SelectedValue
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub cbCharset_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbCharset.SelectedIndexChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.Charset = Encoding.GetEncoding(CStr(cbCharset.SelectedItem))
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbBodyText_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbBodyText.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.BodyText = tbBodyText.Text
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbBodyHtml_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbBodyHtml.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.BodyHtml = tbBodyHtml.Text
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbConnectionString_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbConnectionString.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.ConnectionString = tbConnectionString.Text
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbSql_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbSql.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.Sql = tbSql.Text
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub rbOutputDirectory_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbOutputDirectory.CheckedChanged
        If m_isBinding Then
            Exit Sub
        End If

        If rbOutputDirectory.Checked Then
            m_file.OutputMethod = 0
        Else
            m_file.OutputMethod = 1
        End If
        ChangeOutput()
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub rbSmtp_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbSmtp.CheckedChanged
        If m_isBinding Then
            Exit Sub
        End If

        If rbSmtp.Checked Then
            m_file.OutputMethod = 1
        Else
            m_file.OutputMethod = 2
        End If
        ChangeOutput()
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbOutputDirectory_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbOutputDirectory.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.OutputDirectory = tbOutputDirectory.Text
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbSmtpHostName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbSmtpHostName.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.OutputSmtpHostName = tbSmtpHostName.Text
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbSmtpPort_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbSmtpPort.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        If tbSmtpPort.Text.Length > 0 Then
			Try
                m_file.OutputSmtpPort = Int32.Parse(tbSmtpPort.Text)
            Catch
                tbSmtpPort.Text = ""

            End Try
        End If
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbSmtpHelo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbSmtpHelo.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.OutputSmtpHelo = tbSmtpHelo.Text
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub cbAuthentication_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbAuthentication.SelectedIndexChanged
        If m_isBinding Then
            Exit Sub
        End If

        If cbAuthentication.SelectedIndex > 0 Then
            tbSmtpUserName.Enabled = True
            tbSmtpPassword.Enabled = True
        Else
            tbSmtpUserName.Text = ""
            tbSmtpPassword.Text = ""
            tbSmtpUserName.Enabled = False
            tbSmtpPassword.Enabled = False
        End If

        m_file.OutputSmtpAuth = cbAuthentication.SelectedValue
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbSmtpUserName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbSmtpUserName.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.OutputSmtpUserName = tbSmtpUserName.Text
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbSmtpPassword_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbSmtpPassword.TextChanged
        If m_isBinding Then
            Exit Sub
        End If

        m_file.OutputSmtpPassword = tbSmtpPassword.Text
    End Sub

    ' Loads selected attachment
    Private Sub lbAttachments_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbAttachments.SelectedIndexChanged
        If lbAttachments.SelectedIndex >= 0 AndAlso lbAttachments.SelectedIndex < m_file.Attachments.Count Then
            tbAttCID.Enabled = True
            cbAttInline.Enabled = True

            Dim file As LocalAttachedFile = m_file.Attachments(lbAttachments.SelectedIndex)
            tbAttPath.Text = file.Path
            tbAttCID.Enabled = file.Inline
            cbAttInline.Checked = file.Inline
            tbAttCID.Text = file.ContentId			
        Else
            tbAttCID.Enabled = False
            cbAttInline.Enabled = False
        End If
    End Sub

    ' Adds an attachment
    Private Sub bAddAttachment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bAddAttachment.Click
        If attFileDialog.ShowDialog(Me) = DialogResult.OK Then
            Dim file As New LocalAttachedFile(attFileDialog.FileName)
            m_file.Attachments.Add(file)
            lbAttachments.Items.Add(file)
        End If
    End Sub

    ' removes an attachment
    Private Sub bRemoveAttachment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bRemoveAttachment.Click
        If lbAttachments.SelectedIndex >= 0 AndAlso lbAttachments.SelectedIndex < m_file.Attachments.Count Then
            m_file.Attachments.RemoveAt(lbAttachments.SelectedIndex)
            lbAttachments.Items.RemoveAt(lbAttachments.SelectedIndex)
        End If
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub cbAttInline_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbAttInline.CheckedChanged
        If lbAttachments.SelectedIndex >= 0 AndAlso lbAttachments.SelectedIndex < m_file.Attachments.Count Then
            Dim file As LocalAttachedFile = m_file.Attachments(lbAttachments.SelectedIndex)
            file.Inline = cbAttInline.Checked
            tbAttCID.Enabled = cbAttInline.Checked
        End If
    End Sub

    ' Value changed -> save to mailmerge data file
    Private Sub tbAttCID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbAttCID.TextChanged
        If lbAttachments.SelectedIndex >= 0 AndAlso lbAttachments.SelectedIndex < m_file.Attachments.Count Then
            Dim file As LocalAttachedFile = m_file.Attachments(lbAttachments.SelectedIndex)
            file.ContentId = tbAttCID.Text
        End If
    End Sub

    ' Tests the given ODBC connection string.
    Private Sub bTestConnection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bTestConnection.Click
        Dim connection As New OdbcConnection(m_file.ConnectionString)
        Try
            connection.Open()
            MessageBox.Show(Me, "Connection String is working!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            ShowErrorMessage(ex)
        Finally
            connection.Dispose()
        End Try
    End Sub

    ' Tests the SQL statement (and connection string).
    Private Sub bTestSQL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bTestSQL.Click
        Dim connection As New OdbcConnection(m_file.ConnectionString)
        Dim command As New OdbcCommand(m_file.Sql, connection)
        Try
            connection.Open()
            command.ExecuteNonQuery()
            MessageBox.Show(Me, "Connection String and SQL code is working!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            ShowErrorMessage(ex)
        Finally
            command.Dispose()
            connection.Dispose()
        End Try
    End Sub

    ' Starts the MailMerge process.
    Private Sub bGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bGenerate.Click
        progressBar.Maximum = 4
        progressBar.Minimum = 0
        progressBar.Value = 0
        progressBar.Invalidate()

        If m_file.OutputMethod = 0 Then

            If m_file.OutputDirectory Is Nothing OrElse m_file.OutputDirectory.Length = 0 Then
                ShowErrorMessage("You must select an output folder.")
                Exit Sub
            End If

            If Not Directory.Exists(m_file.OutputDirectory) Then
                Try
                    Directory.CreateDirectory(m_file.OutputDirectory)
                Catch ex As Exception
                    ShowErrorMessage(ex)
                    Exit Sub
                End Try
            End If
        End If

        If m_file.OutputMethod = 1 Then
            If m_file.OutputSmtpHostName.Length = 0 Then
                ShowErrorMessage("You have to enter a host name for your SMTP server.")
                Exit Sub
            End If

            If m_file.OutputSmtpPort <= 0 Then
                ShowErrorMessage("Invalid SMTP port.")
                Exit Sub
            End If
        End If

        ' for logging the results..
        Dim result As MailMergeResult = Nothing

        Cursor = Cursors.WaitCursor
        bGenerate.Enabled = False
        progressBar.Increment(1)
        Try
            ' create mailmerge object
            Dim mm As New MailMerge
            ' setup mail merge template
            mm.Template.From.FullName = m_file.FromFullName
            mm.Template.From.Email = m_file.FromEmail
            mm.Template.To.Add(m_file.ToEmail, m_file.ToFullName)
            mm.Template.Priority = m_file.Priority
            mm.Template.Charset = m_file.Charset
            mm.Template.Subject = m_file.Subject
            mm.Template.BodyHtml = m_file.BodyHtml
            mm.Template.BodyText = m_file.BodyText
            For Each att As LocalAttachedFile In m_file.Attachments
                If att.Inline Then
                    mm.Template.Attachments.AddInlineAttachment(att.Path, att.ContentId)
                Else
                    mm.Template.Attachments.Add(att.Path)
                End If
            Next
            progressBar.Increment(1)

            ' set callback
            mm.OutputCallback = AddressOf OnMailMerge

            ' set test mode if applicable
            If cbIsTest.Checked Then
                mm.EnableTestMode(New Address(m_file.FromEmail, m_file.FromFullName), 5)
            End If
            progressBar.Increment(1)

            ' get data source
            Dim connection As New OdbcConnection(m_file.ConnectionString)
            Dim command As New OdbcCommand(m_file.Sql, connection)
            Try
                connection.Open()
                Dim reader As OdbcDataReader = command.ExecuteReader()
                Try
                    ' set data source
                    mm.DataSource = reader

                    ' data bind
                    result = mm.DataBind(False)
                Finally
                    reader.Close()
                End Try
            Finally
                command.Dispose()
                connection.Dispose()
            End Try
        Catch ex As Exception
            ShowErrorMessage(ex)
            Cursor = Cursors.Default
            bGenerate.Enabled = True
            progressBar.Value = 0
            Exit Sub
        End Try
        progressBar.Increment(1)

        If Not result Is Nothing Then
            MessageBox.Show(Me, "MailMerge completed with " & result.FailureCount & " failures and " & result.SuccessCount & " successfully created messages.")
        End If

        Cursor = Cursors.Default
        bGenerate.Enabled = True
    End Sub

    ' Our MailMerge callback - does the actual serialization of the resulting message.
    ' We want to handle this by ourself so that we can increase our progressbar!
    Private Sub OnMailMerge(ByVal message As Dimac.JMail.Message)
        If m_file.OutputMethod = 0 Then
            Dim fileName As String = Path.Combine(m_file.OutputDirectory, Guid.NewGuid().ToString("n") + ".eml")
            Dim stream As New FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None)
            Dim writer As New MimeWriter(stream)
            Try
                writer.Write(message)
            Finally
                writer.Dispose()
                stream.Close()
            End Try
        ElseIf m_file.OutputMethod = 1 Then
            Dim smtp As New Smtp(m_file.OutputSmtpHostName, CShort(m_file.OutputSmtpPort))
            If m_file.OutputSmtpHelo.Length > 0 Then
                smtp.Domain = m_file.OutputSmtpHelo
            End If

            smtp.Authentication = m_file.OutputSmtpAuth
            If smtp.Authentication <> SmtpAuthentication.None Then
				smtp.UserName = m_file.OutputSmtpUserName
                smtp.Password = m_file.OutputSmtpPassword
            End If
            smtp.Send(message)
        End If
        progressBar.Maximum = progressBar.Maximum + 1
        progressBar.Increment(1)
        progressBar.Invalidate()
    End Sub
End Class
