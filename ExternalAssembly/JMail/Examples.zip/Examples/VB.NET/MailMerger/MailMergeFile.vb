' Represents the data used for setting up mailmerge. Can be saved and loaded from a file.
' This class has nothing to do with Dimac.JMail.MailMerge - it's just for this example.	
Public Class MailMergeFile
    Private m_fileName As String

    Private m_toEmail As String
    Private m_toFullName As String
    Private m_fromEmail As String
    Private m_fromFullName As String
    Private m_priority As Priority
    Private m_charset As Encoding
    Private m_subject As String
    Private m_bodyText As String
    Private m_bodyHtml As String
    Private m_attachments As ArrayList

    Private m_connectionString As String
    Private m_sql As String

    Private m_outputMethod As Integer

    Private m_outputDirectory As String

    Private m_outputSmtpHostName As String
    Private m_outputSmtpPort As Integer
    Private m_outputSmtpHelo As String
    Private m_outputSmtpAuth As SmtpAuthentication
    Private m_outputSmtpUserName As String
    Private m_outputSmtpPassword As String

    ' Constructor
    Public Sub New()
        m_fileName = Nothing

        m_toEmail = String.Empty
        m_toFullName = String.Empty
        m_fromEmail = String.Empty
        m_fromFullName = String.Empty
        m_priority = Priority.None
        m_charset = Encoding.Default
        m_subject = String.Empty
        m_bodyText = String.Empty
        m_bodyHtml = String.Empty
        m_attachments = New ArrayList

        m_connectionString = String.Empty
        m_sql = String.Empty

        m_outputMethod = 0

        m_outputDirectory = String.Empty

        m_outputSmtpHostName = String.Empty
        m_outputSmtpPort = 0
        m_outputSmtpHelo = String.Empty
        m_outputSmtpAuth = SmtpAuthentication.None
        m_outputSmtpUserName = String.Empty
        m_outputSmtpPassword = String.Empty
    End Sub

    ' Loads the MailMergeFile from disk.
    Public Sub Load(ByVal fileName As String)
        Dim xml As New XmlDocument
        xml.Load(fileName)

        m_toEmail = xml.SelectSingleNode("/mailMerge/template/to/email").InnerText
        m_toFullName = xml.SelectSingleNode("/mailMerge/template/to/fullName").InnerText
        m_fromEmail = xml.SelectSingleNode("/mailMerge/template/from/email").InnerText
        m_fromFullName = xml.SelectSingleNode("/mailMerge/template/from/fullName").InnerText
        m_priority = [Enum].Parse(GetType(Priority), xml.SelectSingleNode("/mailMerge/template/priority").InnerText)
        m_charset = Encoding.GetEncoding(xml.SelectSingleNode("/mailMerge/template/charset").InnerText)
        m_subject = xml.SelectSingleNode("/mailMerge/template/subject").InnerText
        m_bodyText = xml.SelectSingleNode("/mailMerge/template/bodyText").InnerText
        m_bodyHtml = xml.SelectSingleNode("/mailMerge/template/bodyHtml").InnerText

        m_attachments = New ArrayList
        Dim nodes As XmlNodeList = xml.SelectNodes("/mailMerge/template/attachments/attachment")
        For Each node As XmlNode In nodes
            Dim file As New LocalAttachedFile(node.SelectSingleNode("path").InnerText, XmlConvert.ToBoolean(node.SelectSingleNode("inline").InnerText), node.SelectSingleNode("contentId").InnerText)
            m_attachments.Add(File)
        Next

        m_connectionString = xml.SelectSingleNode("/mailMerge/dataSource/connectionString").InnerText
        m_sql = xml.SelectSingleNode("/mailMerge/dataSource/sql").InnerText

        m_outputMethod = XmlConvert.ToInt32(xml.SelectSingleNode("/mailMerge/output/method").InnerText)

        m_outputDirectory = xml.SelectSingleNode("/mailMerge/output/directory").InnerText

        m_outputSmtpHostName = xml.SelectSingleNode("/mailMerge/output/smtp/hostName").InnerText
        m_outputSmtpPort = XmlConvert.ToInt32(xml.SelectSingleNode("/mailMerge/output/smtp/port").InnerText)
        m_outputSmtpHelo = xml.SelectSingleNode("/mailMerge/output/smtp/helo").InnerText
        m_outputSmtpAuth = [Enum].Parse(GetType(SmtpAuthentication), xml.SelectSingleNode("/mailMerge/output/smtp/authentication").InnerText)
        m_outputSmtpUserName = xml.SelectSingleNode("/mailMerge/output/smtp/userName").InnerText
        m_outputSmtpPassword = Encoding.Default.GetString(Convert.FromBase64String(xml.SelectSingleNode("/mailMerge/output/smtp/password").InnerText))

        m_fileName = fileName
    End Sub

    ' Saves the MailMergeFile to disk.
    Public Sub Save(ByVal fileName As String)
        Dim xml As New XmlTextWriter(fileName, Encoding.UTF8)
        xml.Formatting = Formatting.Indented
        xml.WriteStartDocument(True)
        xml.WriteStartElement("mailMerge")

        xml.WriteStartElement("template")

        xml.WriteStartElement("to")
        xml.WriteStartElement("email")
        xml.WriteString(m_toEmail)
        xml.WriteEndElement()
        xml.WriteStartElement("fullName")
        xml.WriteString(m_toFullName)
        xml.WriteEndElement()
        xml.WriteEndElement()

        xml.WriteStartElement("from")
        xml.WriteStartElement("email")
        xml.WriteString(m_fromEmail)
        xml.WriteEndElement()
        xml.WriteStartElement("fullName")
        xml.WriteString(m_fromFullName)
        xml.WriteEndElement()
        xml.WriteEndElement()

        xml.WriteStartElement("priority")
        xml.WriteString(m_priority.ToString())
        xml.WriteEndElement()

        xml.WriteStartElement("charset")
        xml.WriteString(m_charset.BodyName)
        xml.WriteEndElement()

        xml.WriteStartElement("subject")
        xml.WriteString(m_subject)
        xml.WriteEndElement()

        xml.WriteStartElement("bodyText")
        xml.WriteString(m_bodyText)
        xml.WriteEndElement()

        xml.WriteStartElement("bodyHtml")
        xml.WriteString(m_bodyHtml)
        xml.WriteEndElement()

        xml.WriteStartElement("attachments")
        For Each att As LocalAttachedFile In m_attachments			
            xml.WriteStartElement("attachment")
            xml.WriteStartElement("path")
            xml.WriteString(att.Path)
            xml.WriteEndElement()
            xml.WriteStartElement("inline")
            xml.WriteString(XmlConvert.ToString(att.Inline))
            xml.WriteEndElement()
            xml.WriteStartElement("contentId")
            xml.WriteString(att.ContentId)
            xml.WriteEndElement()
            xml.WriteEndElement()
        Next
        xml.WriteEndElement()

        xml.WriteEndElement()

        xml.WriteStartElement("dataSource")
        xml.WriteStartElement("connectionString")
        xml.WriteString(m_connectionString)
        xml.WriteEndElement()
        xml.WriteStartElement("sql")
        xml.WriteString(m_sql)
        xml.WriteEndElement()
        xml.WriteEndElement()

        xml.WriteStartElement("output")

        xml.WriteStartElement("method")
        xml.WriteString(XmlConvert.ToString(m_outputMethod))
        xml.WriteEndElement()

        xml.WriteStartElement("directory")
        xml.WriteString(m_outputDirectory)
        xml.WriteEndElement()

        xml.WriteStartElement("smtp")

        xml.WriteStartElement("hostName")
        xml.WriteString(m_outputSmtpHostName)
        xml.WriteEndElement()

        xml.WriteStartElement("port")
        xml.WriteString(XmlConvert.ToString(m_outputSmtpPort))
        xml.WriteEndElement()

        xml.WriteStartElement("helo")
        xml.WriteString(m_outputSmtpHelo)
        xml.WriteEndElement()

        xml.WriteStartElement("authentication")
        xml.WriteString(m_outputSmtpAuth.ToString())
        xml.WriteEndElement()

        xml.WriteStartElement("userName")
        xml.WriteString(m_outputSmtpUserName)
        xml.WriteEndElement()

        xml.WriteStartElement("password")
        ' WARNING: password saved "almost" in clear-text..
        xml.WriteString(Convert.ToBase64String(Encoding.Default.GetBytes(m_outputSmtpPassword)))
        xml.WriteEndElement()

        xml.WriteEndElement()

        xml.WriteEndElement()

        xml.WriteEndElement()
        xml.WriteEndDocument()
        xml.Close()
    End Sub

    Public Property FileName() As String
        Get
            Return m_fileName
        End Get
        Set(ByVal Value As String)
            m_fileName = Value
        End Set
    End Property

    Public Property ToEmail() As String
        Get
            Return m_toEmail
        End Get
        Set(ByVal Value As String)
            m_toEmail = Value
        End Set
    End Property

    Public Property ToFullName() As String
        Get
            Return m_toFullName
        End Get
        Set(ByVal Value As String)
            m_toFullName = Value
        End Set
    End Property

    Public Property FromEmail() As String
        Get
            Return m_fromEmail
        End Get
        Set(ByVal Value As String)
            m_fromEmail = Value
        End Set
    End Property

    Public Property FromFullName() As String
        Get
            Return m_fromFullName
        End Get
        Set(ByVal Value As String)
            m_fromFullName = Value
        End Set
    End Property

    Public Property Priority() As Priority
        Get
            Return m_priority
        End Get
        Set(ByVal Value As Priority)
            m_priority = Value
        End Set
    End Property

    Public Property Charset() As Encoding
        Get
            Return m_charset
        End Get
        Set(ByVal Value As Encoding)
            m_charset = Value
        End Set
    End Property

    Public Property Subject() As String
        Get
            Return m_subject
        End Get
        Set(ByVal Value As String)
            m_subject = Value
        End Set
    End Property

    Public Property BodyText() As String
        Get
            Return m_bodyText
        End Get
        Set(ByVal Value As String)
            m_bodyText = Value
        End Set
    End Property

    Public Property BodyHtml() As String
        Get
            Return m_bodyHtml
        End Get
        Set(ByVal Value As String)
            m_bodyHtml = Value
        End Set
    End Property

    Public Property Attachments() As ArrayList
        Get
            Return m_attachments
        End Get
        Set(ByVal Value As ArrayList)
            m_attachments = Value
        End Set
    End Property

    Public Property ConnectionString() As String
        Get
            Return m_connectionString
        End Get
        Set(ByVal Value As String)
            m_connectionString = Value
        End Set
    End Property

    Public Property Sql() As String
        Get
            Return m_sql
        End Get
        Set(ByVal Value As String)
            m_sql = Value
        End Set
    End Property

    Public Property OutputMethod() As Integer
        Get
            Return m_outputMethod
        End Get
        Set(ByVal Value As Integer)
            m_outputMethod = Value
        End Set
    End Property

    Public Property OutputDirectory() As String
        Get
            Return m_outputDirectory
        End Get
        Set(ByVal Value As String)
            m_outputDirectory = Value
        End Set
    End Property

    Public Property OutputSmtpHostName() As String
        Get
            Return m_outputSmtpHostName
        End Get
        Set(ByVal Value As String)
            m_outputSmtpHostName = Value
        End Set
    End Property

    Public Property OutputSmtpPort() As Integer
        Get
            Return m_outputSmtpPort
        End Get
        Set(ByVal Value As Integer)
            m_outputSmtpPort = Value
        End Set
    End Property

    Public Property OutputSmtpHelo() As String
        Get
            Return m_outputSmtpHelo
        End Get
        Set(ByVal Value As String)
            m_outputSmtpHelo = Value
        End Set
    End Property

    Public Property OutputSmtpAuth() As SmtpAuthentication
        Get
            Return m_outputSmtpAuth
        End Get
        Set(ByVal Value As SmtpAuthentication)
            m_outputSmtpAuth = Value
        End Set
    End Property

    Public Property OutputSmtpUserName() As String
        Get
            Return m_outputSmtpUserName
        End Get
        Set(ByVal Value As String)
            m_outputSmtpUserName = Value
        End Set
    End Property

    Public Property OutputSmtpPassword() As String
        Get
            Return m_outputSmtpPassword
        End Get
        Set(ByVal Value As String)
            m_outputSmtpPassword = Value
        End Set
    End Property
End Class
