smtp.aspx
-----------------------------------------------------------------------------------------------

Description:
	Simple ASP.NET page that sends a mail using JMail.NET

Remarks:
	Copy the file to a folder in your website and the JMail assemblies to the bin-folder of 
	your website.

Requires:
	JMail.NET Free Version
	* Dimac.JMail.dll
	* Dimac.JMail.Smtp.dll


pop3.aspx, download.aspx
-----------------------------------------------------------------------------------------------

Description:
	Simple ASP.NET page that connects to a POP3 server and downloads messages using 
	JMail.NET

Remarks:
	Copy the files to a folder in your website and the JMail assemblies to the bin-folder 
	of your website.

Requires:
	JMail.NET Professional Version
	* Dimac.JMail.dll
	* Dimac.JMail.Pop3.dll
