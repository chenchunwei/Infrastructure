using System;
using System.Text;
using Dimac.JMail;
using Dimac.JMail.Smtp;

namespace SmtpExample
{
	/// <summary>
	/// A consol application that sends an email by SMTP.
	/// Lets the user to set the fields and then write the body part. 
	/// The body part is ended by entering an empty line,
	/// which will also send the email.
	/// </summary>
	public class MainClass
	{
		[STAThread]
		public static void Main(string[] args)
		{
			Console.WriteLine( new string('=', 79) );
			Console.Write( "Server: " );
			string hostName = Console.ReadLine();
			Console.Write( "From: " );
			string from = Console.ReadLine();
			Console.Write( "To: " );
			string to = Console.ReadLine();
			Console.Write( "Subject: " );
			string subject = Console.ReadLine();
			string body = Body();
			Console.WriteLine( new string('=', 79) );

			Console.WriteLine( "Sending message..." );
			Message message = new Message( from, to, subject, body );
			Smtp.Send( message, hostName );
			Console.WriteLine( "Message sent." );
		}

		/// <summary>
		/// Get the body part from user input.
		/// It is ended with an empty line.
		/// </summary>
		private static string Body()
		{
			Console.WriteLine( "Body(end with an emtpy line): " );
			
			StringBuilder body = new StringBuilder();
			string line;
			do
			{
				line = Console.ReadLine();
				if( line.Length > 0 && body.Length > 0 )
					body.Append( Environment.NewLine );
				body.Append( line );
			}
			while( line.Length > 0 ); 

			return body.ToString();
		}
	}
}
