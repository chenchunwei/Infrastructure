using System;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
// for use of the JMail MimeReader and Mime object model
using Dimac.JMail.Mime;

namespace MimeDocumentViewer
{
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem mFile;
		private System.Windows.Forms.MenuItem mFileOpen;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem mFileExit;
		private System.Windows.Forms.StatusBar statusBar;
		private System.Windows.Forms.StatusBarPanel statusBarPanel;
		private System.Windows.Forms.ListView lvHeaders;
		private System.Windows.Forms.ColumnHeader chHeaderName;
		private System.Windows.Forms.ColumnHeader chHeaderValue;
		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.TreeView tvBodyParts;
		private System.Windows.Forms.OpenFileDialog openFileDialog;
		private System.Windows.Forms.ContextMenu contextMenu;
		private System.Windows.Forms.MenuItem menuSaveAs;
		private System.Windows.Forms.SaveFileDialog saveFileDialog;
		private System.ComponentModel.Container components = null;

		public MainForm()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if( components != null )
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.mFile = new System.Windows.Forms.MenuItem();
			this.mFileOpen = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.mFileExit = new System.Windows.Forms.MenuItem();
			this.statusBar = new System.Windows.Forms.StatusBar();
			this.statusBarPanel = new System.Windows.Forms.StatusBarPanel();
			this.lvHeaders = new System.Windows.Forms.ListView();
			this.chHeaderName = new System.Windows.Forms.ColumnHeader();
			this.chHeaderValue = new System.Windows.Forms.ColumnHeader();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.tvBodyParts = new System.Windows.Forms.TreeView();
			this.contextMenu = new System.Windows.Forms.ContextMenu();
			this.menuSaveAs = new System.Windows.Forms.MenuItem();
			this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel)).BeginInit();
			this.SuspendLayout();
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.mFile});
			// 
			// mFile
			// 
			this.mFile.Index = 0;
			this.mFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				  this.mFileOpen,
																				  this.menuItem1,
																				  this.mFileExit});
			this.mFile.Text = "&File";
			// 
			// mFileOpen
			// 
			this.mFileOpen.Index = 0;
			this.mFileOpen.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
			this.mFileOpen.Text = "&Open..";
			this.mFileOpen.Click += new System.EventHandler(this.mFileOpen_Click);
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 1;
			this.menuItem1.Text = "-";
			// 
			// mFileExit
			// 
			this.mFileExit.Index = 2;
			this.mFileExit.Text = "E&xit";
			this.mFileExit.Click += new System.EventHandler(this.mFileExit_Click);
			// 
			// statusBar
			// 
			this.statusBar.Location = new System.Drawing.Point(0, 312);
			this.statusBar.Name = "statusBar";
			this.statusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						 this.statusBarPanel});
			this.statusBar.ShowPanels = true;
			this.statusBar.Size = new System.Drawing.Size(368, 22);
			this.statusBar.TabIndex = 0;
			// 
			// statusBarPanel
			// 
			this.statusBarPanel.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.statusBarPanel.Text = "Ready";
			this.statusBarPanel.Width = 352;
			// 
			// lvHeaders
			// 
			this.lvHeaders.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.chHeaderName,
																						this.chHeaderValue});
			this.lvHeaders.Dock = System.Windows.Forms.DockStyle.Top;
			this.lvHeaders.FullRowSelect = true;
			this.lvHeaders.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.lvHeaders.Location = new System.Drawing.Point(0, 0);
			this.lvHeaders.Name = "lvHeaders";
			this.lvHeaders.Size = new System.Drawing.Size(368, 152);
			this.lvHeaders.TabIndex = 1;
			this.lvHeaders.View = System.Windows.Forms.View.Details;
			// 
			// chHeaderName
			// 
			this.chHeaderName.Text = "Name";
			this.chHeaderName.Width = 160;
			// 
			// chHeaderValue
			// 
			this.chHeaderValue.Text = "Value";
			this.chHeaderValue.Width = 160;
			// 
			// splitter1
			// 
			this.splitter1.Dock = System.Windows.Forms.DockStyle.Top;
			this.splitter1.Location = new System.Drawing.Point(0, 152);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(368, 3);
			this.splitter1.TabIndex = 2;
			this.splitter1.TabStop = false;
			// 
			// tvBodyParts
			// 
			this.tvBodyParts.ContextMenu = this.contextMenu;
			this.tvBodyParts.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tvBodyParts.ImageIndex = -1;
			this.tvBodyParts.Location = new System.Drawing.Point(0, 155);
			this.tvBodyParts.Name = "tvBodyParts";
			this.tvBodyParts.SelectedImageIndex = -1;
			this.tvBodyParts.Size = new System.Drawing.Size(368, 157);
			this.tvBodyParts.TabIndex = 3;
			this.tvBodyParts.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvBodyParts_AfterSelect);
			// 
			// contextMenu
			// 
			this.contextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						this.menuSaveAs});
			this.contextMenu.Popup += new System.EventHandler(this.contextMenu_Popup);
			// 
			// menuSaveAs
			// 
			this.menuSaveAs.Index = 0;
			this.menuSaveAs.Text = "&Save As..";
			this.menuSaveAs.Click += new System.EventHandler(this.menuSaveAs_Click);
			// 
			// openFileDialog
			// 
			this.openFileDialog.Filter = "E-mail Files (*.eml)|*.eml|All Files (*.*)|*.*";
			// 
			// saveFileDialog
			// 
			this.saveFileDialog.Filter = "All Files (*.*)|*.*";
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(368, 334);
			this.Controls.Add(this.tvBodyParts);
			this.Controls.Add(this.splitter1);
			this.Controls.Add(this.lvHeaders);
			this.Controls.Add(this.statusBar);
			this.Menu = this.mainMenu;
			this.Name = "MainForm";
			this.Text = "MIME Document Viewer";
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run( new MainForm() );
		}

		private void mFileOpen_Click(object sender, System.EventArgs e)
		{
			if( openFileDialog.ShowDialog( this ) == DialogResult.OK )
			{
				OpenFile( openFileDialog.FileName );
			}
		}

		private void mFileExit_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void tvBodyParts_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			BindHeaders( e.Node.Tag as Entity );
		}

		private void OpenFile( string path )
		{
			if( File.Exists( path ) )
			{
				// setup filestream for reading file
				using( FileStream fs = new FileStream( path, FileMode.Open, FileAccess.Read, FileShare.Read ) )
				// setup mimereader for parsing the mime objects in the file stream
				using( MimeReader reader = new MimeReader( fs ) )
				{
					// read root mime entity from file
					try
					{
						Entity root = reader.Read();
						if( root != null )
						{
							BindEntity( root );
						}
					}
					catch( Exception ex )
					{
						MessageBox.Show( this, ex.Message, "MIME Error", MessageBoxButtons.OK, MessageBoxIcon.Error );
					}
				}
			}
		}

		private void BindEntity( Entity entity )
		{
			statusBarPanel.Text = "Loading MIME document..";
			tvBodyParts.BeginUpdate();
			AddBodyPart( null, entity );
			tvBodyParts.EndUpdate();
			BindHeaders( entity );
			statusBarPanel.Text = "Ready";
		}

		private void BindHeaders( Entity entity )
		{
			lvHeaders.BeginUpdate();
			lvHeaders.Items.Clear();
			// iterate entity headers and add to list
			foreach( string name in entity.Headers.Names )
			{
				ListViewItem item = new ListViewItem( name );
				item.SubItems.Add( entity.Headers[name].ToString() );
				lvHeaders.Items.Add( item );
			}
			lvHeaders.EndUpdate();
		}

		private const int GB = 1024*1024*1024;
		private const int MB = 1024*1024;
		private const int KB = 1024;
		private static string FormatSize( decimal size )
		{
			if( size > GB )
				return Math.Round( (decimal) size / (decimal) GB, 2 ) + " GB";
			else if( size > MB )
				return Math.Round( (decimal) size / (decimal) MB, 2 ) + " MB";
			else if( size > KB )
				return ((int) Math.Round( (decimal) size / (decimal) KB, 2 )) + " KB";

			return ((int) size) + " B";
		}

		private void AddBodyPart( TreeNode parent, Entity entity )
		{
			string text = entity.Headers.ContentType.Type + "/" + 
				entity.Headers.ContentType.SubType + " (" +
				FormatSize( entity.Body.Length ) + ")";
			
			TreeNode node = new TreeNode( text );
			node.Tag = entity;
			
			if( parent == null )
				tvBodyParts.Nodes.Add( node );
			else
				parent.Nodes.Add( node );

			// iterate child enities ("body parts")
			foreach( Entity child in entity.BodyParts )
			{
				AddBodyPart( node, child );
			}
		}

		private void menuSaveAs_Click(object sender, System.EventArgs e)
		{
			if( tvBodyParts.SelectedNode != null )
			{
				Entity entity = tvBodyParts.SelectedNode.Tag as Entity;
				if( entity != null )
				{
					if( entity.Body.Length > 0 &&
						string.Compare( entity.Headers.ContentType.Type, "multipart" ) != 0 )
					{
						if( entity.Headers.ContentDisposition.FileName != null &&
							entity.Headers.ContentDisposition.FileName.Length > 0 )
							saveFileDialog.FileName = entity.Headers.ContentDisposition.FileName;

						if( saveFileDialog.ShowDialog( this ) == DialogResult.OK )
						{
							using( FileStream fs = new FileStream( saveFileDialog.FileName, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.None ) )
							{
								fs.Write( entity.Body, 0, entity.Body.Length );
							}
						}
					}
				}
			}
		}

		private void contextMenu_Popup(object sender, System.EventArgs e)
		{
			menuSaveAs.Enabled = false;
			if( tvBodyParts.SelectedNode != null )
			{
				Entity entity = tvBodyParts.SelectedNode.Tag as Entity;
				if( entity != null )
				{
					menuSaveAs.Enabled = 
						entity.Body.Length > 0 &&
						string.Compare( entity.Headers.ContentType.Type, "multipart" ) != 0;
				}
			}
		}
	}
}
