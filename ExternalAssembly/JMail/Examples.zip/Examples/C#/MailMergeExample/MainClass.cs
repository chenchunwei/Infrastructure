using System;
using System.Collections;
using System.IO;
using Dimac.JMail;
using Dimac.JMail.MailMerge;

namespace MailMergeExample
{
	/// <summary>
	/// This examples demonstrates how to use MailMerge to create e-mail messages.
	/// </summary>
	class MainClass
	{
		[STAThread]
		static void Main(string[] args)
		{
			// set up fake data
			ArrayList mailingList = new ArrayList();
			for( int i = 0; i < 100; i++ )
			{
				SubscriptionEntry entry = new SubscriptionEntry( "Support Dude #" + i, "support" + i + "@dimac.net", "Helsingborg" ); 
				mailingList.Add( entry );
			}

			// set up mailmerge object
			MailMerge mm = new MailMerge();			

			// create template
			mm.Template.From = "test@dimac.net";
			mm.Template.Subject = "Hello, brave new world!";
			mm.Template.BodyText = "Hello <%# Name %>\nSince you live in <%# City %> you are welcome to visit us.";
			mm.Template.To.Add( "<%# EmailAddress %>", "<%# Name %>" );

			// set output directory
			mm.OutputDirectory = Directory.GetCurrentDirectory();

			// create messages
			mm.DataSource = mailingList;
			int count = mm.DataBind();

			Console.WriteLine( "{0} messages created.", count );
		}
	}
}
