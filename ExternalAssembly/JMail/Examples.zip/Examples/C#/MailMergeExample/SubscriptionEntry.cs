using System;

namespace MailMergeExample
{
	public class SubscriptionEntry
	{
		private string m_name;
		private string m_emailAddress;
		private string m_city;

		public SubscriptionEntry( string name, string emailAddress, string city )
		{
			m_name = name;
			m_emailAddress = emailAddress;
			m_city = city;
		}

		public string Name
		{
			get
			{
				return m_name;
			}
		}

		public string EmailAddress
		{
			get
			{
				return m_emailAddress;
			}
		}

		public string City
		{
			get
			{
				return m_city;
			}
		}
	}
}
