using System;
using Dimac.JMail;
using Dimac.JMail.Pop3;

namespace Pop3Example
{
	/// <summary>
	/// This examples hows how to download e-mail messages from a POP3 server using JMail.
	/// </summary>
	class MainClass
	{
		[STAThread]
		static void Main(string[] args)
		{
			Console.WriteLine( new string('=', 79) );
			Console.Write( "Server: " );
			string hostName = Console.ReadLine();
			Console.Write( "User Name: " );
			string userName = Console.ReadLine();
			Console.Write( "Password: " );
			string password = Console.ReadLine();
			Console.WriteLine( new string('=', 79) );

			Console.WriteLine();
			
			using( Pop3 pop3 = new Pop3( hostName, userName, password ) )
			{
				Pop3MessageCollection messages = pop3.Inbox;

				Console.Write( FixedWidth( "Date", 17 ) );
				Console.Write( FixedWidth( "Subject", 31 ) );
				Console.WriteLine( FixedWidth( "From", 31 ) );
				Console.WriteLine( new string('=', 79) );
				foreach( Message message in messages )
				{
					Console.WriteLine( "{0} {1} {2}",
						message.Date.ToString("yyyy-MM-dd HH:mm"),
						FixedWidth( message.Subject, 30 ),
						FixedWidth( message.From.FullName, 30 ) );
				}
			}			
		}

		static string FixedWidth( string s, int length )
		{
			if( s == null )
				return new string( ' ', length );
			
			if( s.Length < length )
				return s.PadRight( length, ' ' );

			return s.Substring( 0, length - 2 ) + "..";
		}
	}
}
