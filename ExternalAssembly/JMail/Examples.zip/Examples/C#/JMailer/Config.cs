using System;
using System.IO;
using System.Collections.Specialized;
using System.Text;
using System.Xml;

namespace JMailer
{
	/// <summary>
	/// Simple utility class for handling application configuration.
	/// </summary>
	/// <remarks>
	/// Please not that this class has nothing to do with jmail - It's just for this example.
	/// </remarks>
	internal class Config
	{
		/// <summary>
		/// We only want one instance of this class.
		/// </summary>
		public static Config Singleton = new Config();

		/// <summary>
		/// Contains the application settings.
		/// </summary>
		private NameValueCollection m_settings;

		/// <summary>
		/// Private constructor since we only want one instance.
		/// The Config class automatically loads settings directly when initialized.
		/// Be ware of that this constructor might throw an exception if the data in the config file is invalid.
		/// </summary>
		private Config()
		{
			m_settings = new NameValueCollection();
			
			if( File.Exists( FileName ) )
			{
				XmlDocument xml = new XmlDocument();
				xml.Load( FileName );

				foreach( XmlNode node in xml.DocumentElement.ChildNodes )
				{
					m_settings.Add( node.Name, node.InnerText );
				}
			}
		}

		/// <summary>
		/// Saves the settings to an xml-file.
		/// </summary>
		public void Save()
		{
			using( StreamWriter writer = new StreamWriter( FileName, false, Encoding.UTF8 ) )
			{
				XmlTextWriter xml = new XmlTextWriter( writer );
				xml.WriteStartDocument();
				xml.WriteStartElement("configuration");

				foreach( string name in m_settings.AllKeys )
				{
					xml.WriteStartElement( name );
					xml.WriteString( m_settings[name] );
					xml.WriteEndElement();
				}

				xml.WriteEndElement();
				xml.WriteEndDocument();
			}
		}

		/// <summary>
		/// Gets a value from the settings.
		/// </summary>
		/// <param name="name">Name of the value.</param>
		/// <param name="defaultValue">Default value if the name does not exist.</param>
		/// <returns>The requested value.</returns>
		public string GetValue( string name, string defaultValue )
		{
			string s = m_settings[name];
			if( s == null )
				return defaultValue;
			return s;
		}

		/// <summary>
		/// Sets the value in the settings.
		/// </summary>
		/// <param name="name">Name of the value.</param>
		/// <param name="value">The value.</param>
		public void SetValue( string name, string value )
		{
			m_settings[name] = value;
		}

		/// <summary>
		/// Config file name.
		/// </summary>
		public string FileName
		{
			get
			{
				return Path.Combine( AppDomain.CurrentDomain.BaseDirectory,
					"jmailer.config" );
			}
		}
	}
}
