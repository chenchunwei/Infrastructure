Description:
	A very simple mail application that retrieves and sends e-mails using the JMail component.

Remarks:
	This sample is preferably compiled and edited with Microsoft Visual Studio 2003.

Depends on:
	JMail.NET Professional Version
	* Dimac.JMail.dll
	* Dimac.JMail.Smtp.dll
	* Dimac.JMail.Pop3.dll
