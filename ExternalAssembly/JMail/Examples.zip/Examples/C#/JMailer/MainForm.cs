using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
using System.Data;
using System.Web;
using System.Text.RegularExpressions;
using Dimac.JMail;
using mshtml;

namespace JMailer
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem menuFile;
		private System.Windows.Forms.MenuItem menuFileExit;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuFilePreferences;
		private System.Windows.Forms.ListView lvMail;
		private System.Windows.Forms.ColumnHeader chFrom;
		private System.Windows.Forms.ColumnHeader chSubject;
		private System.Windows.Forms.ColumnHeader chDateReceived;
		private System.Windows.Forms.Splitter splitterHorizontal;
		private System.Windows.Forms.MenuItem menuMail;
		private System.Windows.Forms.MenuItem menuMailDelete;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuMailRefresh;
		private System.Windows.Forms.MenuItem menuMailNewMessage;
		private AxSHDocVw.AxWebBrowser axwbMailBody;
		private System.Windows.Forms.Panel pAttachments;
		private System.Windows.Forms.SaveFileDialog saveFileDialog;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;	

		// The JMail POP3 client class.
		private Pop3 m_pop3;		

		// Regex for resolving content-id's in HTML e-mails.
		private Regex m_regexInlineAttachments = new Regex(
			@"cid\:(?<cid>.+)", RegexOptions.Multiline|RegexOptions.Compiled );

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
	
			// Make sure that our temporary directory for inline attachment exists
			string tempPath = Path.Combine( AppDomain.CurrentDomain.BaseDirectory, "temp" );
			if( !Directory.Exists( tempPath ) )
				Directory.CreateDirectory( tempPath );

			ClearMessage();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}

				// dispose JMail POP3 client if it's not already null.
				if( m_pop3 != null )
					m_pop3.Dispose();
			}			
			base.Dispose( disposing );
		}
		

		/// <summary>
		/// This method binds the List View with Messages.
		/// </summary>
		private void BindMessages()
		{
			lvMail.BeginUpdate();
			lvMail.Items.Clear();
			
			// loop all messages in POP3 Inbox
			foreach( Dimac.JMail.Message message in m_pop3.Inbox )
			{
				// tidy from address / name
				string from = null;
				if( message.From.FullName == null || message.From.FullName.Length == 0 )
					from = message.From.Email;
				else
					from = message.From.FullName;

				// create list item
				ListViewItem item = new ListViewItem( from );				
				// add values
				item.SubItems.Add( message.Subject );
				item.SubItems.Add( message.Date.ToString() );

				// add list item to list view control
				lvMail.Items.Add( item );				
			}

			lvMail.EndUpdate();
		}


		/// <summary>
		/// Private helper method who cleans up file names.
		/// </summary>
		/// <param name="path">The file name to clean up.</param>
		/// <returns>The nice path.</returns>
		private static string FixPath( string path )
		{
			return path.Replace("/","_").Replace("\\","_").Replace(":","_").Replace("*","_").Replace("?","_").Replace("\"","_").Replace("<","_").Replace(">","_").Replace("|","_");
		}

		/// <summary>
		/// This method saves all inline attachments in the supplied message to a temporary directory and returns a hashtable with all the Content-ID's as keys and the temporary file path's as values.
		/// </summary>
		/// <param name="msg">The JMail message to save attachments from.</param>
		/// <param name="uidl">The uidl of the message (to create directory with).</param>
		/// <returns>Hashtable containing all content-id's and path's of temporary files.</returns>
		private Hashtable CreateTempInlineAttachments( Dimac.JMail.Message msg, string uidl )
		{			
			if( msg.Attachments.Count > 0 )
			{
				bool hasInline = false;
				foreach( Attachment att in msg.Attachments )
				{
					if( att.ContentID != null && att.ContentID.Length > 0 && 
						att.ContentDisposition.DispositionType == DispositionType.Inline )
					{
						hasInline = true;
						break;
					}
				}

				if( hasInline )
				{					
					string attPath = Path.Combine( AppDomain.CurrentDomain.BaseDirectory,
						"temp\\" + FixPath(uidl) );

					bool exists = Directory.Exists( attPath );

					if( !exists )
						Directory.CreateDirectory( attPath );

					Hashtable result = new Hashtable();
					foreach( Attachment att in msg.Attachments )
					{						
						if( att.ContentDisposition.DispositionType == DispositionType.Inline )
						{
							string cid = att.ContentID;
							if( cid != null && cid.Length > 0 )
							{
								string fileName = Path.Combine( attPath, FixPath(cid) );
								result.Add( cid, fileName );
								if( !exists )
									att.Save( fileName );
							}
						}
					}
					return result;
				}								
			}
			return null;
		}

		/// <summary>
		/// Clears the message view (the body and the attachment panel).
		/// </summary>
		private void ClearMessage()		
		{			
			axwbMailBody.Navigate( "about:blank" );
			pAttachments.Controls.Clear();
			pAttachments.Visible = false;
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.menuFile = new System.Windows.Forms.MenuItem();
			this.menuFilePreferences = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuFileExit = new System.Windows.Forms.MenuItem();
			this.menuMail = new System.Windows.Forms.MenuItem();
			this.menuMailNewMessage = new System.Windows.Forms.MenuItem();
			this.menuMailDelete = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuMailRefresh = new System.Windows.Forms.MenuItem();
			this.lvMail = new System.Windows.Forms.ListView();
			this.chFrom = new System.Windows.Forms.ColumnHeader();
			this.chSubject = new System.Windows.Forms.ColumnHeader();
			this.chDateReceived = new System.Windows.Forms.ColumnHeader();
			this.splitterHorizontal = new System.Windows.Forms.Splitter();
			this.axwbMailBody = new AxSHDocVw.AxWebBrowser();
			this.pAttachments = new System.Windows.Forms.Panel();
			this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
			((System.ComponentModel.ISupportInitialize)(this.axwbMailBody)).BeginInit();
			this.SuspendLayout();
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuFile,
																					 this.menuMail});
			// 
			// menuFile
			// 
			this.menuFile.Index = 0;
			this.menuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuFilePreferences,
																					 this.menuItem1,
																					 this.menuFileExit});
			this.menuFile.Text = "&File";
			// 
			// menuFilePreferences
			// 
			this.menuFilePreferences.Index = 0;
			this.menuFilePreferences.Text = "&Preferences..";
			this.menuFilePreferences.Click += new System.EventHandler(this.menuFilePreferences_Click);
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 1;
			this.menuItem1.Text = "-";
			// 
			// menuFileExit
			// 
			this.menuFileExit.Index = 2;
			this.menuFileExit.Text = "&Exit";
			this.menuFileExit.Click += new System.EventHandler(this.menuFileExit_Click);
			// 
			// menuMail
			// 
			this.menuMail.Index = 1;
			this.menuMail.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuMailNewMessage,
																					 this.menuMailDelete,
																					 this.menuItem4,
																					 this.menuMailRefresh});
			this.menuMail.Text = "&Mail";
			// 
			// menuMailNewMessage
			// 
			this.menuMailNewMessage.Index = 0;
			this.menuMailNewMessage.Text = "&New Message..";
			this.menuMailNewMessage.Click += new System.EventHandler(this.menuMailNewMessage_Click);
			// 
			// menuMailDelete
			// 
			this.menuMailDelete.Index = 1;
			this.menuMailDelete.Text = "&Delete";
			this.menuMailDelete.Click += new System.EventHandler(this.menuMailDelete_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 2;
			this.menuItem4.Text = "-";
			// 
			// menuMailRefresh
			// 
			this.menuMailRefresh.Index = 3;
			this.menuMailRefresh.Text = "&Refresh";
			this.menuMailRefresh.Click += new System.EventHandler(this.menuMailRefresh_Click);
			// 
			// lvMail
			// 
			this.lvMail.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																					 this.chFrom,
																					 this.chSubject,
																					 this.chDateReceived});
			this.lvMail.Dock = System.Windows.Forms.DockStyle.Top;
			this.lvMail.FullRowSelect = true;
			this.lvMail.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.lvMail.Location = new System.Drawing.Point(0, 0);
			this.lvMail.Name = "lvMail";
			this.lvMail.Size = new System.Drawing.Size(488, 152);
			this.lvMail.TabIndex = 0;
			this.lvMail.View = System.Windows.Forms.View.Details;
			this.lvMail.SelectedIndexChanged += new System.EventHandler(this.lvMail_SelectedIndexChanged);
			// 
			// chFrom
			// 
			this.chFrom.Text = "From";
			this.chFrom.Width = 140;
			// 
			// chSubject
			// 
			this.chSubject.Text = "Subject";
			this.chSubject.Width = 180;
			// 
			// chDateReceived
			// 
			this.chDateReceived.Text = "Date Received";
			this.chDateReceived.Width = 120;
			// 
			// splitterHorizontal
			// 
			this.splitterHorizontal.Dock = System.Windows.Forms.DockStyle.Top;
			this.splitterHorizontal.Location = new System.Drawing.Point(0, 152);
			this.splitterHorizontal.Name = "splitterHorizontal";
			this.splitterHorizontal.Size = new System.Drawing.Size(488, 3);
			this.splitterHorizontal.TabIndex = 1;
			this.splitterHorizontal.TabStop = false;
			// 
			// axwbMailBody
			// 
			this.axwbMailBody.Dock = System.Windows.Forms.DockStyle.Fill;
			this.axwbMailBody.Enabled = true;
			this.axwbMailBody.Location = new System.Drawing.Point(0, 155);
			this.axwbMailBody.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axwbMailBody.OcxState")));
			this.axwbMailBody.Size = new System.Drawing.Size(488, 262);
			this.axwbMailBody.TabIndex = 2;
			// 
			// pAttachments
			// 
			this.pAttachments.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.pAttachments.Location = new System.Drawing.Point(0, 393);
			this.pAttachments.Name = "pAttachments";
			this.pAttachments.Size = new System.Drawing.Size(488, 24);
			this.pAttachments.TabIndex = 3;
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(488, 417);
			this.Controls.Add(this.pAttachments);
			this.Controls.Add(this.axwbMailBody);
			this.Controls.Add(this.splitterHorizontal);
			this.Controls.Add(this.lvMail);
			this.Menu = this.mainMenu;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "JMailer";
			((System.ComponentModel.ISupportInitialize)(this.axwbMailBody)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		/// <summary>
		/// File->Exit menu.
		/// </summary>
		private void menuFileExit_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		/// <summary>
		/// File->Preferences menu.
		/// </summary>
		private void menuFilePreferences_Click(object sender, System.EventArgs e)
		{
			PreferencesForm form = new PreferencesForm();
			form.ShowDialog( this );
		}

		/// <summary>
		/// Mail->Refresh menu.
		/// </summary>
		/// <remarks>
		/// Since this only is an example this method is pretty naive and downloads all 
		/// the messages in your POP3 inbox every time you press Refresh in the menu.
		/// For a real application you would probably want to build some form of local caching of messages.
		/// </remarks>
		private void menuMailRefresh_Click(object sender, System.EventArgs e)
		{
			Cursor = Cursors.WaitCursor;
			
			ClearMessage();

			// if we already got a pop3 connection - kill it.
			if( m_pop3 != null )
				m_pop3.Close();

			// connect to the pop3 server as described in the config settings.
			m_pop3 = new Pop3( 
				Config.Singleton.GetValue( "pop3.hostname", "localhost" ), 
				short.Parse( Config.Singleton.GetValue( "pop3.port", "110" ) ), 
				Config.Singleton.GetValue( "pop3.username", "" ),
				Config.Singleton.GetValue( "pop3.password", "" ) );
			
			// display the messages in our list view.
			BindMessages();					

			Cursor = Cursors.Default;
		}

		/// <summary>
		/// This method is called when a message is selected in the list view.
		/// </summary>
		private void lvMail_SelectedIndexChanged( object sender, System.EventArgs e )
		{
			// if we for some odd reason hasn't got any seleted message - return back.
			if( lvMail.SelectedIndices.Count == 0 )
				return;

			Cursor = Cursors.WaitCursor;

			int index = lvMail.SelectedIndices[0];
			if( index >= 0 && index < m_pop3.Inbox.Count )
			{
				// download the FULL message (headers AND body AND attachments) from the server.
				// this might take a while..
				Dimac.JMail.Message msg = m_pop3.Inbox.DownloadFullMessage( index );				
				// if the message is null for some reason,
				// clear the form and return.
				if( msg == null )
				{
					ClearMessage();
					Cursor = Cursors.Default;
					return;
				}
				// get the uidl for this message from the POP3 server.
				string uidl = m_pop3.Inbox.Uidl( index );

				// temporarily save inline attachments (if there are any).
				Hashtable inline = CreateTempInlineAttachments( msg, uidl );

				// clear body
				axwbMailBody.Navigate( "about:blank" );
				// get document object to write to body
				IHTMLDocument2 doc = (IHTMLDocument2) axwbMailBody.Document;

				// write standard headers,
				// such as From, Subject, Date and so on.
				doc.write( "<html><body>" );
				doc.write( "<strong>From:</strong> " + HttpUtility.HtmlEncode( msg.From ) + "<br>" );
				doc.write( "<strong>Subject:</strong> " + HttpUtility.HtmlEncode( msg.Subject ) + "<br>" );
				doc.write( "<strong>Date:</strong> " + msg.Date.ToString() + "<br>" );
				doc.write( "<strong>To:</strong> " + HttpUtility.HtmlEncode( msg.To.ToString() ) + "<br>" );
				if( msg.Cc.Count > 0 )
					doc.write( "<strong>CC:</strong> " + HttpUtility.HtmlEncode( msg.Cc.ToString() ) + "<br>" );
				if( msg.Bcc.Count > 0 )
					doc.write( "<strong>BCC:</strong> " + HttpUtility.HtmlEncode( msg.Bcc.ToString() ) + "<br>" );
				Priority p = msg.Priority;
				if( p != Priority.None )
					doc.write( "<strong>Priority:</strong> " + p.ToString() + "<br>" );
				doc.write( "<hr></body></html>" );


				// handle html body
				bool hasHtml = false;
				if( msg.BodyHtml != null && msg.BodyHtml.Length > 0 )
				{
					string html = msg.BodyHtml;
					// if we have any inline messages, we have to look for them in the HTML body and replace them with a real url.
					if( inline != null )
					{
						// foreach content-id in inline attachments
						foreach( string cid in inline.Keys )
						{
							// use regex to replace it with a real url.
							html = html.Replace( "cid:" + cid, (string)inline[cid] );
						}
					}
					
					// write html to document
					doc.write( html );
					hasHtml = true;
				}
				else
				{
					doc.write( "<html><body></body></html>" );
				}
				
				// handle text body if there is any
				if( msg.BodyText != null && msg.BodyText.Length > 0 )
				{
					doc.write( "<html><body>" );
					if( hasHtml )
						doc.write( "<hr>" );
					doc.write( "<pre>" + HttpUtility.HtmlEncode( msg.BodyText ) + "</pre></body></html>" );
				}

				// print attachments for saving to disk
				if( pAttachments.Visible = msg.Attachments.Count > 0 )
				{
					pAttachments.Controls.Clear();
					int left = 4;
					foreach( Attachment att in msg.Attachments )
					{
						LinkLabel lbl = new LinkLabel();
						lbl.Name = "lAtt" + Guid.NewGuid().ToString("n");
						pAttachments.Controls.Add( lbl );
						lbl.Text = att.FileName;
						lbl.AutoSize = true;
						lbl.Tag = att;											
						lbl.Top = 4;
						lbl.Left = left;
						lbl.Click += new EventHandler(lbl_Click);

						left += lbl.Width;
					}
				}
				else
				{
					pAttachments.Controls.Clear();
					pAttachments.Visible = false;
				}

				axwbMailBody.Invalidate();
				axwbMailBody.CtlRefresh();				

				lvMail.Focus();
			}

			Cursor = Cursors.Default;
		}

		/// <summary>
		/// Mail->Delete menu. Deletes the selected message from the server.
		/// </summary>
		/// <remarks>
		/// Please note that you have to Close the current POP3 connection to commit the delete (use the Mail->Refresh menu).
		/// </remarks>		
		private void menuMailDelete_Click(object sender, System.EventArgs e)
		{
			if( lvMail.SelectedIndices.Count > 0 &&
				MessageBox.Show( this, "Are you sure you want to delete the selected messages?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning ) == DialogResult.Yes )
			{
				Cursor = Cursors.WaitCursor;
				for( int i = 0; i < lvMail.SelectedIndices.Count; i++ )
				{
					m_pop3.Inbox.DeleteMessageFromServer( lvMail.SelectedIndices[i] );
				}
				Cursor = Cursors.Default;			

				ClearMessage();

				MessageBox.Show( this, "Selected messages has been deleted, please refresh your inbox to see the changes." );
			}
		}

		/// <summary>
		/// Mail->New Message menu. Displays the new message form.
		/// </summary>
		private void menuMailNewMessage_Click(object sender, System.EventArgs e)
		{
			NewMessageForm form = new NewMessageForm();
			form.ShowDialog();			
		}

		/// <summary>
		/// Handles the event that's fired when an attachment is clicked. Displays the save file dialog.
		/// </summary>
		private void lbl_Click(object sender, EventArgs e)
		{
			LinkLabel lbl = (LinkLabel) sender;
			Attachment att = (Attachment) lbl.Tag;

			saveFileDialog.FileName = att.FileName;
			if( saveFileDialog.ShowDialog( this ) == DialogResult.OK )
			{
				att.Save( saveFileDialog.FileName );
			}
		}
	}
}
