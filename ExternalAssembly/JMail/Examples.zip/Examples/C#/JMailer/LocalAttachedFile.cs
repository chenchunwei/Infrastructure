using System;
using System.IO;

namespace JMailer
{
	/// <summary>
	/// Private class representing an attached file to send in a message.
	/// </summary>
	/// <remarks>
	/// Please not that this class has nothing to do with jmail - It's just for this example.
	/// </remarks>
	internal class LocalAttachedFile
	{
		/// <summary>
		/// Path of the file to attach.
		/// </summary>
		private string m_path;
		/// <summary>
		/// Boolean telling us if this is an inline attachment or not.
		/// </summary>
		private bool m_inline;
		/// <summary>
		/// If this is an inline file, we want a content-id, this is it.
		/// </summary>
		private string m_contentId;

		/// <summary>
		/// Constructor. Creates a new attachment.
		/// </summary>
		/// <param name="path">Path of the file to attach.</param>
		public LocalAttachedFile( string path )
		{
			if( !File.Exists( path ) )
				throw new FileNotFoundException();

			m_path = path;
			m_inline = false;
			m_contentId = null;
		}

		/// <summary>
		/// Gets and sets the path of the file to add.
		/// </summary>
		public string Path
		{
			get
			{
				return m_path;
			}
			set
			{
				if( !File.Exists( value ) )
					throw new FileNotFoundException();

				m_path = value;
			}
		}

		/// <summary>
		/// Gets and sets the inline value.
		/// </summary>
		public bool Inline
		{
			get
			{
				return m_inline;
			}
			set
			{
				m_inline = value;
				if( !value )
				{
					m_contentId = null;
				}
			}
		}

		/// <summary>
		/// Gets and sets the content-id.
		/// </summary>
		public string ContentId
		{
			get
			{
				return m_contentId;
			}
			set
			{
				if( m_inline )
					m_contentId = value;
			}
		}

		public override string ToString()
		{
			return m_path;
		}
	}
}
