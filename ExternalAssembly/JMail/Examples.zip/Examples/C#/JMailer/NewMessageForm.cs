using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Forms;
using System.Text;
using Dimac.JMail;

namespace JMailer
{
	/// <summary>
	/// This form sends e-mail messages.
	/// </summary>
	public class NewMessageForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ComboBox cbPriority;
		private System.Windows.Forms.TextBox tbTo;
		private System.Windows.Forms.TextBox tbCc;
		private System.Windows.Forms.TextBox tbBcc;
		private System.Windows.Forms.TextBox tbSubject;
		private System.Windows.Forms.Button bSend;
		private System.Windows.Forms.Button bCancel;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ComboBox cbCharset;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.TextBox tbBodyText;
		private System.Windows.Forms.TextBox tbBodyHtml;
		private System.Windows.Forms.ListBox lbAttachments;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.CheckBox cbAttInline;
		private System.Windows.Forms.TextBox tbAttCID;
		private System.Windows.Forms.TextBox tbAttPath;
		private System.Windows.Forms.Button bAddAttachment;
		private System.Windows.Forms.Button bRemoveAttachment;
		private System.Windows.Forms.OpenFileDialog openFileDialog;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Contains common charsets (for use in this form).
		/// </summary>
		static Hashtable charsets;

		/// <summary>
		/// Static constructor makes sure that we only load available charsets once per application.
		/// </summary>
		static NewMessageForm()
		{
			charsets = new Hashtable();
			CultureInfo[] ciList = CultureInfo.GetCultures( CultureTypes.InstalledWin32Cultures );
			foreach( CultureInfo ci in ciList )
			{
				try
				{
					Encoding enc = Encoding.GetEncoding( ci.TextInfo.ANSICodePage );
					if( !charsets.ContainsKey( enc.CodePage ) )
						charsets.Add( enc.CodePage, enc.BodyName );
				}
				catch
				{
				}
			}

			if( !charsets.ContainsKey( Encoding.UTF8.CodePage ) )
				charsets.Add( Encoding.UTF8.CodePage, Encoding.UTF8.BodyName );

			if( !charsets.ContainsKey( Encoding.ASCII.CodePage ) )
				charsets.Add( Encoding.ASCII.CodePage, Encoding.ASCII.BodyName );

			if( !charsets.ContainsKey( Encoding.Default.CodePage ) )
				charsets.Add( Encoding.Default.CodePage, Encoding.Default.BodyName );
		}

		public NewMessageForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.cbPriority = new System.Windows.Forms.ComboBox();
			this.tbTo = new System.Windows.Forms.TextBox();
			this.tbCc = new System.Windows.Forms.TextBox();
			this.tbBcc = new System.Windows.Forms.TextBox();
			this.tbSubject = new System.Windows.Forms.TextBox();
			this.bSend = new System.Windows.Forms.Button();
			this.bCancel = new System.Windows.Forms.Button();
			this.label6 = new System.Windows.Forms.Label();
			this.cbCharset = new System.Windows.Forms.ComboBox();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.tbBodyText = new System.Windows.Forms.TextBox();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.tbBodyHtml = new System.Windows.Forms.TextBox();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.bRemoveAttachment = new System.Windows.Forms.Button();
			this.bAddAttachment = new System.Windows.Forms.Button();
			this.tbAttPath = new System.Windows.Forms.TextBox();
			this.tbAttCID = new System.Windows.Forms.TextBox();
			this.cbAttInline = new System.Windows.Forms.CheckBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.lbAttachments = new System.Windows.Forms.ListBox();
			this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.tabPage3.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "To:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 80);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 16);
			this.label2.TabIndex = 1;
			this.label2.Text = "Subject:";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 104);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(48, 16);
			this.label3.TabIndex = 2;
			this.label3.Text = "Priority:";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 32);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(32, 16);
			this.label4.TabIndex = 4;
			this.label4.Text = "Cc:";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(8, 56);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(40, 16);
			this.label5.TabIndex = 5;
			this.label5.Text = "Bcc:";
			// 
			// cbPriority
			// 
			this.cbPriority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbPriority.Location = new System.Drawing.Point(56, 104);
			this.cbPriority.Name = "cbPriority";
			this.cbPriority.Size = new System.Drawing.Size(128, 21);
			this.cbPriority.TabIndex = 5;
			// 
			// tbTo
			// 
			this.tbTo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbTo.Location = new System.Drawing.Point(56, 8);
			this.tbTo.Name = "tbTo";
			this.tbTo.Size = new System.Drawing.Size(352, 20);
			this.tbTo.TabIndex = 1;
			this.tbTo.Text = "";
			// 
			// tbCc
			// 
			this.tbCc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbCc.Location = new System.Drawing.Point(56, 32);
			this.tbCc.Name = "tbCc";
			this.tbCc.Size = new System.Drawing.Size(352, 20);
			this.tbCc.TabIndex = 2;
			this.tbCc.Text = "";
			// 
			// tbBcc
			// 
			this.tbBcc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbBcc.Location = new System.Drawing.Point(56, 56);
			this.tbBcc.Name = "tbBcc";
			this.tbBcc.Size = new System.Drawing.Size(352, 20);
			this.tbBcc.TabIndex = 3;
			this.tbBcc.Text = "";
			// 
			// tbSubject
			// 
			this.tbSubject.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbSubject.Location = new System.Drawing.Point(56, 80);
			this.tbSubject.Name = "tbSubject";
			this.tbSubject.Size = new System.Drawing.Size(352, 20);
			this.tbSubject.TabIndex = 4;
			this.tbSubject.Text = "";
			// 
			// bSend
			// 
			this.bSend.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.bSend.Location = new System.Drawing.Point(328, 360);
			this.bSend.Name = "bSend";
			this.bSend.TabIndex = 9;
			this.bSend.Text = "Send";
			this.bSend.Click += new System.EventHandler(this.bSend_Click);
			// 
			// bCancel
			// 
			this.bCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.bCancel.Location = new System.Drawing.Point(248, 360);
			this.bCancel.Name = "bCancel";
			this.bCancel.TabIndex = 10;
			this.bCancel.Text = "Cancel";
			this.bCancel.Click += new System.EventHandler(this.bCancel_Click);
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(8, 128);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(48, 16);
			this.label6.TabIndex = 14;
			this.label6.Text = "Charset:";
			// 
			// cbCharset
			// 
			this.cbCharset.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.cbCharset.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbCharset.Location = new System.Drawing.Point(56, 128);
			this.cbCharset.Name = "cbCharset";
			this.cbCharset.Size = new System.Drawing.Size(352, 21);
			this.cbCharset.TabIndex = 6;
			// 
			// tabControl1
			// 
			this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Location = new System.Drawing.Point(8, 152);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(400, 200);
			this.tabControl1.TabIndex = 15;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.tbBodyText);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(392, 174);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Text Body";
			// 
			// tbBodyText
			// 
			this.tbBodyText.AcceptsReturn = true;
			this.tbBodyText.AcceptsTab = true;
			this.tbBodyText.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tbBodyText.Location = new System.Drawing.Point(0, 0);
			this.tbBodyText.Multiline = true;
			this.tbBodyText.Name = "tbBodyText";
			this.tbBodyText.Size = new System.Drawing.Size(392, 174);
			this.tbBodyText.TabIndex = 0;
			this.tbBodyText.Text = "";
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.tbBodyHtml);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Size = new System.Drawing.Size(392, 174);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "HTML Body";
			// 
			// tbBodyHtml
			// 
			this.tbBodyHtml.AcceptsReturn = true;
			this.tbBodyHtml.AcceptsTab = true;
			this.tbBodyHtml.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tbBodyHtml.Location = new System.Drawing.Point(0, 0);
			this.tbBodyHtml.Multiline = true;
			this.tbBodyHtml.Name = "tbBodyHtml";
			this.tbBodyHtml.Size = new System.Drawing.Size(392, 174);
			this.tbBodyHtml.TabIndex = 1;
			this.tbBodyHtml.Text = "";
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.bRemoveAttachment);
			this.tabPage3.Controls.Add(this.bAddAttachment);
			this.tabPage3.Controls.Add(this.tbAttPath);
			this.tabPage3.Controls.Add(this.tbAttCID);
			this.tabPage3.Controls.Add(this.cbAttInline);
			this.tabPage3.Controls.Add(this.label8);
			this.tabPage3.Controls.Add(this.label7);
			this.tabPage3.Controls.Add(this.lbAttachments);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(392, 174);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Attachments";
			// 
			// bRemoveAttachment
			// 
			this.bRemoveAttachment.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.bRemoveAttachment.Location = new System.Drawing.Point(80, 144);
			this.bRemoveAttachment.Name = "bRemoveAttachment";
			this.bRemoveAttachment.Size = new System.Drawing.Size(64, 23);
			this.bRemoveAttachment.TabIndex = 7;
			this.bRemoveAttachment.Text = "Remove";
			this.bRemoveAttachment.Click += new System.EventHandler(this.bRemoveAttachment_Click);
			// 
			// bAddAttachment
			// 
			this.bAddAttachment.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.bAddAttachment.Location = new System.Drawing.Point(8, 144);
			this.bAddAttachment.Name = "bAddAttachment";
			this.bAddAttachment.Size = new System.Drawing.Size(64, 23);
			this.bAddAttachment.TabIndex = 6;
			this.bAddAttachment.Text = "Add";
			this.bAddAttachment.Click += new System.EventHandler(this.bAddAttachment_Click);
			// 
			// tbAttPath
			// 
			this.tbAttPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbAttPath.Enabled = false;
			this.tbAttPath.Location = new System.Drawing.Point(216, 16);
			this.tbAttPath.Name = "tbAttPath";
			this.tbAttPath.Size = new System.Drawing.Size(160, 20);
			this.tbAttPath.TabIndex = 5;
			this.tbAttPath.Text = "";
			// 
			// tbAttCID
			// 
			this.tbAttCID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbAttCID.Location = new System.Drawing.Point(216, 56);
			this.tbAttCID.Name = "tbAttCID";
			this.tbAttCID.Size = new System.Drawing.Size(160, 20);
			this.tbAttCID.TabIndex = 4;
			this.tbAttCID.Text = "";
			this.tbAttCID.TextChanged += new System.EventHandler(this.tbAttCID_TextChanged);
			// 
			// cbAttInline
			// 
			this.cbAttInline.Location = new System.Drawing.Point(152, 32);
			this.cbAttInline.Name = "cbAttInline";
			this.cbAttInline.Size = new System.Drawing.Size(56, 24);
			this.cbAttInline.TabIndex = 3;
			this.cbAttInline.Text = "Inline";
			this.cbAttInline.CheckedChanged += new System.EventHandler(this.cbAttInline_CheckedChanged);
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(152, 56);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(64, 16);
			this.label8.TabIndex = 2;
			this.label8.Text = "Content-ID:";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(152, 16);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(48, 16);
			this.label7.TabIndex = 1;
			this.label7.Text = "Path:";
			// 
			// lbAttachments
			// 
			this.lbAttachments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left)));
			this.lbAttachments.Location = new System.Drawing.Point(8, 8);
			this.lbAttachments.Name = "lbAttachments";
			this.lbAttachments.Size = new System.Drawing.Size(136, 134);
			this.lbAttachments.TabIndex = 0;
			this.lbAttachments.SelectedIndexChanged += new System.EventHandler(this.lbAttachments_SelectedIndexChanged);
			// 
			// openFileDialog
			// 
			this.openFileDialog.Filter = "All Files (*.*)|*.*";
			// 
			// NewMessageForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(416, 390);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.cbCharset);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.bCancel);
			this.Controls.Add(this.bSend);
			this.Controls.Add(this.tbSubject);
			this.Controls.Add(this.tbBcc);
			this.Controls.Add(this.tbCc);
			this.Controls.Add(this.tbTo);
			this.Controls.Add(this.cbPriority);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.MinimumSize = new System.Drawing.Size(424, 424);
			this.Name = "NewMessageForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Compose Mail..";
			this.Load += new System.EventHandler(this.NewMessageForm_Load);
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.tabPage3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Initializes the form, loads Priorities and charsets.
		/// </summary>
		private void NewMessageForm_Load(object sender, System.EventArgs e)
		{
			cbPriority.DataSource = Enum.GetValues(typeof(Priority));
			
			foreach( int codePage in charsets.Keys )
			{
				cbCharset.Items.Add( charsets[codePage] );
			}
			cbCharset.SelectedIndex = cbCharset.Items.IndexOf( Encoding.Default.BodyName );
			
			tbAttCID.Enabled = false;
		}

		/// <summary>
		/// Closes the form without sending the e-mail message.
		/// </summary>
		private void bCancel_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		/// <summary>
		/// Sends an e-mail message and closes the form.
		/// </summary>
		private void bSend_Click(object sender, System.EventArgs e)
		{
			try
			{
				// create a JMail Message
				Dimac.JMail.Message message = new Dimac.JMail.Message();

				// set the From: adress (get it from the configuration file)
				message.From.FullName = Config.Singleton.GetValue( "smtp.fullname", "" );
				message.From.Email = Config.Singleton.GetValue( "smtp.email", "" );

				// set the To: recipients, get value from the textbox in the form
				string[] temp = tbTo.Text.Split(new char[]{',',';'});
				foreach( string s in temp )
					if( s.Trim().Length > 0 )
						message.To.Add( Address.Parse( s.Trim() ) );

				// set the Cc: recipients, get value from the textbox in the form
				temp = tbCc.Text.Split(new char[]{',',';'});
				foreach( string s in temp )
					if( s.Trim().Length > 0 )
						message.Cc.Add( Address.Parse( s.Trim() ) );

				// set the Bcc: recipients, get value from the textbox in the form
				temp = tbBcc.Text.Split(new char[]{',',';'});
				foreach( string s in temp )
					if( s.Trim().Length > 0 )
						message.Bcc.Add( Address.Parse( s.Trim() ) );

				// set the Subject, get value from the textbox in the form
				message.Subject = tbSubject.Text;

				// set the message Priority, get value from the form
				if( cbPriority.SelectedIndex > 0 )
				{
					message.Priority = (Priority) cbPriority.SelectedValue;
				}

				// set message charset, get value from he form
				message.Charset = Encoding.GetEncoding( cbCharset.SelectedItem.ToString() );
				
				// set HTML and TEXT body's from form
				message.BodyText = tbBodyText.Text;
				message.BodyHtml = tbBodyHtml.Text;

				// add attachments
				foreach( LocalAttachedFile file in lbAttachments.Items )
				{
					if( file.Inline )
					{
						message.Attachments.AddInlineAttachment( file.Path, file.ContentId );
					}
					else
					{
						message.Attachments.Add( file.Path );
					}
				}

				// make sure that we have at least one recipient
				if( message.To.Count < 0 && message.Cc.Count < 0 && message.Bcc.Count < 0 )
					throw new Exception("No recipients was supplied.");

				// get HELO domain from senders e-mail address
				// WARNING: this might not work for all mail servers, but the odds are good that it will.
				string heloDomain = null;
				if( message.From.Email != null && message.From.Email.Length > 0 )
				{
					int idx = message.From.Email.IndexOf("@");
					if( idx != -1 )
					{
						heloDomain = message.From.Email.Substring( idx + 1 );
					}
				}

				// send the message using configuration settings
				Smtp.Send( message,
					Config.Singleton.GetValue( "smtp.hostname", "localhost" ), 
					short.Parse(Config.Singleton.GetValue( "smtp.port", "25" )), 
					heloDomain, 
					(SmtpAuthentication) Enum.Parse( typeof(SmtpAuthentication), Config.Singleton.GetValue( "smtp.authentication", "None" ) ), 
					Config.Singleton.GetValue( "smtp.username", "" ), 
					Config.Singleton.GetValue( "smtp.password", "" ) );

				Close();
			}
			catch( Exception ex )
			{
				// on exceptions - popup a messagebox displaying error message
				MessageBox.Show( this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error );
			}			
		}

		/// <summary>
		/// Adds an attachment
		/// </summary>
		private void bAddAttachment_Click(object sender, System.EventArgs e)
		{
			if( openFileDialog.ShowDialog( this ) == DialogResult.OK )
			{
				try
				{
					LocalAttachedFile file = new LocalAttachedFile( openFileDialog.FileName );

					lbAttachments.BeginUpdate();
					lbAttachments.Items.Add( file );
					lbAttachments.EndUpdate();
				}
				catch( Exception ex )
				{
					MessageBox.Show( this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error ); 
				}
			}
		}

		/// <summary>
		/// Removes an attachment.
		/// </summary>
		private void bRemoveAttachment_Click(object sender, System.EventArgs e)
		{
			if( lbAttachments.SelectedIndex >= 0 && lbAttachments.SelectedIndex < lbAttachments.Items.Count )
			{
				lbAttachments.BeginUpdate();
				lbAttachments.Items.RemoveAt( lbAttachments.SelectedIndex );
				lbAttachments.EndUpdate();
			}
		}

		/// <summary>
		/// Set up attachment form for editing selected attachment
		/// </summary>
		private void lbAttachments_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if( lbAttachments.SelectedIndex >= 0 && lbAttachments.SelectedIndex < lbAttachments.Items.Count )
			{
				LocalAttachedFile file = lbAttachments.SelectedItem as LocalAttachedFile;
				if( file != null )
				{
					tbAttPath.Text = file.Path;
					tbAttCID.Enabled = cbAttInline.Checked = file.Inline;
					tbAttCID.Text = file.ContentId;
				}
			}
		}

		/// <summary>
		/// On inline checked-changed
		/// </summary>
		private void cbAttInline_CheckedChanged(object sender, System.EventArgs e)
		{
			tbAttCID.Enabled = cbAttInline.Checked;
			if( lbAttachments.SelectedIndex >= 0 && lbAttachments.SelectedIndex < lbAttachments.Items.Count )
			{
				LocalAttachedFile file = lbAttachments.SelectedItem as LocalAttachedFile;
				if( file != null )
				{
					file.Inline = cbAttInline.Checked;
				}
			}
		}

		/// <summary>
		/// On content-id-changed
		/// </summary>
		private void tbAttCID_TextChanged(object sender, System.EventArgs e)
		{
			if( lbAttachments.SelectedIndex >= 0 && lbAttachments.SelectedIndex < lbAttachments.Items.Count )
			{
				LocalAttachedFile file = lbAttachments.SelectedItem as LocalAttachedFile;
				if( file != null )
				{
					file.ContentId = tbAttCID.Text;
				}
			}
		}
	}
}
