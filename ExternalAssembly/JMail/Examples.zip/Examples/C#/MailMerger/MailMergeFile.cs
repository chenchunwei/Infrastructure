using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Xml;
using Dimac.JMail;

namespace MailMerger
{
	/// <summary>
	/// Represents the data used for setting up mailmerge. Can be saved and loaded from a file.
	/// </summary>
	/// <remarks>
	/// This class has nothing to do with Dimac.JMail.MailMerge - it's just for this example.
	/// </remarks>
	public class MailMergeFile
	{
		private string m_fileName;
		
		private string m_toEmail;
		private string m_toFullName;
		private string m_fromEmail;
		private string m_fromFullName;
		private Priority m_priority;
		private Encoding m_charset;
		private string m_subject;
		private string m_bodyText;
		private string m_bodyHtml;
		private ArrayList m_attachments;

		private string m_connectionString;
		private string m_sql;

		private int m_outputMethod;

		private string m_outputDirectory;

		private string m_outputSmtpHostName;
		private int m_outputSmtpPort;
		private string m_outputSmtpHelo;
		private SmtpAuthentication m_outputSmtpAuth;
		private string m_outputSmtpUserName;
		private string m_outputSmtpPassword;		

		/// <summary>
		/// Constructor.
		/// </summary>
		public MailMergeFile()
		{
			m_fileName = null;
			
			m_toEmail = string.Empty;
			m_toFullName = string.Empty;
			m_fromEmail = string.Empty;
			m_fromFullName = string.Empty;
			m_priority = Priority.None;
			m_charset = Encoding.Default;
			m_subject = string.Empty;
			m_bodyText = string.Empty;
			m_bodyHtml = string.Empty;
			m_attachments = new ArrayList();

			m_connectionString = string.Empty;
			m_sql = string.Empty;

			m_outputMethod = 0;

			m_outputDirectory = string.Empty;

			m_outputSmtpHostName = string.Empty;
			m_outputSmtpPort = 0;
			m_outputSmtpHelo = string.Empty;
			m_outputSmtpAuth = SmtpAuthentication.None;
			m_outputSmtpUserName = string.Empty;
			m_outputSmtpPassword = string.Empty;
		}

		/// <summary>
		/// Loads the MailMergeFile from disk.
		/// </summary>		
		public void Load( string fileName )
		{						
			XmlDocument xml = new XmlDocument();
			xml.Load( fileName );

			m_toEmail = xml.SelectSingleNode("/mailMerge/template/to/email").InnerText;
			m_toFullName = xml.SelectSingleNode("/mailMerge/template/to/fullName").InnerText;
			m_fromEmail = xml.SelectSingleNode("/mailMerge/template/from/email").InnerText;
			m_fromFullName = xml.SelectSingleNode("/mailMerge/template/from/fullName").InnerText;
			m_priority = (Priority) Enum.Parse( typeof(Priority), xml.SelectSingleNode("/mailMerge/template/priority").InnerText );
			m_charset = Encoding.GetEncoding( xml.SelectSingleNode("/mailMerge/template/charset").InnerText );
			m_subject = xml.SelectSingleNode("/mailMerge/template/subject").InnerText;
			m_bodyText = xml.SelectSingleNode("/mailMerge/template/bodyText").InnerText;
			m_bodyHtml = xml.SelectSingleNode("/mailMerge/template/bodyHtml").InnerText;

			m_attachments = new ArrayList();
			XmlNodeList nodes = xml.SelectNodes("/mailMerge/template/attachments/attachment");
			foreach( XmlNode node in nodes )
			{
				LocalAttachedFile file = new LocalAttachedFile(
					node.SelectSingleNode("path").InnerText,
					XmlConvert.ToBoolean( node.SelectSingleNode("inline").InnerText ),
					node.SelectSingleNode("contentId").InnerText );
				m_attachments.Add( file );
			}

			m_connectionString = xml.SelectSingleNode("/mailMerge/dataSource/connectionString").InnerText;
			m_sql = xml.SelectSingleNode("/mailMerge/dataSource/sql").InnerText;

			m_outputMethod = XmlConvert.ToInt32( xml.SelectSingleNode("/mailMerge/output/method").InnerText );

			m_outputDirectory = xml.SelectSingleNode("/mailMerge/output/directory").InnerText;

			m_outputSmtpHostName = xml.SelectSingleNode("/mailMerge/output/smtp/hostName").InnerText;			
			m_outputSmtpPort = XmlConvert.ToInt32( xml.SelectSingleNode("/mailMerge/output/smtp/port").InnerText );
			m_outputSmtpHelo = xml.SelectSingleNode("/mailMerge/output/smtp/helo").InnerText;
			m_outputSmtpAuth = (SmtpAuthentication) Enum.Parse( typeof(SmtpAuthentication), xml.SelectSingleNode("/mailMerge/output/smtp/authentication").InnerText );
			m_outputSmtpUserName = xml.SelectSingleNode("/mailMerge/output/smtp/userName").InnerText;
			m_outputSmtpPassword = Encoding.Default.GetString(Convert.FromBase64String(xml.SelectSingleNode("/mailMerge/output/smtp/password").InnerText));

			m_fileName = fileName;
		}

		/// <summary>
		/// Saves the MailMergeFile to disk.
		/// </summary>
		public void Save( string fileName )
		{
			XmlTextWriter xml = new XmlTextWriter( fileName, Encoding.UTF8 );
			xml.Formatting = Formatting.Indented;
			xml.WriteStartDocument( true );
			xml.WriteStartElement( "mailMerge" );

			xml.WriteStartElement( "template" );
			
			xml.WriteStartElement( "to" );
			xml.WriteStartElement( "email" );
			xml.WriteString( m_toEmail );
			xml.WriteEndElement();
			xml.WriteStartElement( "fullName" );
			xml.WriteString( m_toFullName );
			xml.WriteEndElement();
			xml.WriteEndElement();

			xml.WriteStartElement( "from" );
			xml.WriteStartElement( "email" );
			xml.WriteString( m_fromEmail );
			xml.WriteEndElement();
			xml.WriteStartElement( "fullName" );
			xml.WriteString( m_fromFullName );
			xml.WriteEndElement();
			xml.WriteEndElement();

			xml.WriteStartElement( "priority" );
			xml.WriteString( m_priority.ToString() );
			xml.WriteEndElement();

			xml.WriteStartElement( "charset" );
			xml.WriteString( m_charset.BodyName );
			xml.WriteEndElement();

			xml.WriteStartElement( "subject" );
			xml.WriteString( m_subject );
			xml.WriteEndElement();

			xml.WriteStartElement( "bodyText" );
			xml.WriteString( m_bodyText );
			xml.WriteEndElement();

			xml.WriteStartElement( "bodyHtml" );
			xml.WriteString( m_bodyHtml );
			xml.WriteEndElement();
			
			xml.WriteStartElement( "attachments" );
			foreach( LocalAttachedFile att in m_attachments )
			{
				xml.WriteStartElement( "attachment" );
				xml.WriteStartElement( "path" );
				xml.WriteString( att.Path );
				xml.WriteEndElement();
				xml.WriteStartElement( "inline" );
				xml.WriteString( XmlConvert.ToString(att.Inline) );
				xml.WriteEndElement();
				xml.WriteStartElement( "contentId" );
				xml.WriteString( att.ContentId );
				xml.WriteEndElement();
				xml.WriteEndElement();
			}
			xml.WriteEndElement();

			xml.WriteEndElement();

			xml.WriteStartElement( "dataSource" );
			xml.WriteStartElement( "connectionString" );
			xml.WriteString( m_connectionString );
			xml.WriteEndElement();
			xml.WriteStartElement( "sql" );
			xml.WriteString( m_sql );
			xml.WriteEndElement();
			xml.WriteEndElement();

			xml.WriteStartElement( "output" );

			xml.WriteStartElement( "method" );
			xml.WriteString( XmlConvert.ToString( m_outputMethod ) );
			xml.WriteEndElement();

			xml.WriteStartElement( "directory" );
			xml.WriteString( m_outputDirectory );
			xml.WriteEndElement();

			xml.WriteStartElement( "smtp" );

			xml.WriteStartElement( "hostName" );
			xml.WriteString( m_outputSmtpHostName );
			xml.WriteEndElement();

			xml.WriteStartElement( "port" );
			xml.WriteString( XmlConvert.ToString( m_outputSmtpPort ) );
			xml.WriteEndElement();

			xml.WriteStartElement( "helo" );
			xml.WriteString( m_outputSmtpHelo );
			xml.WriteEndElement();

			xml.WriteStartElement( "authentication" );
			xml.WriteString( m_outputSmtpAuth.ToString() );
			xml.WriteEndElement();

			xml.WriteStartElement( "userName" );
			xml.WriteString( m_outputSmtpUserName );
			xml.WriteEndElement();

			xml.WriteStartElement( "password" );
			// WARNING: password saved "almost" in clear-text..
			xml.WriteString( Convert.ToBase64String( Encoding.Default.GetBytes( m_outputSmtpPassword ) ) );
			xml.WriteEndElement();

			xml.WriteEndElement();

			xml.WriteEndElement();		

			xml.WriteEndElement();
			xml.WriteEndDocument();
			xml.Close();
		}

		public string FileName
		{
			get
			{
				return m_fileName;
			}
			set
			{
				m_fileName = value;
			}
		}

		public string ToEmail
		{
			get
			{
				return m_toEmail;
			}
			set
			{
				m_toEmail = value;
			}
		}

		public string ToFullName
		{
			get
			{
				return m_toFullName;
			}
			set
			{
				m_toFullName = value;
			}
		}

		public string FromEmail
		{
			get
			{
				return m_fromEmail;
			}
			set
			{
				m_fromEmail = value;
			}
		}

		public string FromFullName
		{
			get
			{
				return m_fromFullName;
			}
			set
			{
				m_fromFullName = value;
			}
		}

		public Priority Priority
		{
			get
			{
				return m_priority;
			}
			set
			{
				m_priority = value;
			}
		}

		public Encoding Charset
		{
			get
			{
				return m_charset;
			}
			set
			{
				m_charset = value;
			}
		}

		public string Subject
		{
			get
			{
				return m_subject;
			}
			set
			{
				m_subject = value;
			}
		}

		public string BodyText
		{
			get
			{
				return m_bodyText;
			}
			set
			{
				m_bodyText = value;
			}
		}

		public string BodyHtml
		{
			get
			{
				return m_bodyHtml;
			}
			set
			{
				m_bodyHtml = value;
			}
		}

		public ArrayList Attachments
		{
			get
			{
				return m_attachments;
			}
		}

		public string ConnectionString
		{
			get
			{
				return m_connectionString;
			}
			set
			{
				m_connectionString = value;
			}
		}

		public string Sql
		{
			get
			{
				return m_sql;
			}
			set
			{
				m_sql = value;
			}
		}

		public int OutputMethod
		{
			get
			{
				return m_outputMethod;
			}
			set
			{
				m_outputMethod = value;
			}
		}

		public string OutputDirectory
		{
			get
			{
				return m_outputDirectory;
			}
			set
			{
				m_outputDirectory = value;
			}
		}

		public string OutputSmtpHostName
		{
			get
			{
				return m_outputSmtpHostName;
			}
			set
			{
				m_outputSmtpHostName = value;
			}
		}

		public int OutputSmtpPort
		{
			get
			{
				return m_outputSmtpPort;
			}
			set
			{
				m_outputSmtpPort = value;
			}
		}

		public string OutputSmtpHelo
		{
			get
			{
				return m_outputSmtpHelo;
			}
			set
			{
				m_outputSmtpHelo = value;
			}
		}

		public SmtpAuthentication OutputSmtpAuth
		{
			get
			{
				return m_outputSmtpAuth;
			}
			set
			{
				m_outputSmtpAuth = value;
			}
		}

		public string OutputSmtpUserName
		{
			get
			{
				return m_outputSmtpUserName;
			}
			set
			{
				m_outputSmtpUserName = value;
			}
		}

		public string OutputSmtpPassword
		{
			get
			{
				return m_outputSmtpPassword;
			}
			set
			{
				m_outputSmtpPassword = value;
			}
		}
	}
}
