Description:
	A very simple application that demonstrates the usage of the JMail MailMerge component.

Remarks:
	This sample is preferably compiled and edited with Microsoft Visual Studio 2003.

Requires:
	JMail.NET Standard Version
	* Dimac.JMail.dll
	* Dimac.JMail.MailMerge.dll
	* Dimac.JMail.Smtp.dll
