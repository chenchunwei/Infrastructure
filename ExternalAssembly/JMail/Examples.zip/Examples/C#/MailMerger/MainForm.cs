using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Dimac.JMail;

namespace MailMerger
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem menuFile;
		private System.Windows.Forms.MenuItem menuFileNew;
		private System.Windows.Forms.MenuItem menuFileOpen;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuFileSave;
		private System.Windows.Forms.MenuItem menuFileSaveAs;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuFileExit;
		private System.Windows.Forms.OpenFileDialog openFileDialog;
		private System.Windows.Forms.SaveFileDialog saveFileDialog;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabControl tabControl2;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TextBox tbBodyText;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.TextBox tbBodyHtml;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.Button bRemoveAttachment;
		private System.Windows.Forms.Button bAddAttachment;
		private System.Windows.Forms.TextBox tbAttPath;
		private System.Windows.Forms.TextBox tbAttCID;
		private System.Windows.Forms.CheckBox cbAttInline;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.ListBox lbAttachments;
		private System.Windows.Forms.ComboBox cbCharset;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox tbSubject;
		private System.Windows.Forms.ComboBox cbPriority;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TabPage tabPage5;
		private System.Windows.Forms.TabPage tabPage6;
		private System.Windows.Forms.TextBox tbToAdress;
		private System.Windows.Forms.TextBox tbToName;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.TextBox tbFromName;
		private System.Windows.Forms.TextBox tbFromAddress;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.OpenFileDialog attFileDialog;
		private System.Windows.Forms.TextBox tbConnectionString;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button bTestConnection;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox tbSql;
		private System.Windows.Forms.Button bTestSQL;
		private System.Windows.Forms.TextBox tbOutputDirectory;
		private System.Windows.Forms.TabPage tabPage7;
		private System.Windows.Forms.ProgressBar progressBar;
		private System.Windows.Forms.Button bGenerate;
		private System.Windows.Forms.CheckBox cbIsTest;
		private System.Windows.Forms.RadioButton rbOutputDirectory;
		private System.Windows.Forms.RadioButton rbSmtp;
		private System.Windows.Forms.ComboBox cbAuthentication;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TextBox tbSmtpPassword;
		private System.Windows.Forms.TextBox tbSmtpUserName;
		private System.Windows.Forms.TextBox tbSmtpPort;
		private System.Windows.Forms.TextBox tbSmtpHostName;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.TextBox tbSmtpHelo;

		/// <summary>
		/// The Data.
		/// </summary>
		private MailMergeFile m_file = new MailMergeFile();

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// fill combobox with valid priorities
			cbPriority.DataSource = Enum.GetValues( typeof( Priority ) );

			// fill combobox with valid authentications
			cbAuthentication.DataSource = Enum.GetValues( typeof( SmtpAuthentication ) );
			
			rbOutputDirectory.Checked = true;

			// add valid charsets to combobox
			foreach( int codePage in charsets.Keys )
			{
				cbCharset.Items.Add( charsets[codePage] );
			}
			cbCharset.SelectedIndex = cbCharset.Items.IndexOf( Encoding.Default.BodyName );
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.menuFile = new System.Windows.Forms.MenuItem();
			this.menuFileNew = new System.Windows.Forms.MenuItem();
			this.menuFileOpen = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuFileSave = new System.Windows.Forms.MenuItem();
			this.menuFileSaveAs = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuFileExit = new System.Windows.Forms.MenuItem();
			this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.tbFromName = new System.Windows.Forms.TextBox();
			this.tbFromAddress = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.tbToName = new System.Windows.Forms.TextBox();
			this.tabControl2 = new System.Windows.Forms.TabControl();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.tbBodyText = new System.Windows.Forms.TextBox();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.tbBodyHtml = new System.Windows.Forms.TextBox();
			this.tabPage4 = new System.Windows.Forms.TabPage();
			this.bRemoveAttachment = new System.Windows.Forms.Button();
			this.bAddAttachment = new System.Windows.Forms.Button();
			this.tbAttPath = new System.Windows.Forms.TextBox();
			this.tbAttCID = new System.Windows.Forms.TextBox();
			this.cbAttInline = new System.Windows.Forms.CheckBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.lbAttachments = new System.Windows.Forms.ListBox();
			this.cbCharset = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.tbSubject = new System.Windows.Forms.TextBox();
			this.tbToAdress = new System.Windows.Forms.TextBox();
			this.cbPriority = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.tabPage5 = new System.Windows.Forms.TabPage();
			this.bTestSQL = new System.Windows.Forms.Button();
			this.tbSql = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.bTestConnection = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.tbConnectionString = new System.Windows.Forms.TextBox();
			this.tabPage6 = new System.Windows.Forms.TabPage();
			this.tbOutputDirectory = new System.Windows.Forms.TextBox();
			this.tabPage7 = new System.Windows.Forms.TabPage();
			this.bGenerate = new System.Windows.Forms.Button();
			this.cbIsTest = new System.Windows.Forms.CheckBox();
			this.progressBar = new System.Windows.Forms.ProgressBar();
			this.attFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.rbOutputDirectory = new System.Windows.Forms.RadioButton();
			this.rbSmtp = new System.Windows.Forms.RadioButton();
			this.cbAuthentication = new System.Windows.Forms.ComboBox();
			this.label10 = new System.Windows.Forms.Label();
			this.tbSmtpPassword = new System.Windows.Forms.TextBox();
			this.tbSmtpUserName = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.tbSmtpPort = new System.Windows.Forms.TextBox();
			this.tbSmtpHostName = new System.Windows.Forms.TextBox();
			this.label14 = new System.Windows.Forms.Label();
			this.tbSmtpHelo = new System.Windows.Forms.TextBox();
			this.label15 = new System.Windows.Forms.Label();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabControl2.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.tabPage3.SuspendLayout();
			this.tabPage4.SuspendLayout();
			this.tabPage5.SuspendLayout();
			this.tabPage6.SuspendLayout();
			this.tabPage7.SuspendLayout();
			this.SuspendLayout();
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuFile});
			// 
			// menuFile
			// 
			this.menuFile.Index = 0;
			this.menuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuFileNew,
																					 this.menuFileOpen,
																					 this.menuItem2,
																					 this.menuFileSave,
																					 this.menuFileSaveAs,
																					 this.menuItem4,
																					 this.menuFileExit});
			this.menuFile.Text = "&File";
			// 
			// menuFileNew
			// 
			this.menuFileNew.Index = 0;
			this.menuFileNew.Shortcut = System.Windows.Forms.Shortcut.CtrlN;
			this.menuFileNew.Text = "&New";
			this.menuFileNew.Click += new System.EventHandler(this.menuFileNew_Click);
			// 
			// menuFileOpen
			// 
			this.menuFileOpen.Index = 1;
			this.menuFileOpen.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
			this.menuFileOpen.Text = "&Open..";
			this.menuFileOpen.Click += new System.EventHandler(this.menuFileOpen_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 2;
			this.menuItem2.Text = "-";
			// 
			// menuFileSave
			// 
			this.menuFileSave.Index = 3;
			this.menuFileSave.Shortcut = System.Windows.Forms.Shortcut.CtrlS;
			this.menuFileSave.Text = "&Save";
			this.menuFileSave.Click += new System.EventHandler(this.menuFileSave_Click);
			// 
			// menuFileSaveAs
			// 
			this.menuFileSaveAs.Index = 4;
			this.menuFileSaveAs.Text = "Save &As..";
			this.menuFileSaveAs.Click += new System.EventHandler(this.menuFileSaveAs_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 5;
			this.menuItem4.Text = "-";
			// 
			// menuFileExit
			// 
			this.menuFileExit.Index = 6;
			this.menuFileExit.Text = "E&xit";
			this.menuFileExit.Click += new System.EventHandler(this.menuFileExit_Click);
			// 
			// openFileDialog
			// 
			this.openFileDialog.DefaultExt = "mm";
			this.openFileDialog.Filter = "MailMerge Files (*.mm)|*.mm";
			// 
			// saveFileDialog
			// 
			this.saveFileDialog.DefaultExt = "mm";
			this.saveFileDialog.Filter = "MailMerge Files (*.mm)|*.mm";
			// 
			// tabControl1
			// 
			this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage5);
			this.tabControl1.Controls.Add(this.tabPage6);
			this.tabControl1.Controls.Add(this.tabPage7);
			this.tabControl1.Location = new System.Drawing.Point(8, 8);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(440, 392);
			this.tabControl1.TabIndex = 0;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.tbFromName);
			this.tabPage1.Controls.Add(this.tbFromAddress);
			this.tabPage1.Controls.Add(this.label4);
			this.tabPage1.Controls.Add(this.tbToName);
			this.tabPage1.Controls.Add(this.tabControl2);
			this.tabPage1.Controls.Add(this.cbCharset);
			this.tabPage1.Controls.Add(this.label6);
			this.tabPage1.Controls.Add(this.tbSubject);
			this.tabPage1.Controls.Add(this.tbToAdress);
			this.tabPage1.Controls.Add(this.cbPriority);
			this.tabPage1.Controls.Add(this.label3);
			this.tabPage1.Controls.Add(this.label2);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(432, 366);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "1. Template";
			// 
			// tbFromName
			// 
			this.tbFromName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbFromName.Location = new System.Drawing.Point(272, 8);
			this.tbFromName.Name = "tbFromName";
			this.tbFromName.Size = new System.Drawing.Size(144, 20);
			this.tbFromName.TabIndex = 42;
			this.tbFromName.Text = "";
			this.tbFromName.TextChanged += new System.EventHandler(this.tbFromName_TextChanged);
			// 
			// tbFromAddress
			// 
			this.tbFromAddress.Location = new System.Drawing.Point(112, 8);
			this.tbFromAddress.Name = "tbFromAddress";
			this.tbFromAddress.Size = new System.Drawing.Size(152, 20);
			this.tbFromAddress.TabIndex = 41;
			this.tbFromAddress.Text = "";
			this.tbFromAddress.TextChanged += new System.EventHandler(this.tbFromAddress_TextChanged);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 16);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(112, 16);
			this.label4.TabIndex = 43;
			this.label4.Text = "From E-mail / Name:";
			// 
			// tbToName
			// 
			this.tbToName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbToName.Location = new System.Drawing.Point(272, 32);
			this.tbToName.Name = "tbToName";
			this.tbToName.Size = new System.Drawing.Size(144, 20);
			this.tbToName.TabIndex = 2;
			this.tbToName.Text = "";
			this.tbToName.TextChanged += new System.EventHandler(this.tbToName_TextChanged);
			// 
			// tabControl2
			// 
			this.tabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl2.Controls.Add(this.tabPage2);
			this.tabControl2.Controls.Add(this.tabPage3);
			this.tabControl2.Controls.Add(this.tabPage4);
			this.tabControl2.Location = new System.Drawing.Point(12, 136);
			this.tabControl2.Name = "tabControl2";
			this.tabControl2.SelectedIndex = 0;
			this.tabControl2.Size = new System.Drawing.Size(408, 216);
			this.tabControl2.TabIndex = 6;
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.tbBodyText);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Size = new System.Drawing.Size(400, 190);
			this.tabPage2.TabIndex = 0;
			this.tabPage2.Text = "Text Body";
			// 
			// tbBodyText
			// 
			this.tbBodyText.AcceptsReturn = true;
			this.tbBodyText.AcceptsTab = true;
			this.tbBodyText.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tbBodyText.Location = new System.Drawing.Point(0, 0);
			this.tbBodyText.Multiline = true;
			this.tbBodyText.Name = "tbBodyText";
			this.tbBodyText.Size = new System.Drawing.Size(400, 190);
			this.tbBodyText.TabIndex = 7;
			this.tbBodyText.Text = "";
			this.tbBodyText.TextChanged += new System.EventHandler(this.tbBodyText_TextChanged);
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.tbBodyHtml);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(400, 190);
			this.tabPage3.TabIndex = 1;
			this.tabPage3.Text = "HTML Body";
			this.tabPage3.Visible = false;
			// 
			// tbBodyHtml
			// 
			this.tbBodyHtml.AcceptsReturn = true;
			this.tbBodyHtml.AcceptsTab = true;
			this.tbBodyHtml.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tbBodyHtml.Location = new System.Drawing.Point(0, 0);
			this.tbBodyHtml.Multiline = true;
			this.tbBodyHtml.Name = "tbBodyHtml";
			this.tbBodyHtml.Size = new System.Drawing.Size(400, 190);
			this.tbBodyHtml.TabIndex = 8;
			this.tbBodyHtml.Text = "";
			this.tbBodyHtml.TextChanged += new System.EventHandler(this.tbBodyHtml_TextChanged);
			// 
			// tabPage4
			// 
			this.tabPage4.Controls.Add(this.bRemoveAttachment);
			this.tabPage4.Controls.Add(this.bAddAttachment);
			this.tabPage4.Controls.Add(this.tbAttPath);
			this.tabPage4.Controls.Add(this.tbAttCID);
			this.tabPage4.Controls.Add(this.cbAttInline);
			this.tabPage4.Controls.Add(this.label8);
			this.tabPage4.Controls.Add(this.label7);
			this.tabPage4.Controls.Add(this.lbAttachments);
			this.tabPage4.Location = new System.Drawing.Point(4, 22);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Size = new System.Drawing.Size(400, 190);
			this.tabPage4.TabIndex = 2;
			this.tabPage4.Text = "Attachments";
			this.tabPage4.Visible = false;
			// 
			// bRemoveAttachment
			// 
			this.bRemoveAttachment.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.bRemoveAttachment.Location = new System.Drawing.Point(80, 160);
			this.bRemoveAttachment.Name = "bRemoveAttachment";
			this.bRemoveAttachment.Size = new System.Drawing.Size(64, 23);
			this.bRemoveAttachment.TabIndex = 11;
			this.bRemoveAttachment.Text = "Remove";
			this.bRemoveAttachment.Click += new System.EventHandler(this.bRemoveAttachment_Click);
			// 
			// bAddAttachment
			// 
			this.bAddAttachment.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.bAddAttachment.Location = new System.Drawing.Point(8, 160);
			this.bAddAttachment.Name = "bAddAttachment";
			this.bAddAttachment.Size = new System.Drawing.Size(64, 23);
			this.bAddAttachment.TabIndex = 10;
			this.bAddAttachment.Text = "Add";
			this.bAddAttachment.Click += new System.EventHandler(this.bAddAttachment_Click);
			// 
			// tbAttPath
			// 
			this.tbAttPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbAttPath.Enabled = false;
			this.tbAttPath.Location = new System.Drawing.Point(216, 16);
			this.tbAttPath.Name = "tbAttPath";
			this.tbAttPath.Size = new System.Drawing.Size(168, 20);
			this.tbAttPath.TabIndex = 12;
			this.tbAttPath.Text = "";
			// 
			// tbAttCID
			// 
			this.tbAttCID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbAttCID.Enabled = false;
			this.tbAttCID.Location = new System.Drawing.Point(216, 56);
			this.tbAttCID.Name = "tbAttCID";
			this.tbAttCID.Size = new System.Drawing.Size(168, 20);
			this.tbAttCID.TabIndex = 14;
			this.tbAttCID.Text = "";
			this.tbAttCID.TextChanged += new System.EventHandler(this.tbAttCID_TextChanged);
			// 
			// cbAttInline
			// 
			this.cbAttInline.Enabled = false;
			this.cbAttInline.Location = new System.Drawing.Point(152, 32);
			this.cbAttInline.Name = "cbAttInline";
			this.cbAttInline.Size = new System.Drawing.Size(56, 24);
			this.cbAttInline.TabIndex = 13;
			this.cbAttInline.Text = "Inline";
			this.cbAttInline.CheckedChanged += new System.EventHandler(this.cbAttInline_CheckedChanged);
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(152, 56);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(64, 16);
			this.label8.TabIndex = 2;
			this.label8.Text = "Content-ID:";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(152, 16);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(48, 16);
			this.label7.TabIndex = 1;
			this.label7.Text = "Path:";
			// 
			// lbAttachments
			// 
			this.lbAttachments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left)));
			this.lbAttachments.Location = new System.Drawing.Point(8, 8);
			this.lbAttachments.Name = "lbAttachments";
			this.lbAttachments.Size = new System.Drawing.Size(136, 134);
			this.lbAttachments.TabIndex = 9;
			this.lbAttachments.SelectedIndexChanged += new System.EventHandler(this.lbAttachments_SelectedIndexChanged);
			// 
			// cbCharset
			// 
			this.cbCharset.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.cbCharset.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbCharset.Location = new System.Drawing.Point(112, 104);
			this.cbCharset.Name = "cbCharset";
			this.cbCharset.Size = new System.Drawing.Size(304, 21);
			this.cbCharset.TabIndex = 5;
			this.cbCharset.SelectedIndexChanged += new System.EventHandler(this.cbCharset_SelectedIndexChanged);
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(8, 112);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(48, 16);
			this.label6.TabIndex = 40;
			this.label6.Text = "Charset:";
			// 
			// tbSubject
			// 
			this.tbSubject.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbSubject.Location = new System.Drawing.Point(112, 56);
			this.tbSubject.Name = "tbSubject";
			this.tbSubject.Size = new System.Drawing.Size(304, 20);
			this.tbSubject.TabIndex = 3;
			this.tbSubject.Text = "";
			this.tbSubject.TextChanged += new System.EventHandler(this.tbSubject_TextChanged);
			// 
			// tbToAdress
			// 
			this.tbToAdress.Location = new System.Drawing.Point(112, 32);
			this.tbToAdress.Name = "tbToAdress";
			this.tbToAdress.Size = new System.Drawing.Size(152, 20);
			this.tbToAdress.TabIndex = 1;
			this.tbToAdress.Text = "";
			this.tbToAdress.TextChanged += new System.EventHandler(this.tbToAdress_TextChanged);
			// 
			// cbPriority
			// 
			this.cbPriority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbPriority.Location = new System.Drawing.Point(112, 80);
			this.cbPriority.Name = "cbPriority";
			this.cbPriority.Size = new System.Drawing.Size(128, 21);
			this.cbPriority.TabIndex = 4;
			this.cbPriority.SelectedIndexChanged += new System.EventHandler(this.cbPriority_SelectedIndexChanged);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 88);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(48, 16);
			this.label3.TabIndex = 33;
			this.label3.Text = "Priority:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 64);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 16);
			this.label2.TabIndex = 31;
			this.label2.Text = "Subject:";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 40);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 16);
			this.label1.TabIndex = 29;
			this.label1.Text = "To E-mail / Name:";
			// 
			// tabPage5
			// 
			this.tabPage5.Controls.Add(this.bTestSQL);
			this.tabPage5.Controls.Add(this.tbSql);
			this.tabPage5.Controls.Add(this.label9);
			this.tabPage5.Controls.Add(this.bTestConnection);
			this.tabPage5.Controls.Add(this.label5);
			this.tabPage5.Controls.Add(this.tbConnectionString);
			this.tabPage5.Location = new System.Drawing.Point(4, 22);
			this.tabPage5.Name = "tabPage5";
			this.tabPage5.Size = new System.Drawing.Size(432, 366);
			this.tabPage5.TabIndex = 1;
			this.tabPage5.Text = "2. Data Source";
			// 
			// bTestSQL
			// 
			this.bTestSQL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.bTestSQL.Location = new System.Drawing.Point(352, 328);
			this.bTestSQL.Name = "bTestSQL";
			this.bTestSQL.TabIndex = 5;
			this.bTestSQL.Text = "Test";
			this.bTestSQL.Click += new System.EventHandler(this.bTestSQL_Click);
			// 
			// tbSql
			// 
			this.tbSql.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbSql.Location = new System.Drawing.Point(8, 56);
			this.tbSql.Multiline = true;
			this.tbSql.Name = "tbSql";
			this.tbSql.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.tbSql.Size = new System.Drawing.Size(416, 264);
			this.tbSql.TabIndex = 4;
			this.tbSql.Text = "";
			this.tbSql.TextChanged += new System.EventHandler(this.tbSql_TextChanged);
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(8, 40);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(88, 16);
			this.label9.TabIndex = 3;
			this.label9.Text = "SQL Code:";
			// 
			// bTestConnection
			// 
			this.bTestConnection.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.bTestConnection.Location = new System.Drawing.Point(344, 8);
			this.bTestConnection.Name = "bTestConnection";
			this.bTestConnection.TabIndex = 2;
			this.bTestConnection.Text = "Test";
			this.bTestConnection.Click += new System.EventHandler(this.bTestConnection_Click);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(8, 8);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(104, 16);
			this.label5.TabIndex = 1;
			this.label5.Text = "Connection String:";
			// 
			// tbConnectionString
			// 
			this.tbConnectionString.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbConnectionString.Location = new System.Drawing.Point(120, 8);
			this.tbConnectionString.Name = "tbConnectionString";
			this.tbConnectionString.Size = new System.Drawing.Size(216, 20);
			this.tbConnectionString.TabIndex = 0;
			this.tbConnectionString.Text = "";
			this.tbConnectionString.TextChanged += new System.EventHandler(this.tbConnectionString_TextChanged);
			// 
			// tabPage6
			// 
			this.tabPage6.Controls.Add(this.tbSmtpHelo);
			this.tabPage6.Controls.Add(this.label15);
			this.tabPage6.Controls.Add(this.cbAuthentication);
			this.tabPage6.Controls.Add(this.label10);
			this.tabPage6.Controls.Add(this.tbSmtpPassword);
			this.tabPage6.Controls.Add(this.tbSmtpUserName);
			this.tabPage6.Controls.Add(this.label11);
			this.tabPage6.Controls.Add(this.label12);
			this.tabPage6.Controls.Add(this.label13);
			this.tabPage6.Controls.Add(this.tbSmtpPort);
			this.tabPage6.Controls.Add(this.tbSmtpHostName);
			this.tabPage6.Controls.Add(this.label14);
			this.tabPage6.Controls.Add(this.rbSmtp);
			this.tabPage6.Controls.Add(this.rbOutputDirectory);
			this.tabPage6.Controls.Add(this.tbOutputDirectory);
			this.tabPage6.Location = new System.Drawing.Point(4, 22);
			this.tabPage6.Name = "tabPage6";
			this.tabPage6.Size = new System.Drawing.Size(432, 366);
			this.tabPage6.TabIndex = 2;
			this.tabPage6.Text = "3. Output";
			// 
			// tbOutputDirectory
			// 
			this.tbOutputDirectory.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbOutputDirectory.Location = new System.Drawing.Point(128, 8);
			this.tbOutputDirectory.Name = "tbOutputDirectory";
			this.tbOutputDirectory.Size = new System.Drawing.Size(272, 20);
			this.tbOutputDirectory.TabIndex = 2;
			this.tbOutputDirectory.Text = "";
			this.tbOutputDirectory.TextChanged += new System.EventHandler(this.tbOutputDirectory_TextChanged);
			// 
			// tabPage7
			// 
			this.tabPage7.Controls.Add(this.bGenerate);
			this.tabPage7.Controls.Add(this.cbIsTest);
			this.tabPage7.Controls.Add(this.progressBar);
			this.tabPage7.Location = new System.Drawing.Point(4, 22);
			this.tabPage7.Name = "tabPage7";
			this.tabPage7.Size = new System.Drawing.Size(432, 366);
			this.tabPage7.TabIndex = 3;
			this.tabPage7.Text = "4. MailMerge";
			// 
			// bGenerate
			// 
			this.bGenerate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.bGenerate.Location = new System.Drawing.Point(16, 56);
			this.bGenerate.Name = "bGenerate";
			this.bGenerate.Size = new System.Drawing.Size(400, 23);
			this.bGenerate.TabIndex = 2;
			this.bGenerate.Text = "Start";
			this.bGenerate.Click += new System.EventHandler(this.bGenerate_Click);
			// 
			// cbIsTest
			// 
			this.cbIsTest.Location = new System.Drawing.Point(16, 24);
			this.cbIsTest.Name = "cbIsTest";
			this.cbIsTest.Size = new System.Drawing.Size(224, 24);
			this.cbIsTest.TabIndex = 1;
			this.cbIsTest.Text = "Run in test-mode only.";
			// 
			// progressBar
			// 
			this.progressBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.progressBar.Location = new System.Drawing.Point(16, 88);
			this.progressBar.Name = "progressBar";
			this.progressBar.Size = new System.Drawing.Size(400, 24);
			this.progressBar.TabIndex = 0;
			// 
			// rbOutputDirectory
			// 
			this.rbOutputDirectory.Location = new System.Drawing.Point(16, 8);
			this.rbOutputDirectory.Name = "rbOutputDirectory";
			this.rbOutputDirectory.Size = new System.Drawing.Size(112, 24);
			this.rbOutputDirectory.TabIndex = 3;
			this.rbOutputDirectory.Text = "Output Directory:";
			this.rbOutputDirectory.CheckedChanged += new System.EventHandler(this.rbOutputDirectory_CheckedChanged);
			// 
			// rbSmtp
			// 
			this.rbSmtp.Location = new System.Drawing.Point(16, 40);
			this.rbSmtp.Name = "rbSmtp";
			this.rbSmtp.TabIndex = 4;
			this.rbSmtp.Text = "Output SMTP:";
			this.rbSmtp.CheckedChanged += new System.EventHandler(this.rbSmtp_CheckedChanged);
			// 
			// cbAuthentication
			// 
			this.cbAuthentication.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.cbAuthentication.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbAuthentication.Location = new System.Drawing.Point(32, 200);
			this.cbAuthentication.Name = "cbAuthentication";
			this.cbAuthentication.Size = new System.Drawing.Size(368, 21);
			this.cbAuthentication.TabIndex = 27;
			this.cbAuthentication.SelectedIndexChanged += new System.EventHandler(this.cbAuthentication_SelectedIndexChanged);
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(32, 184);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(80, 16);
			this.label10.TabIndex = 26;
			this.label10.Text = "Authentication:";
			// 
			// tbSmtpPassword
			// 
			this.tbSmtpPassword.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbSmtpPassword.Location = new System.Drawing.Point(32, 296);
			this.tbSmtpPassword.Name = "tbSmtpPassword";
			this.tbSmtpPassword.PasswordChar = '*';
			this.tbSmtpPassword.Size = new System.Drawing.Size(360, 20);
			this.tbSmtpPassword.TabIndex = 25;
			this.tbSmtpPassword.Text = "";
			this.tbSmtpPassword.TextChanged += new System.EventHandler(this.tbSmtpPassword_TextChanged);
			// 
			// tbSmtpUserName
			// 
			this.tbSmtpUserName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbSmtpUserName.Location = new System.Drawing.Point(32, 248);
			this.tbSmtpUserName.Name = "tbSmtpUserName";
			this.tbSmtpUserName.Size = new System.Drawing.Size(360, 20);
			this.tbSmtpUserName.TabIndex = 24;
			this.tbSmtpUserName.Text = "";
			this.tbSmtpUserName.TextChanged += new System.EventHandler(this.tbSmtpUserName_TextChanged);
			// 
			// label11
			// 
			this.label11.Location = new System.Drawing.Point(32, 280);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(64, 16);
			this.label11.TabIndex = 23;
			this.label11.Text = "Password:";
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(32, 232);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(72, 16);
			this.label12.TabIndex = 22;
			this.label12.Text = "User Name:";
			// 
			// label13
			// 
			this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label13.Location = new System.Drawing.Point(328, 72);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(48, 16);
			this.label13.TabIndex = 21;
			this.label13.Text = "Port:";
			// 
			// tbSmtpPort
			// 
			this.tbSmtpPort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.tbSmtpPort.Location = new System.Drawing.Point(328, 88);
			this.tbSmtpPort.Name = "tbSmtpPort";
			this.tbSmtpPort.Size = new System.Drawing.Size(72, 20);
			this.tbSmtpPort.TabIndex = 20;
			this.tbSmtpPort.Text = "";
			this.tbSmtpPort.TextChanged += new System.EventHandler(this.tbSmtpPort_TextChanged);
			// 
			// tbSmtpHostName
			// 
			this.tbSmtpHostName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbSmtpHostName.Location = new System.Drawing.Point(32, 88);
			this.tbSmtpHostName.Name = "tbSmtpHostName";
			this.tbSmtpHostName.Size = new System.Drawing.Size(288, 20);
			this.tbSmtpHostName.TabIndex = 19;
			this.tbSmtpHostName.Text = "";
			this.tbSmtpHostName.TextChanged += new System.EventHandler(this.tbSmtpHostName_TextChanged);
			// 
			// label14
			// 
			this.label14.Location = new System.Drawing.Point(32, 72);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(100, 16);
			this.label14.TabIndex = 18;
			this.label14.Text = "Host Name:";
			// 
			// tbSmtpHelo
			// 
			this.tbSmtpHelo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tbSmtpHelo.Location = new System.Drawing.Point(32, 136);
			this.tbSmtpHelo.Name = "tbSmtpHelo";
			this.tbSmtpHelo.Size = new System.Drawing.Size(360, 20);
			this.tbSmtpHelo.TabIndex = 29;
			this.tbSmtpHelo.Text = "";
			this.tbSmtpHelo.TextChanged += new System.EventHandler(this.tbSmtpHelo_TextChanged);
			// 
			// label15
			// 
			this.label15.Location = new System.Drawing.Point(32, 120);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(80, 16);
			this.label15.TabIndex = 28;
			this.label15.Text = "HELO Domain:";
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(456, 409);
			this.Controls.Add(this.tabControl1);
			this.Menu = this.mainMenu;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "MailMerger";
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabControl2.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.tabPage3.ResumeLayout(false);
			this.tabPage4.ResumeLayout(false);
			this.tabPage5.ResumeLayout(false);
			this.tabPage6.ResumeLayout(false);
			this.tabPage7.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		/// <summary>
		/// Contains common charsets (for use in this form).
		/// </summary>
		static Hashtable charsets;

		/// <summary>
		/// Static constructor makes sure that we only load available charsets once per application.
		/// </summary>
		static MainForm()
		{
			charsets = new Hashtable();
			CultureInfo[] ciList = CultureInfo.GetCultures( CultureTypes.InstalledWin32Cultures );
			foreach( CultureInfo ci in ciList )
			{
				try
				{
					Encoding enc = Encoding.GetEncoding( ci.TextInfo.ANSICodePage );
					if( !charsets.ContainsKey( enc.CodePage ) )
						charsets.Add( enc.CodePage, enc.BodyName );
				}
				catch
				{
				}
			}

			if( !charsets.ContainsKey( Encoding.UTF8.CodePage ) )
				charsets.Add( Encoding.UTF8.CodePage, Encoding.UTF8.BodyName );

			if( !charsets.ContainsKey( Encoding.ASCII.CodePage ) )
				charsets.Add( Encoding.ASCII.CodePage, Encoding.ASCII.BodyName );

			if( !charsets.ContainsKey( Encoding.Default.CodePage ) )
				charsets.Add( Encoding.Default.CodePage, Encoding.Default.BodyName );
		}

		/// <summary>
		/// Helper function - displays an error message.
		/// </summary>
		private void ShowErrorMessage( Exception e )
		{
			ShowErrorMessage( e.Message );
		}

		/// <summary>
		/// Helper function - displays an error message.
		/// </summary>
		private void ShowErrorMessage( string msg )
		{
			MessageBox.Show( this, msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error );
		}

		/// <summary>
		/// Helper member - keeps track of wether we are updating the form or the user is.
		/// </summary>
		private bool m_isBinding = false;

		/// <summary>
		/// Fills the form with data.
		/// </summary>
		private void BindFormData()
		{
			m_isBinding = true;

			// template form data
			// message headers
			tbFromAddress.Text = m_file.FromEmail;
			tbFromName.Text = m_file.FromFullName;
			tbToAdress.Text = m_file.ToEmail;
			tbToName.Text = m_file.ToFullName;
			tbSubject.Text = m_file.Subject;
			cbPriority.SelectedItem = m_file.Priority;
			cbCharset.SelectedIndex = cbCharset.Items.IndexOf( m_file.Charset.BodyName );

			// bodies
			tbBodyText.Text = m_file.BodyText;
			tbBodyHtml.Text = m_file.BodyHtml;

			// attachments			
			BindAttachments();

			// data sources
			// connection string
			tbConnectionString.Text = m_file.ConnectionString;
			tbSql.Text = m_file.Sql;

			// output
			// output directory
			rbOutputDirectory.Checked = m_file.OutputMethod == 0;
			tbOutputDirectory.Text = m_file.OutputDirectory;
			// output smtp
			rbSmtp.Checked = m_file.OutputMethod == 1;
			tbSmtpHostName.Text = m_file.OutputSmtpHostName;
			tbSmtpHelo.Text = m_file.OutputSmtpHelo;
			tbSmtpPort.Text = m_file.OutputSmtpPort.ToString();
			cbAuthentication.SelectedItem = m_file.OutputSmtpAuth;
			tbSmtpUserName.Text = m_file.OutputSmtpUserName;
			tbSmtpPassword.Text = m_file.OutputSmtpPassword;

			ChangeOutput();

			m_isBinding = false;
		}

		/// <summary>
		/// Changes the output method.
		/// </summary>
		private void ChangeOutput()
		{
			if( m_file.OutputMethod == 0 )
			{
				tbOutputDirectory.Enabled = true;

				tbSmtpHostName.Enabled = 
					tbSmtpPort.Enabled =
					cbAuthentication.Enabled =
					tbSmtpUserName.Enabled =
					tbSmtpPassword.Enabled = false;

				cbAuthentication.SelectedIndex = 0;

				tbSmtpHostName.Text = 
					tbSmtpPort.Text =					
					tbSmtpUserName.Text =
					tbSmtpPassword.Text = "";
			}
			if( m_file.OutputMethod == 1 )
			{
				tbOutputDirectory.Enabled = false;
				tbOutputDirectory.Text = "";

				tbSmtpHostName.Enabled = 
					tbSmtpPort.Enabled =
					cbAuthentication.Enabled = true;

				tbSmtpUserName.Enabled =
					tbSmtpPassword.Enabled = cbAuthentication.SelectedIndex > 0;
			}
		}

		/// <summary>
		/// Fills the attachment list.
		/// </summary>
		private void BindAttachments()
		{
			lbAttachments.BeginUpdate();
			lbAttachments.Items.Clear();
			foreach( LocalAttachedFile att in m_file.Attachments )
			{
				lbAttachments.Items.Add( att );
			}
			lbAttachments.EndUpdate();
		}

		/// <summary>
		/// File -> New menu
		/// </summary>
		private void menuFileNew_Click(object sender, System.EventArgs e)
		{
			m_file = new MailMergeFile();
			BindFormData();
		}

		/// <summary>
		/// File -> Open menu
		/// </summary>
		private void menuFileOpen_Click(object sender, System.EventArgs e)
		{
			if( openFileDialog.ShowDialog( this ) == DialogResult.OK )
			{
				try
				{
					m_file.Load( openFileDialog.FileName );
					BindFormData();
				}
				catch( Exception ex )
				{
					ShowErrorMessage( ex );
				}
			}
		}

		/// <summary>
		/// File -> Save menu
		/// </summary>
		private void menuFileSave_Click(object sender, System.EventArgs e)
		{
			if( m_file.FileName == null )
			{
				menuFileSaveAs_Click( sender, e );
			}
			else
			{
				try
				{				
					m_file.Save( m_file.FileName );
				}
				catch( Exception ex )
				{
					ShowErrorMessage( ex );
				}
			}
		}

		/// <summary>
		/// File -> Save As menu
		/// </summary>
		private void menuFileSaveAs_Click(object sender, System.EventArgs e)
		{
			if( saveFileDialog.ShowDialog( this ) == DialogResult.OK )
			{
				try
				{
					m_file.Save( saveFileDialog.FileName );
				}
				catch( Exception ex )
				{
					ShowErrorMessage( ex );
				}
			}
		}

		/// <summary>
		/// File -> Exit menu
		/// </summary>
		private void menuFileExit_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbFromAddress_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.FromEmail = tbFromAddress.Text;
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbFromName_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.FromFullName = tbFromName.Text;
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbToAdress_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.ToEmail = tbToAdress.Text;
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbToName_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.ToFullName = tbToName.Text;
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbSubject_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.Subject = tbSubject.Text;
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void cbPriority_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.Priority = (Priority) cbPriority.SelectedItem;
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void cbCharset_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.Charset = Encoding.GetEncoding( (string) cbCharset.SelectedItem );
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbBodyText_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.BodyText = tbBodyText.Text;
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbBodyHtml_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.BodyHtml = tbBodyHtml.Text;
		}

		/// <summary>
		/// Loads selected attachment
		/// </summary>
		private void lbAttachments_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if( lbAttachments.SelectedIndex >= 0 && lbAttachments.SelectedIndex < m_file.Attachments.Count )
			{
				tbAttCID.Enabled = true;
				cbAttInline.Enabled = true;

				LocalAttachedFile file = (LocalAttachedFile) m_file.Attachments[lbAttachments.SelectedIndex];
				tbAttPath.Text = file.Path;
				tbAttCID.Enabled = cbAttInline.Checked = file.Inline;
				tbAttCID.Text = file.ContentId;				
			}
			else
			{
				tbAttCID.Enabled = false;
				cbAttInline.Enabled = false;
			}
		}

		/// <summary>
		/// Adds an attachment
		/// </summary>
		private void bAddAttachment_Click(object sender, System.EventArgs e)
		{
			if( attFileDialog.ShowDialog( this ) == DialogResult.OK )
			{
				LocalAttachedFile file = new LocalAttachedFile( attFileDialog.FileName );
				m_file.Attachments.Add( file );
				lbAttachments.Items.Add( file );
			}
		}

		/// <summary>
		/// Removes an attachment
		/// </summary>
		private void bRemoveAttachment_Click(object sender, System.EventArgs e)
		{
			if( lbAttachments.SelectedIndex >= 0 && lbAttachments.SelectedIndex < m_file.Attachments.Count )
			{
				m_file.Attachments.RemoveAt( lbAttachments.SelectedIndex );
				lbAttachments.Items.RemoveAt( lbAttachments.SelectedIndex );
			}
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void cbAttInline_CheckedChanged(object sender, System.EventArgs e)
		{
			if( lbAttachments.SelectedIndex >= 0 && lbAttachments.SelectedIndex < m_file.Attachments.Count )
			{				
				LocalAttachedFile file = (LocalAttachedFile) m_file.Attachments[lbAttachments.SelectedIndex];
				file.Inline = tbAttCID.Enabled = cbAttInline.Checked;
			}
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbAttCID_TextChanged(object sender, System.EventArgs e)
		{
			if( lbAttachments.SelectedIndex >= 0 && lbAttachments.SelectedIndex < m_file.Attachments.Count )
			{				
				LocalAttachedFile file = (LocalAttachedFile) m_file.Attachments[lbAttachments.SelectedIndex];
				file.ContentId = tbAttCID.Text;
			}
		}

		/// <summary>
		/// Tests the given ODBC connection string.
		/// </summary>
		private void bTestConnection_Click(object sender, System.EventArgs e)
		{
			try
			{
				using( OdbcConnection connection = new OdbcConnection( m_file.ConnectionString ) )
				{
					connection.Open();				
				}
				MessageBox.Show( this, "Connection String is working!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information );
			}
			catch( Exception ex )
			{
				ShowErrorMessage( ex );
			}
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbConnectionString_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.ConnectionString = tbConnectionString.Text;
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbSql_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.Sql = tbSql.Text;
		}

		/// <summary>
		/// Tests the SQL statement (and connection string).
		/// </summary>
		private void bTestSQL_Click(object sender, System.EventArgs e)
		{
			try
			{
				using( OdbcConnection connection = new OdbcConnection( m_file.ConnectionString ) )
				using( OdbcCommand command = new OdbcCommand( m_file.Sql, connection ) )
				{
					connection.Open();
					command.ExecuteNonQuery();
				}
				MessageBox.Show( this, "Connection String and SQL code is working!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information );
			}
			catch( Exception ex )
			{
				ShowErrorMessage( ex );
			}
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbOutputDirectory_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.OutputDirectory = tbOutputDirectory.Text;
		}

		/// <summary>
		/// Starts the MailMerge process.
		/// </summary>
		private void bGenerate_Click(object sender, System.EventArgs e)
		{			
			progressBar.Maximum = 4;
			progressBar.Minimum = 0;
			progressBar.Value = 0;	
			progressBar.Invalidate();

			if( m_file.OutputMethod == 0 )
			{
				if(  m_file.OutputDirectory == null || m_file.OutputDirectory.Length == 0 )
				{
					ShowErrorMessage( "You must select an output folder." );
					return;
				}

				if( !Directory.Exists( m_file.OutputDirectory ) )
				{
					try
					{
						Directory.CreateDirectory( m_file.OutputDirectory );
					}
					catch( Exception ex )
					{
						ShowErrorMessage( ex );
						return;
					}
				}
			}

			if( m_file.OutputMethod == 1 )
			{
				if( m_file.OutputSmtpHostName.Length == 0 )
				{
					ShowErrorMessage( "You have to enter a host name for your SMTP server." );
					return;
				}

				if( m_file.OutputSmtpPort <= 0 )
				{
					ShowErrorMessage( "Invalid SMTP port." );
					return;
				}
			}

			// for logging the results..
			MailMergeResult result = null;

			Cursor = Cursors.WaitCursor;
			bGenerate.Enabled = false;
			progressBar.Increment(1);
			try
			{
				// create mailmerge object
				MailMerge mm = new MailMerge();
				// setup mail merge template
				mm.Template.From.FullName = m_file.FromFullName;
				mm.Template.From.Email = m_file.FromEmail;
				mm.Template.To.Add( m_file.ToEmail, m_file.ToFullName );
				mm.Template.Priority = m_file.Priority;
				mm.Template.Charset = m_file.Charset;
				mm.Template.Subject = m_file.Subject;
				mm.Template.BodyHtml = m_file.BodyHtml;
				mm.Template.BodyText = m_file.BodyText;
				foreach( LocalAttachedFile att in m_file.Attachments )
				{
					if( att.Inline )
					{
						mm.Template.Attachments.AddInlineAttachment( att.Path, att.ContentId );
					}
					else
					{
						mm.Template.Attachments.Add( att.Path );
					}
				}
				progressBar.Increment(1);

				// set callback
				mm.OutputCallback = new MailMergeCallback( OnMailMerge );
				
				// set test mode if applicable
				if( cbIsTest.Checked )
				{
					mm.EnableTestMode( new Address( m_file.FromEmail, m_file.FromFullName ), 5 );
				}
				progressBar.Increment(1);							

				// get data source
				using( OdbcConnection connection = new OdbcConnection( m_file.ConnectionString ) )
				using( OdbcCommand command = new OdbcCommand( m_file.Sql, connection ) )
				{
					connection.Open();
					using( OdbcDataReader reader = command.ExecuteReader() ) 
					{
						// set data source
						mm.DataSource = reader;

						// data bind
						result = mm.DataBind(false);						
					}
				}								
				progressBar.Increment(1);
			}
			catch( Exception ex )
			{
				ShowErrorMessage( ex );
				Cursor = Cursors.Default;
				bGenerate.Enabled = true;
				progressBar.Value = 0;
				return;
			}

			if( result != null )
			{
				MessageBox.Show( this, "MailMerge completed with " +
					result.FailureCount + " failures and " + result.SuccessCount + " successfully created messages." );
			}

			Cursor = Cursors.Default;
			bGenerate.Enabled = true;
		}

		/// <summary>
		/// Our MailMerge callback - does the actual serialization of the resulting message.
		/// We want to handle this by ourself so that we can increase our progressbar!
		/// </summary>
		private void OnMailMerge( Dimac.JMail.Message message )
		{
			if( m_file.OutputMethod == 0 )
			{
				string fileName = Path.Combine( m_file.OutputDirectory, Guid.NewGuid().ToString("n") + ".eml" );
				using( FileStream stream = new FileStream( fileName, FileMode.Create, FileAccess.Write, FileShare.None ) )
				using( MimeWriter writer = new MimeWriter( stream ) )
				{
					writer.Write( message );
				}
			}
			else if( m_file.OutputMethod == 1 )
			{
				Smtp smtp = new Smtp( m_file.OutputSmtpHostName, (short) m_file.OutputSmtpPort );
				smtp.Domain = m_file.OutputSmtpHelo.Length > 0 ? m_file.OutputSmtpHelo : null;

				if( ( smtp.Authentication = m_file.OutputSmtpAuth ) != SmtpAuthentication.None )
				{
					smtp.UserName = m_file.OutputSmtpUserName;
					smtp.Password = m_file.OutputSmtpPassword;					
				}
				smtp.Send( message );
			}
			progressBar.Maximum++;
			progressBar.Increment(1);			
			progressBar.Invalidate();
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void rbOutputDirectory_CheckedChanged(object sender, System.EventArgs e)
		{
			if (m_isBinding) return;

			m_file.OutputMethod = rbOutputDirectory.Checked ? 0 : 1;
			ChangeOutput();
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void rbSmtp_CheckedChanged(object sender, System.EventArgs e)
		{
			if (m_isBinding) return;

			m_file.OutputMethod = rbSmtp.Checked ? 1 : 0;
			ChangeOutput();
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void cbAuthentication_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			tbSmtpUserName.Enabled =
				tbSmtpPassword.Enabled = cbAuthentication.SelectedIndex > 0;

			if( ( m_file.OutputSmtpAuth = (SmtpAuthentication) cbAuthentication.SelectedItem ) == SmtpAuthentication.None )
			{
				tbSmtpUserName.Text = 
					tbSmtpPassword.Text = "";
			}
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbSmtpHostName_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;
			
			m_file.OutputSmtpHostName = tbSmtpHostName.Text;
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbSmtpHelo_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.OutputSmtpHelo = tbSmtpHelo.Text;
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbSmtpPort_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			if( tbSmtpPort.Text.Length > 0 )
			{
				try
				{
					m_file.OutputSmtpPort = int.Parse( tbSmtpPort.Text );
				}
				catch
				{
					tbSmtpPort.Text = "";
				}
			}
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbSmtpUserName_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.OutputSmtpUserName = tbSmtpUserName.Text;
		}

		/// <summary>
		/// Value changed -> save to mailmerge data file
		/// </summary>
		private void tbSmtpPassword_TextChanged(object sender, System.EventArgs e)
		{
			if( m_isBinding ) return;

			m_file.OutputSmtpPassword = tbSmtpPassword.Text;
		}
	}
}
